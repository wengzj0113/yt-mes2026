"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dataSourceOptions = void 0;
const typeorm_1 = require("typeorm");
const config_1 = require("@nestjs/config");
const dotenv_1 = require("dotenv");
const typeorm_naming_strategies_1 = require("typeorm-naming-strategies");
(0, dotenv_1.config)();
const configService = new config_1.ConfigService();
exports.dataSourceOptions = {
    type: 'mssql',
    host: configService.get('DB_HOST', 'localhost'),
    port: parseInt(configService.get('DB_PORT', '1433'), 10),
    username: configService.get('DB_USERNAME', 'sa'),
    password: configService.get('DB_PASSWORD'),
    database: configService.get('DB_DATABASE', 'YT_MES'),
    entities: ['src/**/*.entity.ts'],
    migrations: ['src/migrations/*.ts'],
    namingStrategy: new typeorm_naming_strategies_1.SnakeNamingStrategy(),
    options: {
        encrypt: false,
        trustServerCertificate: true,
    },
};
const dataSource = new typeorm_1.DataSource(exports.dataSourceOptions);
exports.default = dataSource;
//# sourceMappingURL=typeorm.config.js.map