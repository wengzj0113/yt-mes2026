"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessDynamicModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const batch_entity_1 = require("../batch/batch.entity");
const process_dictionary_entity_1 = require("../master-data/process-dictionary/process-dictionary.entity");
const process_dynamic_controller_1 = require("./process-dynamic.controller");
const process_dynamic_record_entity_1 = require("./process-dynamic-record.entity");
const process_dynamic_service_1 = require("./process-dynamic.service");
let ProcessDynamicModule = class ProcessDynamicModule {
};
exports.ProcessDynamicModule = ProcessDynamicModule;
exports.ProcessDynamicModule = ProcessDynamicModule = __decorate([
    (0, common_1.Module)({ imports: [typeorm_1.TypeOrmModule.forFeature([process_dynamic_record_entity_1.ProcessDynamicRecord, batch_entity_1.Batch, process_dictionary_entity_1.ProcessDictionary])], controllers: [process_dynamic_controller_1.ProcessDynamicController], providers: [process_dynamic_service_1.ProcessDynamicService] })
], ProcessDynamicModule);
//# sourceMappingURL=process-dynamic.module.js.map