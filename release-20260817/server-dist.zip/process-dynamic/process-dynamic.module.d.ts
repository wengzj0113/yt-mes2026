export declare class ProcessDynamicModule {
}
