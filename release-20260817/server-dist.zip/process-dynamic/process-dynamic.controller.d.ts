import { JwtPayload } from '../common/decorators/current-user.decorator';
import { ProcessDynamicService } from './process-dynamic.service';
export declare class ProcessDynamicController {
    private readonly service;
    constructor(service: ProcessDynamicService);
    find(code: string, batchNo: string): Promise<{
        data: import("./process-dynamic-record.entity").ProcessDynamicRecord | null;
    }>;
    save(code: string, body: {
        batchNo: string;
        [key: string]: unknown;
    }, user: JwtPayload): Promise<{
        data: import("./process-dynamic-record.entity").ProcessDynamicRecord;
        message: string;
    }>;
    submit(code: string, body: {
        batchNo: string;
        [key: string]: unknown;
    }, user: JwtPayload): Promise<{
        data: import("./process-dynamic-record.entity").ProcessDynamicRecord;
        message: string;
    }>;
}
