export declare class ProcessDynamicRecord {
    id: number;
    batchNo: string;
    processCode: string;
    extraData: string | null;
    recordStatus: number;
    isDraft: boolean;
    createdBy: number | null;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date;
}
