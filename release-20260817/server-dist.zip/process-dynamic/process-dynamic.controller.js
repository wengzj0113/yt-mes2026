"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessDynamicController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const roles_decorator_1 = require("../common/decorators/roles.decorator");
const user_entity_1 = require("../user/user.entity");
const process_dynamic_service_1 = require("./process-dynamic.service");
let ProcessDynamicController = class ProcessDynamicController {
    constructor(service) {
        this.service = service;
    }
    async find(code, batchNo) { return { data: await this.service.findByBatchNo(code, batchNo) }; }
    async save(code, body, user) {
        const { batchNo, ...data } = body;
        return { data: await this.service.saveDraft(code, batchNo, data, user.sub), message: '参数保存成功' };
    }
    async submit(code, body, user) {
        const { batchNo, ...data } = body;
        return { data: await this.service.submit(code, batchNo, data, user.sub), message: '工序参数提交成功' };
    }
};
exports.ProcessDynamicController = ProcessDynamicController;
__decorate([
    (0, common_1.Get)(':processCode/:batchNo'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.OPERATOR, user_entity_1.UserRole.QUALITY, user_entity_1.UserRole.WAREHOUSE, user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('processCode')),
    __param(1, (0, common_1.Param)('batchNo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], ProcessDynamicController.prototype, "find", null);
__decorate([
    (0, common_1.Post)(':processCode/draft'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.OPERATOR, user_entity_1.UserRole.QUALITY, user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('processCode')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], ProcessDynamicController.prototype, "save", null);
__decorate([
    (0, common_1.Post)(':processCode/submit'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.OPERATOR, user_entity_1.UserRole.QUALITY, user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('processCode')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], ProcessDynamicController.prototype, "submit", null);
exports.ProcessDynamicController = ProcessDynamicController = __decorate([
    (0, common_1.Controller)('process-dynamic'),
    __metadata("design:paramtypes", [process_dynamic_service_1.ProcessDynamicService])
], ProcessDynamicController);
//# sourceMappingURL=process-dynamic.controller.js.map