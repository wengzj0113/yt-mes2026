"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessDynamicRecord = void 0;
const typeorm_1 = require("typeorm");
let ProcessDynamicRecord = class ProcessDynamicRecord {
};
exports.ProcessDynamicRecord = ProcessDynamicRecord;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ProcessDynamicRecord.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'batch_no', length: 16 }),
    __metadata("design:type", String)
], ProcessDynamicRecord.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'process_code', length: 32 }),
    __metadata("design:type", String)
], ProcessDynamicRecord.prototype, "processCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'extra_data', type: 'nvarchar', length: 'max', nullable: true }),
    __metadata("design:type", Object)
], ProcessDynamicRecord.prototype, "extraData", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'record_status', type: 'int', default: 1 }),
    __metadata("design:type", Number)
], ProcessDynamicRecord.prototype, "recordStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'is_draft', default: true }),
    __metadata("design:type", Boolean)
], ProcessDynamicRecord.prototype, "isDraft", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'created_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], ProcessDynamicRecord.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], ProcessDynamicRecord.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'updated_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], ProcessDynamicRecord.prototype, "updatedBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], ProcessDynamicRecord.prototype, "updatedAt", void 0);
exports.ProcessDynamicRecord = ProcessDynamicRecord = __decorate([
    (0, typeorm_1.Entity)('process_dynamic_record'),
    (0, typeorm_1.Index)(['batchNo', 'processCode'], { unique: true })
], ProcessDynamicRecord);
//# sourceMappingURL=process-dynamic-record.entity.js.map