"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessDynamicService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const batch_entity_1 = require("../batch/batch.entity");
const process_baseline_1 = require("../master-data/process-baseline");
const process_dictionary_entity_1 = require("../master-data/process-dictionary/process-dictionary.entity");
const process_dynamic_record_entity_1 = require("./process-dynamic-record.entity");
let ProcessDynamicService = class ProcessDynamicService {
    constructor(repo, batchRepo, dictionaryRepo) {
        this.repo = repo;
        this.batchRepo = batchRepo;
        this.dictionaryRepo = dictionaryRepo;
    }
    validate(processCode) {
        if (!(0, process_baseline_1.getProcessBaseline)(processCode))
            throw new common_1.BadRequestException({ code: 'PROCESS_UNSUPPORTED', message: '不支持的普通工序' });
    }
    async getFieldDefinitions(processCode) {
        const dictionary = await this.dictionaryRepo.findOne({ where: { processCode } });
        const baseline = (0, process_baseline_1.getProcessBaseline)(processCode);
        if (baseline) {
            if ((0, process_baseline_1.hasIncompatibleFieldDefinitions)(dictionary?.fieldDefinitions, baseline.fieldDefinitions)) {
                return baseline.fieldDefinitions;
            }
        }
        if (dictionary?.fieldDefinitions) {
            try {
                const fields = JSON.parse(dictionary.fieldDefinitions);
                if (Array.isArray(fields))
                    return fields.filter((field) => field && typeof field === 'object');
            }
            catch { }
        }
        return (0, process_baseline_1.getProcessBaseline)(processCode)?.fieldDefinitions ?? [];
    }
    async validateSubmission(processCode, data) {
        const fields = await this.getFieldDefinitions(processCode);
        const missing = [];
        const invalid = [];
        for (const field of fields) {
            if (field.type === 'range' && field.minKey && field.maxKey) {
                const minValue = data[field.minKey];
                const maxValue = data[field.maxKey];
                if (field.required !== false && (minValue === undefined || minValue === null || String(minValue).trim() === '')) {
                    missing.push(field.minLabel || `${field.label}最小值`);
                }
                if (field.required !== false && (maxValue === undefined || maxValue === null || String(maxValue).trim() === '')) {
                    missing.push(field.maxLabel || `${field.label}最大值`);
                }
                if (minValue !== undefined && minValue !== null && String(minValue).trim() !== '' && !Number.isFinite(Number(minValue)))
                    invalid.push(field.minLabel || `${field.label}最小值`);
                if (maxValue !== undefined && maxValue !== null && String(maxValue).trim() !== '' && !Number.isFinite(Number(maxValue)))
                    invalid.push(field.maxLabel || `${field.label}最大值`);
                if (Number.isFinite(Number(minValue)) && Number.isFinite(Number(maxValue)) && Number(minValue) > Number(maxValue))
                    invalid.push(field.label);
                continue;
            }
            const value = data[field.key];
            if (field.required !== false && (value === undefined || value === null || String(value).trim() === '')) {
                missing.push(field.label || field.key);
                continue;
            }
            if (value === undefined || value === null || String(value).trim() === '')
                continue;
            if (field.type === 'number' && !Number.isFinite(Number(value)))
                invalid.push(field.label || field.key);
            const numericValue = Number(value);
            if (field.min != null && Number.isFinite(numericValue) && numericValue < Number(field.min))
                invalid.push(field.label || field.key);
            if (field.max != null && Number.isFinite(numericValue) && numericValue > Number(field.max))
                invalid.push(field.label || field.key);
        }
        if (missing.length)
            throw new common_1.BadRequestException({ code: 'PROCESS_FIELDS_INCOMPLETE', message: `以下参数未填写：${missing.join('、')}` });
        if (invalid.length)
            throw new common_1.BadRequestException({ code: 'PROCESS_FIELDS_INVALID', message: `以下参数不符合配置范围或类型：${[...new Set(invalid)].join('、')}` });
    }
    async findByBatchNo(processCode, batchNo) {
        this.validate(processCode);
        return this.repo.findOne({ where: { processCode, batchNo } });
    }
    async saveDraft(processCode, batchNo, data, userId) {
        this.validate(processCode);
        if (!(await this.batchRepo.findOne({ where: { batchNo } })))
            throw new common_1.NotFoundException({ code: 'BATCH_NOT_FOUND', message: `批次 ${batchNo} 不存在` });
        let record = await this.repo.findOne({ where: { processCode, batchNo } });
        if (!record)
            record = this.repo.create({ processCode, batchNo, createdBy: userId });
        record.extraData = JSON.stringify(data);
        record.updatedBy = userId;
        return this.repo.save(record);
    }
    async submit(processCode, batchNo, data, userId) {
        this.validate(processCode);
        if (!(await this.batchRepo.findOne({ where: { batchNo } })))
            throw new common_1.NotFoundException({ code: 'BATCH_NOT_FOUND', message: `批次 ${batchNo} 不存在` });
        let record = await this.repo.findOne({ where: { processCode, batchNo } });
        if (!record)
            record = this.repo.create({ processCode, batchNo, createdBy: userId });
        let existing = {};
        if (record.extraData) {
            try {
                existing = JSON.parse(record.extraData);
            }
            catch {
                existing = {};
            }
        }
        const mergedData = { ...existing, ...data };
        await this.validateSubmission(processCode, mergedData);
        record.extraData = JSON.stringify(mergedData);
        record.isDraft = false;
        record.recordStatus = 1;
        record.updatedBy = userId;
        return this.repo.save(record);
    }
};
exports.ProcessDynamicService = ProcessDynamicService;
exports.ProcessDynamicService = ProcessDynamicService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(process_dynamic_record_entity_1.ProcessDynamicRecord)),
    __param(1, (0, typeorm_1.InjectRepository)(batch_entity_1.Batch)),
    __param(2, (0, typeorm_1.InjectRepository)(process_dictionary_entity_1.ProcessDictionary)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], ProcessDynamicService);
//# sourceMappingURL=process-dynamic.service.js.map