import { Repository } from 'typeorm';
import { Batch } from '../batch/batch.entity';
import { ProcessDictionary } from '../master-data/process-dictionary/process-dictionary.entity';
import { ProcessDynamicRecord } from './process-dynamic-record.entity';
export declare class ProcessDynamicService {
    private readonly repo;
    private readonly batchRepo;
    private readonly dictionaryRepo;
    constructor(repo: Repository<ProcessDynamicRecord>, batchRepo: Repository<Batch>, dictionaryRepo: Repository<ProcessDictionary>);
    private validate;
    private getFieldDefinitions;
    private validateSubmission;
    findByBatchNo(processCode: string, batchNo: string): Promise<ProcessDynamicRecord | null>;
    saveDraft(processCode: string, batchNo: string, data: Record<string, unknown>, userId: number): Promise<ProcessDynamicRecord>;
    submit(processCode: string, batchNo: string, data: Record<string, unknown>, userId: number): Promise<ProcessDynamicRecord>;
}
