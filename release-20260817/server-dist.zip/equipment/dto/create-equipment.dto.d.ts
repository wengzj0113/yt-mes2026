export declare class CreateEquipmentDto {
    equipmentCode: string;
    equipmentName: string;
    model?: string;
    departmentCode?: string;
}
