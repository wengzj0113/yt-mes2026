export declare class UpdateEquipmentDto {
    equipmentName?: string;
    model?: string;
    departmentCode?: string;
    isActive?: boolean;
}
