"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Equipment = void 0;
const typeorm_1 = require("typeorm");
let Equipment = class Equipment {
    constructor() {
        this.isActive = true;
    }
};
exports.Equipment = Equipment;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], Equipment.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'equipment_code', length: 50, unique: true }),
    __metadata("design:type", String)
], Equipment.prototype, "equipmentCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'equipment_name', length: 100 }),
    __metadata("design:type", String)
], Equipment.prototype, "equipmentName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'model', type: 'nvarchar', length: 50, nullable: true }),
    __metadata("design:type", Object)
], Equipment.prototype, "model", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'department_code', type: 'nvarchar', length: 50, nullable: true }),
    __metadata("design:type", Object)
], Equipment.prototype, "departmentCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'is_active', default: true }),
    __metadata("design:type", Boolean)
], Equipment.prototype, "isActive", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], Equipment.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], Equipment.prototype, "updatedAt", void 0);
exports.Equipment = Equipment = __decorate([
    (0, typeorm_1.Entity)('sys_equipment')
], Equipment);
//# sourceMappingURL=equipment.entity.js.map