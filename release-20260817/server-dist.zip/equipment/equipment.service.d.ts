import { Repository } from 'typeorm';
import { Equipment } from './equipment.entity';
export declare class EquipmentService {
    private readonly equipmentRepo;
    constructor(equipmentRepo: Repository<Equipment>);
    findAll(): Promise<Equipment[]>;
    create(dto: any): Promise<Equipment>;
    update(id: number, dto: any): Promise<Equipment>;
    remove(id: number): Promise<void>;
}
