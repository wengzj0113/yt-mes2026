export declare class EquipmentModule {
}
