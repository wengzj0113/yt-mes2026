export declare class Equipment {
    id: number;
    equipmentCode: string;
    equipmentName: string;
    model: string | null;
    departmentCode: string | null;
    isActive: boolean;
    createdAt: Date;
    updatedAt: Date;
}
