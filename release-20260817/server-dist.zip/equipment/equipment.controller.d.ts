import { EquipmentService } from './equipment.service';
import { CreateEquipmentDto } from './dto/create-equipment.dto';
import { UpdateEquipmentDto } from './dto/update-equipment.dto';
export declare class EquipmentController {
    private readonly equipmentService;
    constructor(equipmentService: EquipmentService);
    findAll(): Promise<{
        data: import("./equipment.entity").Equipment[];
    }>;
    create(dto: CreateEquipmentDto): Promise<{
        data: import("./equipment.entity").Equipment;
        message: string;
    }>;
    update(id: number, dto: UpdateEquipmentDto): Promise<{
        data: import("./equipment.entity").Equipment;
        message: string;
    }>;
    remove(id: number): Promise<{
        message: string;
    }>;
}
