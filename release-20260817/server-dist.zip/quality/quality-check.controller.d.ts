import { QualityCheckService } from './quality-check.service';
import { CreateQualityCheckDto } from './dto/create-quality-check.dto';
import { JwtPayload } from '../common/decorators/current-user.decorator';
export declare class QualityCheckController {
    private readonly qualityCheckService;
    constructor(qualityCheckService: QualityCheckService);
    create(batchNo: string, dto: CreateQualityCheckDto, user: JwtPayload): Promise<{
        data: import("./quality-check.entity").QualityCheck;
        message: string;
    }>;
    findAll(batchNo: string): Promise<{
        data: import("./quality-check.entity").QualityCheck[];
    }>;
}
