export declare class QueryQualityDto {
    batchNo?: string;
    processType?: string;
    inspectionResult?: number;
    inspectorName?: string;
    startDate?: string;
    endDate?: string;
    page?: number;
    pageSize?: number;
}
