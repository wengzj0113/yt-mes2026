export declare class CreateQualityCheckDto {
    batchNo?: string;
    processType: string;
    inspectionResult: number;
    defectQty?: number;
    defectReason?: string;
    inspectorName: string;
    abnormalRecord?: string;
}
