export declare class QualityCheckModule {
}
