import { Repository } from 'typeorm';
import { QualityCheck } from './quality-check.entity';
import { Batch } from '../batch/batch.entity';
import { BatchStatusLog } from '../batch/batch-status-log.entity';
import { CreateQualityCheckDto } from './dto/create-quality-check.dto';
import { QueryQualityDto } from './dto/query-quality.dto';
import { CellBarcode } from '../cells/cell-barcode.entity';
export declare class QualityCheckService {
    private readonly repo;
    private readonly batchRepo;
    private readonly statusLogRepo;
    private readonly cellBarcodeRepo;
    constructor(repo: Repository<QualityCheck>, batchRepo: Repository<Batch>, statusLogRepo: Repository<BatchStatusLog>, cellBarcodeRepo: Repository<CellBarcode>);
    private validateBatchExists;
    create(dto: CreateQualityCheckDto, userId: number): Promise<QualityCheck>;
    inspect(dto: CreateQualityCheckDto, userId: number): Promise<QualityCheck>;
    private handleQualityIssue;
    findAllPaginated(filters: QueryQualityDto): Promise<{
        items: QualityCheck[];
        total: number;
        page: number;
        pageSize: number;
    }>;
    findPendingQuality(batchNo?: string): Promise<any[]>;
    findOne(id: number): Promise<QualityCheck>;
    findAll(batchNo: string): Promise<QualityCheck[]>;
    update(id: number, dto: Partial<CreateQualityCheckDto>, userId: number): Promise<QualityCheck>;
    remove(id: number): Promise<void>;
    getQualityTrends(): Promise<{
        batchNo: string;
        passRate: number | null;
    }[]>;
}
