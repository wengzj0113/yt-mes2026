export declare const VALID_PROCESS_TYPES: readonly ["batching", "coating", "roller-pressing", "slitting", "electrode", "winding", "assembly", "baking", "injection", "wrapping", "casing", "integrated-machine", "laser-welding", "formation-grading", "formation", "grading", "sorting"];
export declare class QualityCheck {
    id: number;
    batchNo: string;
    processType: string;
    inspectionResult: number;
    defectQty: number | null;
    defectReason: string | null;
    inspectorName: string;
    abnormalRecord: string | null;
    createdBy: number;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date | null;
}
