"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QualityCheck = exports.VALID_PROCESS_TYPES = void 0;
const typeorm_1 = require("typeorm");
exports.VALID_PROCESS_TYPES = [
    'batching', 'coating', 'roller-pressing', 'slitting', 'electrode',
    'winding', 'assembly', 'baking', 'injection', 'wrapping',
    'casing', 'integrated-machine', 'laser-welding', 'formation-grading',
    'formation', 'grading', 'sorting',
];
let QualityCheck = class QualityCheck {
};
exports.QualityCheck = QualityCheck;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], QualityCheck.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'batch_no', length: 16 }),
    __metadata("design:type", String)
], QualityCheck.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'process_type', length: 32 }),
    __metadata("design:type", String)
], QualityCheck.prototype, "processType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'inspection_result', type: 'tinyint' }),
    __metadata("design:type", Number)
], QualityCheck.prototype, "inspectionResult", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'defect_qty', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], QualityCheck.prototype, "defectQty", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'defect_reason', type: 'nvarchar', length: 512, nullable: true }),
    __metadata("design:type", Object)
], QualityCheck.prototype, "defectReason", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'inspector_name', length: 32 }),
    __metadata("design:type", String)
], QualityCheck.prototype, "inspectorName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'abnormal_record', type: 'nvarchar', length: 512, nullable: true }),
    __metadata("design:type", Object)
], QualityCheck.prototype, "abnormalRecord", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'created_by', type: 'int' }),
    __metadata("design:type", Number)
], QualityCheck.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], QualityCheck.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'updated_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], QualityCheck.prototype, "updatedBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Object)
], QualityCheck.prototype, "updatedAt", void 0);
exports.QualityCheck = QualityCheck = __decorate([
    (0, typeorm_1.Entity)('quality_check')
], QualityCheck);
//# sourceMappingURL=quality-check.entity.js.map