import { QualityCheckService } from './quality-check.service';
import { CreateQualityCheckDto } from './dto/create-quality-check.dto';
import { QueryQualityDto } from './dto/query-quality.dto';
import { JwtPayload } from '../common/decorators/current-user.decorator';
export declare class QualityController {
    private readonly qualityCheckService;
    constructor(qualityCheckService: QualityCheckService);
    getQualityTrends(): Promise<{
        data: {
            batchNo: string;
            passRate: number | null;
        }[];
    }>;
    findAllPaginated(filters: QueryQualityDto): Promise<{
        data: {
            items: import("./quality-check.entity").QualityCheck[];
            total: number;
            page: number;
            pageSize: number;
        };
    }>;
    findPending(batchNo?: string): Promise<{
        data: any[];
    }>;
    findOne(id: string): Promise<{
        data: import("./quality-check.entity").QualityCheck;
    }>;
    inspect(dto: CreateQualityCheckDto, user: JwtPayload): Promise<{
        data: import("./quality-check.entity").QualityCheck;
        message: string;
    }>;
    update(id: string, dto: Partial<CreateQualityCheckDto>, user: JwtPayload): Promise<{
        data: import("./quality-check.entity").QualityCheck;
        message: string;
    }>;
    remove(id: string): Promise<{
        message: string;
    }>;
}
