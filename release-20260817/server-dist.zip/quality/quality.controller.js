"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QualityController = void 0;
const common_1 = require("@nestjs/common");
const quality_check_service_1 = require("./quality-check.service");
const create_quality_check_dto_1 = require("./dto/create-quality-check.dto");
const query_quality_dto_1 = require("./dto/query-quality.dto");
const roles_decorator_1 = require("../common/decorators/roles.decorator");
const user_entity_1 = require("../user/user.entity");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
let QualityController = class QualityController {
    constructor(qualityCheckService) {
        this.qualityCheckService = qualityCheckService;
    }
    async getQualityTrends() {
        const trends = await this.qualityCheckService.getQualityTrends();
        return { data: trends };
    }
    async findAllPaginated(filters) {
        const result = await this.qualityCheckService.findAllPaginated(filters);
        return { data: result };
    }
    async findPending(batchNo) {
        const items = await this.qualityCheckService.findPendingQuality(batchNo);
        return { data: items };
    }
    async findOne(id) {
        const record = await this.qualityCheckService.findOne(+id);
        return { data: record };
    }
    async inspect(dto, user) {
        const record = await this.qualityCheckService.inspect(dto, user.sub);
        return { data: record, message: '质检成功' };
    }
    async update(id, dto, user) {
        const record = await this.qualityCheckService.update(+id, dto, user.sub);
        return { data: record, message: '更新成功' };
    }
    async remove(id) {
        await this.qualityCheckService.remove(+id);
        return { message: '删除成功' };
    }
};
exports.QualityController = QualityController;
__decorate([
    (0, common_1.Get)('trends'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], QualityController.prototype, "getQualityTrends", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_quality_dto_1.QueryQualityDto]),
    __metadata("design:returntype", Promise)
], QualityController.prototype, "findAllPaginated", null);
__decorate([
    (0, common_1.Get)('pending'),
    __param(0, (0, common_1.Query)('batchNo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], QualityController.prototype, "findPending", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], QualityController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)('inspect'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.QUALITY, user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_quality_check_dto_1.CreateQualityCheckDto, Object]),
    __metadata("design:returntype", Promise)
], QualityController.prototype, "inspect", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.QUALITY, user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], QualityController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], QualityController.prototype, "remove", null);
exports.QualityController = QualityController = __decorate([
    (0, common_1.Controller)('quality'),
    __metadata("design:paramtypes", [quality_check_service_1.QualityCheckService])
], QualityController);
//# sourceMappingURL=quality.controller.js.map