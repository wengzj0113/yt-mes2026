"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QualityCheckService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const quality_check_entity_1 = require("./quality-check.entity");
const batch_entity_1 = require("../batch/batch.entity");
const batch_status_log_entity_1 = require("../batch/batch-status-log.entity");
const cell_barcode_entity_1 = require("../cells/cell-barcode.entity");
const process_baseline_1 = require("../master-data/process-baseline");
let QualityCheckService = class QualityCheckService {
    constructor(repo, batchRepo, statusLogRepo, cellBarcodeRepo) {
        this.repo = repo;
        this.batchRepo = batchRepo;
        this.statusLogRepo = statusLogRepo;
        this.cellBarcodeRepo = cellBarcodeRepo;
    }
    async validateBatchExists(batchNo) {
        const batch = await this.batchRepo.findOne({ where: { batchNo } });
        if (!batch) {
            throw new common_1.NotFoundException({ code: 'BATCH_NOT_FOUND', message: `批次 ${batchNo} 不存在` });
        }
        return batch;
    }
    async create(dto, userId) {
        if (!dto.batchNo) {
            throw new common_1.BadRequestException({ code: 'VALIDATION_ERROR', message: '批次号不能为空' });
        }
        await this.validateBatchExists(dto.batchNo);
        if (!quality_check_entity_1.VALID_PROCESS_TYPES.includes(dto.processType)) {
            throw new common_1.BadRequestException({ code: 'VALIDATION_ERROR', message: `无效的工序类型: ${dto.processType}` });
        }
        if (dto.inspectionResult !== 1 && dto.inspectionResult !== 2) {
            throw new common_1.BadRequestException({ code: 'VALIDATION_ERROR', message: '检验结果只能为 1(合格) 或 2(不合格)' });
        }
        let defectQty = null;
        let defectReason = null;
        if (dto.inspectionResult === 2) {
            if (dto.defectQty === undefined || dto.defectQty === null) {
                throw new common_1.BadRequestException({ code: 'VALIDATION_ERROR', message: '不合格必须填写缺陷数量' });
            }
            if (!dto.defectReason) {
                throw new common_1.BadRequestException({ code: 'VALIDATION_ERROR', message: '不合格必须填写缺陷原因' });
            }
            defectQty = dto.defectQty;
            defectReason = dto.defectReason;
        }
        const record = this.repo.create({
            batchNo: dto.batchNo,
            processType: dto.processType,
            inspectionResult: dto.inspectionResult,
            defectQty,
            defectReason,
            inspectorName: dto.inspectorName,
            abnormalRecord: dto.abnormalRecord || null,
            createdBy: userId,
        });
        return this.repo.save(record);
    }
    async inspect(dto, userId) {
        const record = await this.create(dto, userId);
        if (dto.inspectionResult === 2 && dto.batchNo) {
            await this.handleQualityIssue(dto.batchNo, userId);
        }
        return record;
    }
    async handleQualityIssue(batchNo, userId) {
        const batch = await this.batchRepo.findOne({ where: { batchNo } });
        if (batch && batch.status === batch_entity_1.BatchStatus.IN_PROGRESS) {
            batch.status = batch_entity_1.BatchStatus.QUALITY_ISSUE;
            await this.batchRepo.save(batch);
            await this.statusLogRepo.save(this.statusLogRepo.create({
                batchNo,
                fromStatus: batch_entity_1.BatchStatus.IN_PROGRESS,
                toStatus: batch_entity_1.BatchStatus.QUALITY_ISSUE,
                changeReason: '质检不合格',
                changedBy: userId,
            }));
        }
    }
    async findAllPaginated(filters) {
        const { batchNo, processType, inspectionResult, inspectorName, startDate, endDate, page = 1, pageSize = 20 } = filters;
        const where = {};
        if (batchNo)
            where.batchNo = (0, typeorm_2.Like)(`%${batchNo}%`);
        if (processType)
            where.processType = processType;
        if (inspectionResult)
            where.inspectionResult = inspectionResult;
        if (inspectorName)
            where.inspectorName = (0, typeorm_2.Like)(`%${inspectorName}%`);
        if (startDate && endDate) {
            where.createdAt = (0, typeorm_2.Between)(new Date(startDate), new Date(endDate + 'T23:59:59'));
        }
        const [items, total] = await this.repo.findAndCount({
            where,
            order: { createdAt: 'DESC' },
            skip: (page - 1) * pageSize,
            take: pageSize,
        });
        return { items, total, page, pageSize };
    }
    async findPendingQuality(batchNo) {
        const processTables = [
            'batching', 'coating', 'roller_pressing', 'slitting', 'electrode',
            'winding', 'assembly', 'baking', 'injection', 'wrapping',
            'formation', 'grading', 'sorting',
        ];
        const processNames = {
            batching: '配料', coating: '涂布', roller_pressing: '辊压', slitting: '分切',
            electrode: '制片', winding: '卷绕', assembly: '装配', baking: '烘烤',
            injection: '注液', wrapping: '顶封', formation: '化成', grading: '分容', sorting: '分选',
        };
        const batchNoFilter = batchNo ? `AND p.batch_no LIKE '%${batchNo.replace(/'/g, "''")}%'` : '';
        const queries = processTables.map(table => {
            return `SELECT '${table}' as processType, p.batch_no as batchNo, p.operator_name as operatorName, p.updated_at as submittedAt
              FROM ${table}_record p
              WHERE p.is_draft = 0 AND p.record_status = 1
              AND NOT EXISTS (SELECT 1 FROM quality_check q WHERE q.batch_no = p.batch_no AND q.process_type = '${table}')
              ${batchNoFilter}`;
        });
        queries.push(`SELECT p.process_code as processType, p.batch_no as batchNo,
                         JSON_VALUE(p.extra_data, '$.operatorName') as operatorName, p.updated_at as submittedAt
                  FROM process_dynamic_record p
                  WHERE p.is_draft = 0 AND p.record_status = 1
                  AND NOT EXISTS (SELECT 1 FROM quality_check q WHERE q.batch_no = p.batch_no AND q.process_type = p.process_code)
                  ${batchNo ? `AND p.batch_no LIKE '%${batchNo.replace(/'/g, "''")}%'` : ''}`);
        for (const item of process_baseline_1.PROCESS_BASELINE)
            processNames[item.processCode] = item.processName;
        const results = await this.repo.query(queries.join('\nUNION ALL\n'));
        return results.map(r => ({
            processType: r.processType,
            processName: processNames[r.processType] || r.processType,
            batchNo: r.batchNo,
            operatorName: r.operatorName,
            submittedAt: r.submittedAt ? new Date(r.submittedAt).toISOString() : null,
        }));
    }
    async findOne(id) {
        const record = await this.repo.findOne({ where: { id } });
        if (!record) {
            throw new common_1.NotFoundException({ code: 'QUALITY_NOT_FOUND', message: '质检记录不存在' });
        }
        return record;
    }
    async findAll(batchNo) {
        return this.repo.find({ where: { batchNo }, order: { createdAt: 'DESC' } });
    }
    async update(id, dto, userId) {
        const record = await this.findOne(id);
        if (dto.processType !== undefined)
            record.processType = dto.processType;
        if (dto.inspectionResult !== undefined)
            record.inspectionResult = dto.inspectionResult;
        if (dto.defectQty !== undefined)
            record.defectQty = dto.defectQty;
        if (dto.defectReason !== undefined)
            record.defectReason = dto.defectReason;
        if (dto.inspectorName !== undefined)
            record.inspectorName = dto.inspectorName;
        if (dto.abnormalRecord !== undefined)
            record.abnormalRecord = dto.abnormalRecord;
        record.updatedBy = userId;
        return this.repo.save(record);
    }
    async remove(id) {
        const record = await this.findOne(id);
        await this.repo.remove(record);
    }
    async getQualityTrends() {
        const batches = await this.batchRepo.find({
            order: { createdAt: 'DESC' },
            take: 10,
        });
        if (batches.length === 0)
            return [];
        const batchNos = batches.map((b) => b.batchNo);
        const results = await this.cellBarcodeRepo
            .createQueryBuilder('cb')
            .select('cb.batchNo', 'batchNo')
            .addSelect('COUNT(*)', 'total')
            .addSelect('SUM(CASE WHEN cb.grade = \'A\' THEN 1 ELSE 0 END)', 'passed')
            .where('cb.batchNo IN (:...batchNos)', { batchNos })
            .groupBy('cb.batchNo')
            .getRawMany();
        const resultMap = new Map(results.map((r) => [r.batchNo, r]));
        return batches.reverse().map((batch) => {
            const row = resultMap.get(batch.batchNo);
            const total = row ? Number(row.total) : 0;
            const passed = row ? Number(row.passed) : 0;
            const rate = total > 0 ? (passed / total) * 100 : null;
            return {
                batchNo: batch.batchNo,
                passRate: rate !== null ? parseFloat(rate.toFixed(1)) : null,
            };
        });
    }
};
exports.QualityCheckService = QualityCheckService;
exports.QualityCheckService = QualityCheckService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(quality_check_entity_1.QualityCheck)),
    __param(1, (0, typeorm_1.InjectRepository)(batch_entity_1.Batch)),
    __param(2, (0, typeorm_1.InjectRepository)(batch_status_log_entity_1.BatchStatusLog)),
    __param(3, (0, typeorm_1.InjectRepository)(cell_barcode_entity_1.CellBarcode)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], QualityCheckService);
//# sourceMappingURL=quality-check.service.js.map