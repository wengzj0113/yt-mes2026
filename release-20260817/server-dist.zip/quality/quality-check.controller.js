"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QualityCheckController = void 0;
const common_1 = require("@nestjs/common");
const quality_check_service_1 = require("./quality-check.service");
const create_quality_check_dto_1 = require("./dto/create-quality-check.dto");
const roles_decorator_1 = require("../common/decorators/roles.decorator");
const user_entity_1 = require("../user/user.entity");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
let QualityCheckController = class QualityCheckController {
    constructor(qualityCheckService) {
        this.qualityCheckService = qualityCheckService;
    }
    async create(batchNo, dto, user) {
        dto.batchNo = batchNo;
        const record = await this.qualityCheckService.create(dto, user.sub);
        return { data: record, message: '创建成功' };
    }
    async findAll(batchNo) {
        const records = await this.qualityCheckService.findAll(batchNo);
        return { data: records };
    }
};
exports.QualityCheckController = QualityCheckController;
__decorate([
    (0, common_1.Post)(),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.QUALITY, user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('batchNo')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_quality_check_dto_1.CreateQualityCheckDto, Object]),
    __metadata("design:returntype", Promise)
], QualityCheckController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Param)('batchNo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], QualityCheckController.prototype, "findAll", null);
exports.QualityCheckController = QualityCheckController = __decorate([
    (0, common_1.Controller)('batches/:batchNo/quality-checks'),
    __metadata("design:paramtypes", [quality_check_service_1.QualityCheckService])
], QualityCheckController);
//# sourceMappingURL=quality-check.controller.js.map