"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DashboardService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const rxjs_1 = require("rxjs");
const cell_barcode_entity_1 = require("../cells/cell-barcode.entity");
const batch_entity_1 = require("../batch/batch.entity");
let DashboardService = class DashboardService {
    constructor(cellBarcodeRepo, batchRepo) {
        this.cellBarcodeRepo = cellBarcodeRepo;
        this.batchRepo = batchRepo;
    }
    async fetchRealMetrics() {
        const [totalCells, batches, todayCells, todayPassCells] = await Promise.all([
            this.cellBarcodeRepo.count(),
            this.batchRepo.find({ order: { createdAt: 'DESC' }, take: 10 }),
            this.cellBarcodeRepo.count({
                where: { createdAt: (0, typeorm_2.MoreThanOrEqual)(new Date(new Date().setHours(0, 0, 0, 0))) },
            }),
            this.cellBarcodeRepo.count({
                where: {
                    createdAt: (0, typeorm_2.MoreThanOrEqual)(new Date(new Date().setHours(0, 0, 0, 0))),
                    grade: 'A',
                },
            }),
        ]);
        const totalBatches = await this.batchRepo.count();
        const batchesWithBarcodes = await this.batchRepo
            .createQueryBuilder('batch')
            .innerJoin('cell_barcode', 'cb', 'cb.batchNo = batch.batchNo')
            .select('COUNT(DISTINCT batch.batchNo)', 'count')
            .getRawOne();
        const coverageRate = totalBatches > 0
            ? (Number(batchesWithBarcodes?.count ?? 0) / totalBatches) * 100
            : 0;
        const goodRate = todayCells > 0 ? (todayPassCells / todayCells) * 100 : 0;
        return {
            topMetrics: {
                totalCells,
                coverageRate: parseFloat(coverageRate.toFixed(1)),
                goodRate: parseFloat(goodRate.toFixed(1)),
            },
            processes: [
                { name: '配料', wip: 0 }, { name: '涂布', wip: 0 },
                { name: '辊压', wip: 0 }, { name: '分切', wip: 0 },
                { name: '制片', wip: 0 }, { name: '卷绕', wip: 0 },
                { name: '装配', wip: 0 }, { name: '烘烤', wip: 0 },
                { name: '注液', wip: 0 }, { name: '顶封', wip: 0 },
                { name: '化成', wip: 0 }, { name: '分容', wip: 0 },
                { name: '分选', wip: 0 },
            ],
            sorterLogs: [
                ['C001', '3.95V', '21.5mΩ', 'A档'],
                ['C002', '3.96V', '21.6mΩ', 'A档'],
                ['C003', '3.92V', '22.1mΩ', 'B档'],
            ],
        };
    }
    getStreamData() {
        return (0, rxjs_1.interval)(30000).pipe((0, rxjs_1.startWith)(0), (0, rxjs_1.switchMap)(() => (0, rxjs_1.from)(this.fetchRealMetrics())), (0, rxjs_1.map)((data) => ({ data })));
    }
};
exports.DashboardService = DashboardService;
exports.DashboardService = DashboardService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(cell_barcode_entity_1.CellBarcode)),
    __param(1, (0, typeorm_1.InjectRepository)(batch_entity_1.Batch)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], DashboardService);
//# sourceMappingURL=dashboard.service.js.map