import { Repository } from 'typeorm';
import { Observable } from 'rxjs';
import { CellBarcode } from '../cells/cell-barcode.entity';
import { Batch } from '../batch/batch.entity';
export declare class DashboardService {
    private readonly cellBarcodeRepo;
    private readonly batchRepo;
    constructor(cellBarcodeRepo: Repository<CellBarcode>, batchRepo: Repository<Batch>);
    fetchRealMetrics(): Promise<{
        topMetrics: {
            totalCells: number;
            coverageRate: number;
            goodRate: number;
        };
        processes: {
            name: string;
            wip: number;
        }[];
        sorterLogs: string[][];
    }>;
    getStreamData(): Observable<any>;
}
