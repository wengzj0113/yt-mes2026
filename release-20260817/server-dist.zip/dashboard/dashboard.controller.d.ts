import { MessageEvent } from '@nestjs/common';
import { Observable } from 'rxjs';
import { DashboardService } from './dashboard.service';
export declare class DashboardController {
    private readonly dashboardService;
    constructor(dashboardService: DashboardService);
    stream(): Observable<MessageEvent>;
}
