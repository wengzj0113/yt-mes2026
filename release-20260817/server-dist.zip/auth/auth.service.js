"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const config_1 = require("@nestjs/config");
const bcrypt = require("bcrypt");
const user_service_1 = require("../user/user.service");
let AuthService = class AuthService {
    constructor(userService, jwtService, configService) {
        this.userService = userService;
        this.jwtService = jwtService;
        this.configService = configService;
    }
    async login(dto) {
        const user = await this.userService.findByUsername(dto.username);
        if (!user) {
            throw new common_1.UnauthorizedException({ code: 'USER_NOT_FOUND', message: '用户不存在' });
        }
        if (!user.isActive) {
            throw new common_1.UnauthorizedException({ code: 'USER_DISABLED', message: '账号已被禁用' });
        }
        if (user.lockedUntil && user.lockedUntil > new Date()) {
            throw new common_1.UnauthorizedException({ code: 'USER_LOCKED', message: '账号已被锁定，请稍后再试' });
        }
        const isBcryptHash = typeof user.password === 'string' && /^\$2[aby]\$\d+\$/.test(user.password);
        const valid = isBcryptHash
            ? await bcrypt.compare(dto.password, user.password)
            : dto.password === user.password;
        if (!valid) {
            user.loginAttempts += 1;
            if (user.loginAttempts >= 5) {
                user.lockedUntil = new Date(Date.now() + 15 * 60 * 1000);
            }
            await this.userService['userRepo'].save(user);
            throw new common_1.UnauthorizedException({ code: 'USER_PASSWORD_ERROR', message: '密码错误' });
        }
        if (!isBcryptHash) {
            user.password = await bcrypt.hash(dto.password, 12);
            await this.userService['userRepo'].save(user);
        }
        if (user.loginAttempts > 0) {
            user.loginAttempts = 0;
            user.lockedUntil = null;
            await this.userService['userRepo'].save(user);
        }
        const payload = {
            sub: user.id,
            username: user.username,
            realName: user.realName,
            roleCode: user.roleCode,
        };
        const accessToken = this.jwtService.sign(payload);
        const refreshToken = this.jwtService.sign(payload, {
            secret: this.getRefreshSecret(),
            expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '604800s',
        });
        return {
            data: {
                accessToken,
                refreshToken,
                user: {
                    id: user.id,
                    username: user.username,
                    realName: user.realName,
                    roleCode: user.roleCode,
                },
            },
        };
    }
    async refresh(refreshToken) {
        try {
            const payload = this.jwtService.verify(refreshToken, {
                secret: this.getRefreshSecret(),
            });
            const user = await this.userService.findById(payload.sub);
            if (!user || !user.isActive) {
                throw new common_1.UnauthorizedException({ code: 'UNAUTHORIZED', message: 'Token 无效' });
            }
            const newPayload = { sub: user.id, username: user.username, realName: user.realName, roleCode: user.roleCode };
            const accessToken = this.jwtService.sign(newPayload);
            return { data: { accessToken } };
        }
        catch {
            throw new common_1.UnauthorizedException({ code: 'UNAUTHORIZED', message: 'Refresh Token 已过期' });
        }
    }
    async logout(userId) {
        return { data: { message: '登出成功' } };
    }
    async changePassword(userId, dto) {
        const user = await this.userService.findById(userId);
        if (!user) {
            throw new common_1.BadRequestException('用户不存在');
        }
        const valid = await bcrypt.compare(dto.oldPassword, user.password);
        if (!valid) {
            throw new common_1.BadRequestException('旧密码错误');
        }
        const salt = await bcrypt.genSalt(12);
        const hashedPassword = await bcrypt.hash(dto.newPassword, salt);
        await this.userService.updatePassword(userId, hashedPassword);
        return { message: '密码修改成功' };
    }
    getRefreshSecret() {
        const secret = this.configService.get('JWT_REFRESH_SECRET');
        if (!secret) {
            throw new Error('JWT_REFRESH_SECRET environment variable is required');
        }
        return secret;
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [user_service_1.UserService,
        jwt_1.JwtService,
        config_1.ConfigService])
], AuthService);
//# sourceMappingURL=auth.service.js.map