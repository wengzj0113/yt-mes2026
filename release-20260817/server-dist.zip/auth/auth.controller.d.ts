import { Request } from 'express';
import { AuthService } from './auth.service';
import { LoginDto } from './dto/login.dto';
import { ChangePasswordDto } from './dto/change-password.dto';
export declare class AuthController {
    private readonly authService;
    constructor(authService: AuthService);
    login(dto: LoginDto): Promise<{
        data: {
            accessToken: string;
            refreshToken: string;
            user: {
                id: number;
                username: string;
                realName: string;
                roleCode: number;
            };
        };
    }>;
    refresh(refreshToken: string): Promise<{
        data: {
            accessToken: string;
        };
    }>;
    logout(req: Request): Promise<{
        data: {
            message: string;
        };
    }>;
    changePassword(req: Request, dto: ChangePasswordDto): Promise<{
        message: string;
    }>;
}
