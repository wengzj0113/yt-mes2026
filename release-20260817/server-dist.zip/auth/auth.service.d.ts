import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { UserService } from '../user/user.service';
import { LoginDto } from './dto/login.dto';
export declare class AuthService {
    private readonly userService;
    private readonly jwtService;
    private readonly configService;
    constructor(userService: UserService, jwtService: JwtService, configService: ConfigService);
    login(dto: LoginDto): Promise<{
        data: {
            accessToken: string;
            refreshToken: string;
            user: {
                id: number;
                username: string;
                realName: string;
                roleCode: number;
            };
        };
    }>;
    refresh(refreshToken: string): Promise<{
        data: {
            accessToken: string;
        };
    }>;
    logout(userId: number): Promise<{
        data: {
            message: string;
        };
    }>;
    changePassword(userId: number, dto: any): Promise<{
        message: string;
    }>;
    private getRefreshSecret;
}
