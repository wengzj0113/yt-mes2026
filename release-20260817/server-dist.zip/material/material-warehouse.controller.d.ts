import { MaterialWarehouseService } from './material-warehouse.service';
import { CreateMaterialDto } from './dto/create-material.dto';
import { JwtPayload } from '../common/decorators/current-user.decorator';
export declare class MaterialWarehouseController {
    private readonly materialWarehouseService;
    constructor(materialWarehouseService: MaterialWarehouseService);
    create(batchNo: string, dto: CreateMaterialDto, user: JwtPayload): Promise<{
        data: import("./material-warehouse.entity").MaterialWarehouse;
        message: string;
    }>;
    findAll(batchNo: string): Promise<{
        data: import("./material-warehouse.entity").MaterialWarehouse[];
    }>;
    findAvailable(batchNo: string, type: string): Promise<{
        data: {
            label: string;
            value: string;
            quantity: number;
            unit: string;
        }[];
    }>;
}
