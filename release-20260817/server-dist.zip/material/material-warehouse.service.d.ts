import { Repository } from 'typeorm';
import { MaterialWarehouse } from './material-warehouse.entity';
import { Batch } from '../batch/batch.entity';
import { CreateMaterialDto } from './dto/create-material.dto';
export declare class MaterialWarehouseService {
    private readonly repo;
    private readonly batchRepo;
    constructor(repo: Repository<MaterialWarehouse>, batchRepo: Repository<Batch>);
    private validateBatch;
    create(dto: CreateMaterialDto, userId: number): Promise<MaterialWarehouse>;
    findAll(batchNo: string): Promise<MaterialWarehouse[]>;
    findAvailable(batchNo: string, materialType: number): Promise<MaterialWarehouse[]>;
}
