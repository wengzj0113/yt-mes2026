"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialWarehouseController = void 0;
const common_1 = require("@nestjs/common");
const material_warehouse_service_1 = require("./material-warehouse.service");
const create_material_dto_1 = require("./dto/create-material.dto");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
let MaterialWarehouseController = class MaterialWarehouseController {
    constructor(materialWarehouseService) {
        this.materialWarehouseService = materialWarehouseService;
    }
    async create(batchNo, dto, user) {
        dto.batchNo = batchNo;
        const record = await this.materialWarehouseService.create(dto, user.sub);
        return { data: record, message: '录入成功' };
    }
    async findAll(batchNo) {
        const records = await this.materialWarehouseService.findAll(batchNo);
        return { data: records };
    }
    async findAvailable(batchNo, type) {
        const records = await this.materialWarehouseService.findAvailable(batchNo, Number(type));
        return {
            data: records.map((item) => ({
                label: item.supplierBatchNo,
                value: item.supplierBatchNo,
                quantity: item.quantity,
                unit: item.unit,
            })),
        };
    }
};
exports.MaterialWarehouseController = MaterialWarehouseController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Param)('batchNo')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_material_dto_1.CreateMaterialDto, Object]),
    __metadata("design:returntype", Promise)
], MaterialWarehouseController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Param)('batchNo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MaterialWarehouseController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('available'),
    __param(0, (0, common_1.Param)('batchNo')),
    __param(1, (0, common_1.Query)('type')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], MaterialWarehouseController.prototype, "findAvailable", null);
exports.MaterialWarehouseController = MaterialWarehouseController = __decorate([
    (0, common_1.Controller)('batches/:batchNo/materials'),
    __metadata("design:paramtypes", [material_warehouse_service_1.MaterialWarehouseService])
], MaterialWarehouseController);
//# sourceMappingURL=material-warehouse.controller.js.map