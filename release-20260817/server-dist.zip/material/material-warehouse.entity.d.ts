export declare enum MaterialType {
    POSITIVE = 1,
    NEGATIVE = 2,
    ELECTROLYTE = 3,
    SEPARATOR = 4,
    SHELL_CAP = 5
}
export declare enum MaterialStatus {
    QUALIFIED = 1,
    UNQUALIFIED = 2
}
export declare class MaterialWarehouse {
    id: number;
    batchNo: string;
    materialType: number;
    supplierBatchNo: string;
    status: number;
    warehousePerson: string;
    quantity: number;
    unit: string;
    createdBy: number;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date | null;
}
