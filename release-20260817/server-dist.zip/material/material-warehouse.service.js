"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialWarehouseService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const material_warehouse_entity_1 = require("./material-warehouse.entity");
const batch_entity_1 = require("../batch/batch.entity");
const UNIT_MAP = {
    [material_warehouse_entity_1.MaterialType.POSITIVE]: 'kg',
    [material_warehouse_entity_1.MaterialType.NEGATIVE]: 'kg',
    [material_warehouse_entity_1.MaterialType.ELECTROLYTE]: 'kg',
    [material_warehouse_entity_1.MaterialType.SEPARATOR]: '卷',
    [material_warehouse_entity_1.MaterialType.SHELL_CAP]: '个',
};
let MaterialWarehouseService = class MaterialWarehouseService {
    constructor(repo, batchRepo) {
        this.repo = repo;
        this.batchRepo = batchRepo;
    }
    async validateBatch(batchNo) {
        const batch = await this.batchRepo.findOne({ where: { batchNo } });
        if (!batch) {
            throw new common_1.NotFoundException({ code: 'BATCH_NOT_FOUND', message: `批次 ${batchNo} 不存在` });
        }
        return batch;
    }
    async create(dto, userId) {
        if (!dto.batchNo) {
            throw new common_1.BadRequestException({ code: 'VALIDATION_ERROR', message: '批次号不能为空' });
        }
        await this.validateBatch(dto.batchNo);
        if (dto.materialType < 1 || dto.materialType > 5) {
            throw new common_1.BadRequestException({ code: 'VALIDATION_ERROR', message: '材料类型无效，必须为 1-5' });
        }
        if (dto.quantity <= 0) {
            throw new common_1.BadRequestException({ code: 'VALIDATION_ERROR', message: '数量必须大于 0' });
        }
        const record = this.repo.create({
            batchNo: dto.batchNo,
            materialType: dto.materialType,
            supplierBatchNo: dto.supplierBatchNo,
            warehousePerson: dto.warehousePerson,
            status: dto.status ?? material_warehouse_entity_1.MaterialStatus.QUALIFIED,
            quantity: dto.quantity,
            unit: dto.unit || UNIT_MAP[dto.materialType] || 'kg',
            createdBy: userId,
        });
        return this.repo.save(record);
    }
    async findAll(batchNo) {
        return this.repo.find({ where: { batchNo }, order: { createdAt: 'DESC' } });
    }
    async findAvailable(batchNo, materialType) {
        return this.repo.find({
            where: { batchNo, materialType, status: material_warehouse_entity_1.MaterialStatus.QUALIFIED },
        });
    }
};
exports.MaterialWarehouseService = MaterialWarehouseService;
exports.MaterialWarehouseService = MaterialWarehouseService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(material_warehouse_entity_1.MaterialWarehouse)),
    __param(1, (0, typeorm_1.InjectRepository)(batch_entity_1.Batch)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], MaterialWarehouseService);
//# sourceMappingURL=material-warehouse.service.js.map