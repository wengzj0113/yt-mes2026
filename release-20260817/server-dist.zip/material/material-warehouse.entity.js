"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialWarehouse = exports.MaterialStatus = exports.MaterialType = void 0;
const typeorm_1 = require("typeorm");
var MaterialType;
(function (MaterialType) {
    MaterialType[MaterialType["POSITIVE"] = 1] = "POSITIVE";
    MaterialType[MaterialType["NEGATIVE"] = 2] = "NEGATIVE";
    MaterialType[MaterialType["ELECTROLYTE"] = 3] = "ELECTROLYTE";
    MaterialType[MaterialType["SEPARATOR"] = 4] = "SEPARATOR";
    MaterialType[MaterialType["SHELL_CAP"] = 5] = "SHELL_CAP";
})(MaterialType || (exports.MaterialType = MaterialType = {}));
var MaterialStatus;
(function (MaterialStatus) {
    MaterialStatus[MaterialStatus["QUALIFIED"] = 1] = "QUALIFIED";
    MaterialStatus[MaterialStatus["UNQUALIFIED"] = 2] = "UNQUALIFIED";
})(MaterialStatus || (exports.MaterialStatus = MaterialStatus = {}));
let MaterialWarehouse = class MaterialWarehouse {
    constructor() {
        this.status = MaterialStatus.QUALIFIED;
        this.unit = 'kg';
    }
};
exports.MaterialWarehouse = MaterialWarehouse;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], MaterialWarehouse.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'batch_no', length: 16 }),
    __metadata("design:type", String)
], MaterialWarehouse.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'material_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], MaterialWarehouse.prototype, "materialType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'supplier_batch_no', length: 32 }),
    __metadata("design:type", String)
], MaterialWarehouse.prototype, "supplierBatchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: MaterialStatus.QUALIFIED }),
    __metadata("design:type", Number)
], MaterialWarehouse.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'warehouse_person', length: 32, nullable: true }),
    __metadata("design:type", String)
], MaterialWarehouse.prototype, "warehousePerson", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'quantity', type: 'decimal', precision: 12, scale: 3 }),
    __metadata("design:type", Number)
], MaterialWarehouse.prototype, "quantity", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'unit', length: 16, default: 'kg' }),
    __metadata("design:type", String)
], MaterialWarehouse.prototype, "unit", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'created_by', type: 'int' }),
    __metadata("design:type", Number)
], MaterialWarehouse.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], MaterialWarehouse.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'updated_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], MaterialWarehouse.prototype, "updatedBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Object)
], MaterialWarehouse.prototype, "updatedAt", void 0);
exports.MaterialWarehouse = MaterialWarehouse = __decorate([
    (0, typeorm_1.Entity)('material_warehouse')
], MaterialWarehouse);
//# sourceMappingURL=material-warehouse.entity.js.map