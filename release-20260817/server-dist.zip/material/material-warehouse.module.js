"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialWarehouseModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const material_warehouse_entity_1 = require("./material-warehouse.entity");
const material_warehouse_service_1 = require("./material-warehouse.service");
const material_warehouse_controller_1 = require("./material-warehouse.controller");
const batch_entity_1 = require("../batch/batch.entity");
let MaterialWarehouseModule = class MaterialWarehouseModule {
};
exports.MaterialWarehouseModule = MaterialWarehouseModule;
exports.MaterialWarehouseModule = MaterialWarehouseModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([material_warehouse_entity_1.MaterialWarehouse, batch_entity_1.Batch])],
        providers: [material_warehouse_service_1.MaterialWarehouseService],
        controllers: [material_warehouse_controller_1.MaterialWarehouseController],
    })
], MaterialWarehouseModule);
//# sourceMappingURL=material-warehouse.module.js.map