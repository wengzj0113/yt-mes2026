export declare class MaterialWarehouseModule {
}
