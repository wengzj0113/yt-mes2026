export declare class CreateMaterialDto {
    batchNo?: string;
    materialType: number;
    supplierBatchNo: string;
    warehousePerson: string;
    status?: number;
    quantity: number;
    unit?: string;
}
