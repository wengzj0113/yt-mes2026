export type ProcessFieldType = 'text' | 'number';
export interface ProcessFieldDefinition {
    group: string;
    key: string;
    label: string;
    unit?: string;
    type: ProcessFieldType;
    required: boolean;
    isSystem: boolean;
}
export interface ProcessBaselineItem {
    processCode: string;
    processName: string;
    sortOrder: number;
    isActive: boolean;
    fieldDefinitions: ProcessFieldDefinition[];
}
export declare function mergeFieldDefinitionsWithBaseline(existingJson: string | null | undefined, baselineFields: readonly {
    key: string;
}[]): Array<Record<string, unknown>>;
export declare function hasIncompatibleFieldDefinitions(existingJson: string | null | undefined, baselineFields: readonly ProcessFieldDefinition[]): boolean;
export declare const PROCESS_BASELINE: ProcessBaselineItem[];
export declare const OCV_PROCESS_FIELDS: ProcessFieldDefinition[];
export declare function getProcessBaseline(processCode: string): ProcessBaselineItem | undefined;
