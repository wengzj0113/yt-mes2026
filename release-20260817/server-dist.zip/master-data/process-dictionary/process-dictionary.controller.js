"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessDictionaryController = void 0;
const common_1 = require("@nestjs/common");
const process_dictionary_service_1 = require("./process-dictionary.service");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const user_entity_1 = require("../../user/user.entity");
let ProcessDictionaryController = class ProcessDictionaryController {
    constructor(processDictionaryService) {
        this.processDictionaryService = processDictionaryService;
    }
    async findAll(query) {
        const data = await this.processDictionaryService.findAll(query);
        return { success: true, data };
    }
    async findByCode(code) {
        const data = await this.processDictionaryService.findByCode(code);
        return { success: true, data };
    }
    async create(body) {
        const data = await this.processDictionaryService.create(body);
        return { success: true, data };
    }
    async update(id, body) {
        const data = await this.processDictionaryService.update(+id, body);
        return { success: true, data };
    }
    async remove(id) {
        await this.processDictionaryService.remove(+id);
        return { success: true, message: 'Deleted successfully' };
    }
};
exports.ProcessDictionaryController = ProcessDictionaryController;
__decorate([
    (0, common_1.Get)(),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ProcessDictionaryController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('code/:code'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.OPERATOR, user_entity_1.UserRole.QUALITY, user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('code')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ProcessDictionaryController.prototype, "findByCode", null);
__decorate([
    (0, common_1.Post)(),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ProcessDictionaryController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ProcessDictionaryController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ProcessDictionaryController.prototype, "remove", null);
exports.ProcessDictionaryController = ProcessDictionaryController = __decorate([
    (0, common_1.Controller)('process-dictionary'),
    __metadata("design:paramtypes", [process_dictionary_service_1.ProcessDictionaryService])
], ProcessDictionaryController);
//# sourceMappingURL=process-dictionary.controller.js.map