"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessDictionary = void 0;
const typeorm_1 = require("typeorm");
let ProcessDictionary = class ProcessDictionary {
};
exports.ProcessDictionary = ProcessDictionary;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], ProcessDictionary.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ unique: true, name: 'process_code' }),
    __metadata("design:type", String)
], ProcessDictionary.prototype, "processCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'process_name' }),
    __metadata("design:type", String)
], ProcessDictionary.prototype, "processName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'sort_order' }),
    __metadata("design:type", Number)
], ProcessDictionary.prototype, "sortOrder", void 0);
__decorate([
    (0, typeorm_1.Column)({ default: true, name: 'is_active' }),
    __metadata("design:type", Boolean)
], ProcessDictionary.prototype, "isActive", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true, name: 'description' }),
    __metadata("design:type", String)
], ProcessDictionary.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'nvarchar', length: 'max', nullable: true, name: 'field_definitions' }),
    __metadata("design:type", String)
], ProcessDictionary.prototype, "fieldDefinitions", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], ProcessDictionary.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], ProcessDictionary.prototype, "updatedAt", void 0);
exports.ProcessDictionary = ProcessDictionary = __decorate([
    (0, typeorm_1.Entity)('process_dictionary')
], ProcessDictionary);
//# sourceMappingURL=process-dictionary.entity.js.map