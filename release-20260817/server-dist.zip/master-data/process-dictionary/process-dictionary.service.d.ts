import { OnModuleInit } from '@nestjs/common';
import { Repository, DataSource } from 'typeorm';
import { ProcessDictionary } from './process-dictionary.entity';
export declare class ProcessDictionaryService implements OnModuleInit {
    private readonly processDictRepo;
    private readonly dataSource;
    constructor(processDictRepo: Repository<ProcessDictionary>, dataSource: DataSource);
    onModuleInit(): Promise<void>;
    private syncBaseline;
    findAll(query?: {
        keyword?: string;
        isActive?: string;
        page?: number;
        pageSize?: number;
    }): Promise<{
        items: ProcessDictionary[];
        meta: {
            total: number;
            page: number;
            pageSize: number;
            totalPages: number;
        };
    }>;
    findOne(id: number): Promise<ProcessDictionary>;
    findByCode(processCode: string): Promise<ProcessDictionary | null>;
    create(data: Partial<ProcessDictionary>): Promise<ProcessDictionary>;
    update(id: number, data: Partial<ProcessDictionary>): Promise<ProcessDictionary>;
    remove(id: number): Promise<void>;
}
