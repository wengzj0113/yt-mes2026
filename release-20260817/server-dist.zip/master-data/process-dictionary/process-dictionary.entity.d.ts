export declare class ProcessDictionary {
    id: number;
    processCode: string;
    processName: string;
    sortOrder: number;
    isActive: boolean;
    description: string;
    fieldDefinitions: string;
    createdAt: Date;
    updatedAt: Date;
}
