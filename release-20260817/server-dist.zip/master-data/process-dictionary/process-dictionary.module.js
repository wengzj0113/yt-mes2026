"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessDictionaryModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const process_dictionary_entity_1 = require("./process-dictionary.entity");
const process_dictionary_controller_1 = require("./process-dictionary.controller");
const process_dictionary_service_1 = require("./process-dictionary.service");
let ProcessDictionaryModule = class ProcessDictionaryModule {
};
exports.ProcessDictionaryModule = ProcessDictionaryModule;
exports.ProcessDictionaryModule = ProcessDictionaryModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([process_dictionary_entity_1.ProcessDictionary])],
        controllers: [process_dictionary_controller_1.ProcessDictionaryController],
        providers: [process_dictionary_service_1.ProcessDictionaryService],
        exports: [process_dictionary_service_1.ProcessDictionaryService],
    })
], ProcessDictionaryModule);
//# sourceMappingURL=process-dictionary.module.js.map