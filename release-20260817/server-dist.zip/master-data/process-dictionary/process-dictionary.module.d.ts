export declare class ProcessDictionaryModule {
}
