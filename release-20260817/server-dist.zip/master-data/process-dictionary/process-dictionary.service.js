"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessDictionaryService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const process_dictionary_entity_1 = require("./process-dictionary.entity");
const process_baseline_1 = require("../process-baseline");
let ProcessDictionaryService = class ProcessDictionaryService {
    constructor(processDictRepo, dataSource) {
        this.processDictRepo = processDictRepo;
        this.dataSource = dataSource;
    }
    async onModuleInit() { await this.syncBaseline(); }
    async syncBaseline() {
        const processes = await this.processDictRepo.find();
        const byCode = new Map(processes.map((process) => [process.processCode, process]));
        for (const definition of process_baseline_1.PROCESS_BASELINE) {
            const existing = byCode.get(definition.processCode);
            const fields = JSON.stringify((0, process_baseline_1.mergeFieldDefinitionsWithBaseline)(existing?.fieldDefinitions, definition.fieldDefinitions));
            if (!existing) {
                await this.processDictRepo.save(this.processDictRepo.create({ ...definition, fieldDefinitions: fields }));
                continue;
            }
            if (existing.processName !== definition.processName || existing.sortOrder !== definition.sortOrder || existing.fieldDefinitions !== fields || !existing.isActive) {
                Object.assign(existing, { ...definition, fieldDefinitions: fields });
                await this.processDictRepo.save(existing);
            }
        }
        for (const legacyCode of ['assembly', 'formation', 'grading']) {
            const legacy = byCode.get(legacyCode);
            if (legacy?.isActive) {
                legacy.isActive = false;
                await this.processDictRepo.save(legacy);
            }
        }
        for (const definition of [
            { processCode: 'ocv1', processName: 'OCV1测试', sortOrder: 150, isActive: true },
            { processCode: 'ocv2', processName: 'OCV2测试', sortOrder: 155, isActive: true },
        ]) {
            const existing = byCode.get(definition.processCode);
            const fieldDefinitions = JSON.stringify((0, process_baseline_1.mergeFieldDefinitionsWithBaseline)(existing?.fieldDefinitions, process_baseline_1.OCV_PROCESS_FIELDS));
            if (!existing)
                await this.processDictRepo.save(this.processDictRepo.create({ ...definition, fieldDefinitions }));
            else if (existing.processName !== definition.processName || existing.sortOrder !== definition.sortOrder || existing.fieldDefinitions !== fieldDefinitions || !existing.isActive)
                await this.processDictRepo.save(Object.assign(existing, { ...definition, fieldDefinitions }));
        }
    }
    async findAll(query) {
        const where = { isActive: true };
        if (query?.keyword)
            where.processName = (0, typeorm_2.Like)(`%${query.keyword}%`);
        if (query?.isActive !== undefined && query?.isActive !== '')
            where.isActive = query.isActive === 'true';
        const page = query?.page ? Number(query.page) : 1;
        const pageSize = query?.pageSize ? Number(query.pageSize) : 20;
        const [items, total] = await this.processDictRepo.findAndCount({ where, order: { sortOrder: 'ASC' }, skip: (page - 1) * pageSize, take: pageSize });
        return { items, meta: { total, page, pageSize, totalPages: Math.ceil(total / pageSize) } };
    }
    async findOne(id) {
        const process = await this.processDictRepo.findOne({ where: { id } });
        if (!process)
            throw new common_1.NotFoundException(`Process Dictionary with ID ${id} not found`);
        return process;
    }
    async findByCode(processCode) {
        const process = await this.processDictRepo.findOne({ where: { processCode } });
        const baseline = (0, process_baseline_1.getProcessBaseline)(processCode);
        if (!process || !baseline)
            return process;
        if ((0, process_baseline_1.hasIncompatibleFieldDefinitions)(process.fieldDefinitions, baseline.fieldDefinitions)) {
            return { ...process, fieldDefinitions: JSON.stringify(baseline.fieldDefinitions) };
        }
        return {
            ...process,
            fieldDefinitions: process.fieldDefinitions,
        };
    }
    async create(data) { return this.processDictRepo.save(this.processDictRepo.create(data)); }
    async update(id, data) {
        const editableFields = ['processName', 'sortOrder', 'isActive', 'description', 'fieldDefinitions'];
        const updateData = Object.fromEntries(editableFields
            .filter((field) => data[field] !== undefined)
            .map((field) => [field, data[field]]));
        await this.processDictRepo.update(id, updateData);
        return this.findOne(id);
    }
    async remove(id) {
        const process = await this.findOne(id);
        if (!/^[a-zA-Z0-9_-]+$/.test(process.processCode))
            throw new common_1.BadRequestException('无效的工序代码');
        const tableName = `${process.processCode.replace(/-/g, '_')}_record`;
        try {
            const records = await this.dataSource.query(`SELECT TOP 1 id FROM ${tableName}`);
            if (records?.length)
                throw new common_1.BadRequestException('该工序已有历史生产批次使用过，无法删除，建议将其停用。');
        }
        catch (error) {
            if (error instanceof common_1.BadRequestException)
                throw error;
        }
        await this.processDictRepo.delete(id);
    }
};
exports.ProcessDictionaryService = ProcessDictionaryService;
exports.ProcessDictionaryService = ProcessDictionaryService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(process_dictionary_entity_1.ProcessDictionary)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.DataSource])
], ProcessDictionaryService);
//# sourceMappingURL=process-dictionary.service.js.map