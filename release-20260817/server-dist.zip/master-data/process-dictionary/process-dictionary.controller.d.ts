import { ProcessDictionaryService } from './process-dictionary.service';
import { ProcessDictionary } from './process-dictionary.entity';
export declare class ProcessDictionaryController {
    private readonly processDictionaryService;
    constructor(processDictionaryService: ProcessDictionaryService);
    findAll(query: any): Promise<{
        success: boolean;
        data: {
            items: ProcessDictionary[];
            meta: {
                total: number;
                page: number;
                pageSize: number;
                totalPages: number;
            };
        };
    }>;
    findByCode(code: string): Promise<{
        success: boolean;
        data: ProcessDictionary | null;
    }>;
    create(body: Partial<ProcessDictionary>): Promise<{
        success: boolean;
        data: ProcessDictionary;
    }>;
    update(id: string, body: Partial<ProcessDictionary>): Promise<{
        success: boolean;
        data: ProcessDictionary;
    }>;
    remove(id: string): Promise<{
        success: boolean;
        message: string;
    }>;
}
