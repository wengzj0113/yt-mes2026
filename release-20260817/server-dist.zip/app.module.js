"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const typeorm_1 = require("@nestjs/typeorm");
const cache_manager_1 = require("@nestjs/cache-manager");
const event_emitter_1 = require("@nestjs/event-emitter");
const cache_manager_redis_yet_1 = require("cache-manager-redis-yet");
const auth_module_1 = require("./auth/auth.module");
const user_module_1 = require("./user/user.module");
const department_module_1 = require("./department/department.module");
const equipment_module_1 = require("./equipment/equipment.module");
const health_module_1 = require("./health/health.module");
const batch_module_1 = require("./batch/batch.module");
const batching_module_1 = require("./processes/batching/batching.module");
const coating_module_1 = require("./processes/coating/coating.module");
const roller_pressing_module_1 = require("./processes/roller-pressing/roller-pressing.module");
const slitting_module_1 = require("./processes/slitting/slitting.module");
const sorting_module_1 = require("./processes/sorting/sorting.module");
const electrode_module_1 = require("./processes/electrode/electrode.module");
const winding_module_1 = require("./processes/winding/winding.module");
const assembly_module_1 = require("./processes/assembly/assembly.module");
const baking_module_1 = require("./processes/baking/baking.module");
const injection_module_1 = require("./processes/injection/injection.module");
const wrapping_module_1 = require("./processes/wrapping/wrapping.module");
const formation_module_1 = require("./processes/formation/formation.module");
const grading_module_1 = require("./processes/grading/grading.module");
const quality_check_module_1 = require("./quality/quality-check.module");
const material_warehouse_module_1 = require("./material/material-warehouse.module");
const cell_barcode_module_1 = require("./cells/cell-barcode.module");
const process_status_module_1 = require("./processes/process-status/process-status.module");
const process_dictionary_module_1 = require("./master-data/process-dictionary/process-dictionary.module");
const typeorm_naming_strategies_1 = require("typeorm-naming-strategies");
const dashboard_module_1 = require("./dashboard/dashboard.module");
const system_module_1 = require("./system/system.module");
const pack_module_1 = require("./packs/pack.module");
const core_1 = require("@nestjs/core");
const roles_guard_1 = require("./auth/roles.guard");
const jwt_auth_guard_1 = require("./auth/jwt-auth.guard");
const audit_log_interceptor_1 = require("./common/interceptors/audit-log.interceptor");
const process_parameter_module_1 = require("./process-parameters/process-parameter.module");
const process_dynamic_module_1 = require("./process-dynamic/process-dynamic.module");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({ isGlobal: true }),
            event_emitter_1.EventEmitterModule.forRoot(),
            cache_manager_1.CacheModule.registerAsync({
                isGlobal: true,
                imports: [config_1.ConfigModule],
                inject: [config_1.ConfigService],
                useFactory: async (config) => {
                    const host = config.get('REDIS_HOST');
                    if (host) {
                        const store = await (0, cache_manager_redis_yet_1.redisStore)({
                            socket: {
                                host: host,
                                port: parseInt(config.get('REDIS_PORT', '6379'), 10),
                            },
                            password: config.get('REDIS_PASSWORD'),
                            ttl: 3600000,
                        });
                        return { store };
                    }
                    return { ttl: 3600000 };
                },
            }),
            typeorm_1.TypeOrmModule.forRootAsync({
                imports: [config_1.ConfigModule],
                inject: [config_1.ConfigService],
                useFactory: (config) => ({
                    type: 'mssql',
                    host: config.get('DB_HOST', 'localhost'),
                    port: parseInt(config.get('DB_PORT', '1433'), 10),
                    username: config.get('DB_USERNAME', 'sa'),
                    password: config.get('DB_PASSWORD'),
                    database: config.get('DB_DATABASE', 'YT_MES'),
                    synchronize: false,
                    migrationsRun: true,
                    migrations: [__dirname + '/migrations/*.{js,ts}'],
                    autoLoadEntities: true,
                    namingStrategy: new typeorm_naming_strategies_1.SnakeNamingStrategy(),
                    options: {
                        encrypt: false,
                        trustServerCertificate: true,
                        connectTimeout: 15000,
                        requestTimeout: 30000,
                        cancelTimeout: 10000,
                    },
                    extra: {
                        max: 20,
                        min: 2,
                        connectionTimeout: 15000,
                        requestTimeout: 30000,
                    },
                }),
            }),
            auth_module_1.AuthModule,
            user_module_1.UserModule,
            department_module_1.DepartmentModule,
            equipment_module_1.EquipmentModule,
            health_module_1.HealthModule,
            batch_module_1.BatchModule,
            batching_module_1.BatchingModule,
            coating_module_1.CoatingModule,
            roller_pressing_module_1.RollerPressingModule,
            slitting_module_1.SlittingModule,
            sorting_module_1.SortingModule,
            electrode_module_1.ElectrodeModule,
            winding_module_1.WindingModule,
            assembly_module_1.AssemblyModule,
            baking_module_1.BakingModule,
            injection_module_1.InjectionModule,
            wrapping_module_1.WrappingModule,
            formation_module_1.FormationModule,
            grading_module_1.GradingModule,
            quality_check_module_1.QualityCheckModule,
            material_warehouse_module_1.MaterialWarehouseModule,
            cell_barcode_module_1.CellBarcodeModule,
            process_status_module_1.ProcessStatusModule,
            process_dictionary_module_1.ProcessDictionaryModule,
            dashboard_module_1.DashboardModule,
            system_module_1.SystemModule,
            pack_module_1.PackModule,
            process_parameter_module_1.ProcessParameterModule,
            process_dynamic_module_1.ProcessDynamicModule,
        ],
        providers: [
            {
                provide: core_1.APP_INTERCEPTOR,
                useClass: audit_log_interceptor_1.AuditLogInterceptor,
            },
            {
                provide: core_1.APP_GUARD,
                useClass: jwt_auth_guard_1.JwtAuthGuard,
            },
            {
                provide: core_1.APP_GUARD,
                useClass: roles_guard_1.RolesGuard,
            },
        ],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map