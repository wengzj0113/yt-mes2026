import { DepartmentService } from './department.service';
import { CreateDepartmentDto } from './dto/create-department.dto';
import { UpdateDepartmentDto } from './dto/update-department.dto';
export declare class DepartmentController {
    private readonly departmentService;
    constructor(departmentService: DepartmentService);
    findAll(): Promise<{
        data: import("./department.entity").Department[];
    }>;
    create(dto: CreateDepartmentDto): Promise<{
        data: import("./department.entity").Department;
        message: string;
    }>;
    update(id: number, dto: UpdateDepartmentDto): Promise<{
        data: import("./department.entity").Department;
        message: string;
    }>;
    remove(id: number): Promise<{
        message: string;
    }>;
}
