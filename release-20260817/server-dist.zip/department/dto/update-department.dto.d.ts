export declare class UpdateDepartmentDto {
    name?: string;
    code?: string;
    isActive?: boolean;
}
