import { Repository } from 'typeorm';
import { Department } from './department.entity';
export declare class DepartmentService {
    private readonly departmentRepo;
    constructor(departmentRepo: Repository<Department>);
    findAll(): Promise<Department[]>;
    create(dto: {
        name: string;
        code: string;
    }): Promise<Department>;
    update(id: number, dto: {
        name?: string;
        code?: string;
        isActive?: boolean;
    }): Promise<Department>;
    remove(id: number): Promise<void>;
}
