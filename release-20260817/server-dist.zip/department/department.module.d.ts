export declare class DepartmentModule {
}
