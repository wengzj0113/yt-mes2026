"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessParameterService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const batch_entity_1 = require("../batch/batch.entity");
const process_parameter_entity_1 = require("./process-parameter.entity");
const ALLOWED_PROCESS_CODES = new Set(['ocv1', 'ocv2']);
let ProcessParameterService = class ProcessParameterService {
    constructor(repo, batchRepo) {
        this.repo = repo;
        this.batchRepo = batchRepo;
    }
    validateProcessCode(processCode) {
        if (!ALLOWED_PROCESS_CODES.has(processCode)) {
            throw new common_1.BadRequestException({ code: 'PROCESS_PARAMETER_UNSUPPORTED', message: '仅支持 OCV1 和 OCV2 参数' });
        }
    }
    validateRanges(dto) {
        const ranges = [
            ['OCV电压', dto.ocvVoltageMin, dto.ocvVoltageMax],
            ['内阻', dto.irMin, dto.irMax],
            ['容量', dto.capacityMin, dto.capacityMax],
        ];
        const invalid = ranges.find(([, min, max]) => min > max);
        if (invalid) {
            throw new common_1.BadRequestException({ code: 'INVALID_PARAMETER_RANGE', message: `${invalid[0]}范围的最小值不能大于最大值` });
        }
    }
    async findByBatchNo(processCode, batchNo) {
        this.validateProcessCode(processCode);
        return this.repo.findOne({ where: { processCode, batchNo } });
    }
    async saveDraft(processCode, dto, userId) {
        this.validateProcessCode(processCode);
        this.validateRanges(dto);
        const batch = await this.batchRepo.findOne({ where: { batchNo: dto.batchNo } });
        if (!batch) {
            throw new common_1.NotFoundException({ code: 'BATCH_NOT_FOUND', message: `批次 ${dto.batchNo} 不存在` });
        }
        let record = await this.repo.findOne({ where: { processCode, batchNo: dto.batchNo } });
        if (!record) {
            record = this.repo.create({ processCode, batchNo: dto.batchNo, createdBy: userId });
        }
        Object.assign(record, dto, { processCode, updatedBy: userId });
        return this.repo.save(record);
    }
};
exports.ProcessParameterService = ProcessParameterService;
exports.ProcessParameterService = ProcessParameterService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(process_parameter_entity_1.ProcessParameter)),
    __param(1, (0, typeorm_1.InjectRepository)(batch_entity_1.Batch)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], ProcessParameterService);
//# sourceMappingURL=process-parameter.service.js.map