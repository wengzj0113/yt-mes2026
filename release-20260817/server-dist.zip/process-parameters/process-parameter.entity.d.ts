export declare class ProcessParameter {
    id: number;
    batchNo: string;
    processCode: string;
    equipmentCode: string;
    ocvVoltageMin: number;
    ocvVoltageMax: number;
    irMin: number;
    irMax: number;
    capacityMin: number;
    capacityMax: number;
    operatorName: string;
    createdBy: number | null;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date;
}
