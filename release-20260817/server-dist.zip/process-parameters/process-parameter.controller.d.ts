import { JwtPayload } from '../common/decorators/current-user.decorator';
import { SaveProcessParameterDto } from './dto/save-process-parameter.dto';
import { ProcessParameterService } from './process-parameter.service';
export declare class ProcessParameterController {
    private readonly service;
    constructor(service: ProcessParameterService);
    findByBatchNo(processCode: string, batchNo: string): Promise<{
        data: import("./process-parameter.entity").ProcessParameter | null;
    }>;
    saveDraft(processCode: string, dto: SaveProcessParameterDto, user: JwtPayload): Promise<{
        data: import("./process-parameter.entity").ProcessParameter;
        message: string;
    }>;
}
