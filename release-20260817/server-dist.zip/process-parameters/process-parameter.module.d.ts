export declare class ProcessParameterModule {
}
