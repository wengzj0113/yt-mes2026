"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessParameter = void 0;
const typeorm_1 = require("typeorm");
let ProcessParameter = class ProcessParameter {
};
exports.ProcessParameter = ProcessParameter;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ProcessParameter.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'batch_no', length: 16 }),
    __metadata("design:type", String)
], ProcessParameter.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'process_code', length: 16 }),
    __metadata("design:type", String)
], ProcessParameter.prototype, "processCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'equipment_code', length: 64 }),
    __metadata("design:type", String)
], ProcessParameter.prototype, "equipmentCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ocv_voltage_min', type: 'decimal', precision: 12, scale: 4 }),
    __metadata("design:type", Number)
], ProcessParameter.prototype, "ocvVoltageMin", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ocv_voltage_max', type: 'decimal', precision: 12, scale: 4 }),
    __metadata("design:type", Number)
], ProcessParameter.prototype, "ocvVoltageMax", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ir_min', type: 'decimal', precision: 12, scale: 4 }),
    __metadata("design:type", Number)
], ProcessParameter.prototype, "irMin", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ir_max', type: 'decimal', precision: 12, scale: 4 }),
    __metadata("design:type", Number)
], ProcessParameter.prototype, "irMax", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'capacity_min', type: 'decimal', precision: 12, scale: 4 }),
    __metadata("design:type", Number)
], ProcessParameter.prototype, "capacityMin", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'capacity_max', type: 'decimal', precision: 12, scale: 4 }),
    __metadata("design:type", Number)
], ProcessParameter.prototype, "capacityMax", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'operator_name', length: 64 }),
    __metadata("design:type", String)
], ProcessParameter.prototype, "operatorName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'created_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], ProcessParameter.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], ProcessParameter.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'updated_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], ProcessParameter.prototype, "updatedBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], ProcessParameter.prototype, "updatedAt", void 0);
exports.ProcessParameter = ProcessParameter = __decorate([
    (0, typeorm_1.Entity)('process_parameter'),
    (0, typeorm_1.Index)(['batchNo', 'processCode'], { unique: true })
], ProcessParameter);
//# sourceMappingURL=process-parameter.entity.js.map