"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessParameterController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const roles_decorator_1 = require("../common/decorators/roles.decorator");
const user_entity_1 = require("../user/user.entity");
const save_process_parameter_dto_1 = require("./dto/save-process-parameter.dto");
const process_parameter_service_1 = require("./process-parameter.service");
let ProcessParameterController = class ProcessParameterController {
    constructor(service) {
        this.service = service;
    }
    async findByBatchNo(processCode, batchNo) {
        return { data: await this.service.findByBatchNo(processCode, batchNo) };
    }
    async saveDraft(processCode, dto, user) {
        return { data: await this.service.saveDraft(processCode, dto, user.sub), message: '参数保存成功' };
    }
};
exports.ProcessParameterController = ProcessParameterController;
__decorate([
    (0, common_1.Get)(':processCode/:batchNo'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.OPERATOR, user_entity_1.UserRole.QUALITY, user_entity_1.UserRole.WAREHOUSE, user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('processCode')),
    __param(1, (0, common_1.Param)('batchNo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], ProcessParameterController.prototype, "findByBatchNo", null);
__decorate([
    (0, common_1.Post)(':processCode/draft'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.OPERATOR, user_entity_1.UserRole.QUALITY, user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('processCode')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, save_process_parameter_dto_1.SaveProcessParameterDto, Object]),
    __metadata("design:returntype", Promise)
], ProcessParameterController.prototype, "saveDraft", null);
exports.ProcessParameterController = ProcessParameterController = __decorate([
    (0, common_1.Controller)('processes'),
    __metadata("design:paramtypes", [process_parameter_service_1.ProcessParameterService])
], ProcessParameterController);
//# sourceMappingURL=process-parameter.controller.js.map