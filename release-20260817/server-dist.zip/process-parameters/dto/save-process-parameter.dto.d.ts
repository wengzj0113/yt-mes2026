export declare class SaveProcessParameterDto {
    batchNo: string;
    equipmentCode: string;
    ocvVoltageMin: number;
    ocvVoltageMax: number;
    irMin: number;
    irMax: number;
    capacityMin: number;
    capacityMax: number;
    operatorName: string;
}
