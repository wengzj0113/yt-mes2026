import { Repository } from 'typeorm';
import { Batch } from '../batch/batch.entity';
import { SaveProcessParameterDto } from './dto/save-process-parameter.dto';
import { ProcessParameter } from './process-parameter.entity';
export declare class ProcessParameterService {
    private readonly repo;
    private readonly batchRepo;
    constructor(repo: Repository<ProcessParameter>, batchRepo: Repository<Batch>);
    private validateProcessCode;
    private validateRanges;
    findByBatchNo(processCode: string, batchNo: string): Promise<ProcessParameter | null>;
    saveDraft(processCode: string, dto: SaveProcessParameterDto, userId: number): Promise<ProcessParameter>;
}
