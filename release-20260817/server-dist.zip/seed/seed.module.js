"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeedModule = void 0;
const typeorm_naming_strategies_1 = require("typeorm-naming-strategies");
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const config_1 = require("@nestjs/config");
const seed_service_1 = require("./seed.service");
const user_entity_1 = require("../user/user.entity");
const department_entity_1 = require("../department/department.entity");
const equipment_entity_1 = require("../equipment/equipment.entity");
const process_dictionary_entity_1 = require("../master-data/process-dictionary/process-dictionary.entity");
const config_entity_1 = require("../system/entities/config.entity");
const batch_entity_1 = require("../batch/batch.entity");
const cell_barcode_entity_1 = require("../cells/cell-barcode.entity");
let SeedModule = class SeedModule {
};
exports.SeedModule = SeedModule;
exports.SeedModule = SeedModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot(),
            typeorm_1.TypeOrmModule.forRoot({
                type: 'mssql',
                host: process.env.DB_HOST || 'localhost',
                port: Number(process.env.DB_PORT) || 1433,
                username: process.env.DB_USERNAME || 'sa',
                password: process.env.DB_PASSWORD,
                database: process.env.DB_DATABASE || 'YT_MES',
                entities: [user_entity_1.User, department_entity_1.Department, equipment_entity_1.Equipment, process_dictionary_entity_1.ProcessDictionary, config_entity_1.SystemConfig, batch_entity_1.Batch, cell_barcode_entity_1.CellBarcode],
                synchronize: process.env.SEED_ALLOW_SYNC === 'true',
                namingStrategy: new typeorm_naming_strategies_1.SnakeNamingStrategy(),
                options: { encrypt: false, trustServerCertificate: true },
            }),
            typeorm_1.TypeOrmModule.forFeature([user_entity_1.User, department_entity_1.Department, equipment_entity_1.Equipment, process_dictionary_entity_1.ProcessDictionary, config_entity_1.SystemConfig, batch_entity_1.Batch, cell_barcode_entity_1.CellBarcode]),
        ],
        providers: [seed_service_1.SeedService],
    })
], SeedModule);
//# sourceMappingURL=seed.module.js.map