"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const seed_module_1 = require("./seed.module");
const seed_service_1 = require("./seed.service");
async function run() {
    const app = await core_1.NestFactory.createApplicationContext(seed_module_1.SeedModule);
    const seeder = app.get(seed_service_1.SeedService);
    try {
        await seeder.seed();
    }
    catch (err) {
        console.error('Seed failed:', err);
        process.exit(1);
    }
    await app.close();
}
run();
//# sourceMappingURL=run-seed.js.map