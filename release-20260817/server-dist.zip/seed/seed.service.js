"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeedService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const config_1 = require("@nestjs/config");
const bcrypt = require("bcrypt");
const user_entity_1 = require("../user/user.entity");
const department_entity_1 = require("../department/department.entity");
const equipment_entity_1 = require("../equipment/equipment.entity");
const process_dictionary_entity_1 = require("../master-data/process-dictionary/process-dictionary.entity");
const config_entity_1 = require("../system/entities/config.entity");
const batch_entity_1 = require("../batch/batch.entity");
const cell_barcode_entity_1 = require("../cells/cell-barcode.entity");
const process_baseline_1 = require("../master-data/process-baseline");
let SeedService = class SeedService {
    constructor(userRepo, departmentRepo, equipmentRepo, processDictRepo, systemConfigRepo, batchRepo, cellRepo, configService) {
        this.userRepo = userRepo;
        this.departmentRepo = departmentRepo;
        this.equipmentRepo = equipmentRepo;
        this.processDictRepo = processDictRepo;
        this.systemConfigRepo = systemConfigRepo;
        this.batchRepo = batchRepo;
        this.cellRepo = cellRepo;
        this.configService = configService;
    }
    async seed() {
        await this.seedUsers();
        await this.seedDepartments();
        await this.seedEquipment();
        await this.seedProcessDictionary();
        await this.seedSystemConfig();
        await this.seedMockBatches();
        console.log('Seed completed successfully.');
    }
    async seedMockBatches() {
        const mockBatches = [
            { no: 'B20260520001', model: 'LP27148200-50Ah', spec: '3.2V 50Ah LFP', qty: 1000 },
            { no: 'B20260520002', model: 'LP27148200-100Ah', spec: '3.2V 100Ah LFP', qty: 500 },
            { no: 'B20260520003', model: 'NCM811-60Ah', spec: '3.7V 60Ah NCM', qty: 800 },
            { no: 'B20260520004', model: 'NCM811-120Ah', spec: '3.7V 120Ah NCM', qty: 400 },
            { no: 'B20260520005', model: 'LFP-Blade-150Ah', spec: '3.2V 150Ah Blade', qty: 300 },
        ];
        for (const item of mockBatches) {
            let batch = await this.batchRepo.findOne({ where: { batchNo: item.no } });
            if (!batch) {
                batch = this.batchRepo.create({
                    batchNo: item.no,
                    productModel: item.model,
                    productSpec: item.spec,
                    workshop: '一号车间',
                    shift: '白班',
                    plannedQty: item.qty,
                    actualStartDate: new Date(),
                    status: batch_entity_1.BatchStatus.IN_PROGRESS,
                    createdBy: 1
                });
                await this.batchRepo.save(batch);
                console.log(`Created mock batch: ${item.no}`);
                const mockCells = [];
                const grades = ['A', 'A', 'A', 'B', 'A'];
                for (let i = 1; i <= 5; i++) {
                    const sn = `SN${item.no}${i.toString().padStart(3, '0')}`;
                    const cell = this.cellRepo.create({
                        barcode: sn,
                        batchNo: item.no,
                        voltage: 3.2 + Math.random() * 0.1,
                        internalResistance: 0.5 + Math.random() * 0.2,
                        capacity: ((item.qty > 500 ? 50000 : 100000) + Math.random() * 500).toFixed(2),
                        kValue: 0.01 + Math.random() * 0.005,
                        grade: grades[i - 1],
                        sortingTime: new Date(),
                        importSource: 'mock_seed'
                    });
                    mockCells.push(cell);
                }
                await this.cellRepo.save(mockCells);
                console.log(`  Seeded 5 mock cells for batch ${item.no}`);
            }
        }
    }
    async seedSystemConfig() {
        const count = await this.systemConfigRepo.count();
        if (count > 0) {
            console.log('System Config already seeded, skipping.');
            return;
        }
        const configs = this.systemConfigRepo.create([
            { key: 'system_name', value: 'YT-MES 智能生产执行系统', description: '系统显示名称' },
            { key: 'allow_guest_login', value: 'false', description: '是否允许游客登录' },
            { key: 'max_login_attempts', value: '5', description: '最大登录尝试次数' },
            { key: 'session_timeout', value: '3600', description: '会话超时时间 (秒)' },
        ]);
        await this.systemConfigRepo.save(configs);
        console.log(`Seeded ${configs.length} system config records.`);
    }
    async seedUsers() {
        const count = await this.userRepo.count();
        if (count > 0) {
            console.log('Users already seeded, skipping.');
            return;
        }
        const defaultPassword = this.configService.get('DEFAULT_USER_PASSWORD');
        if (!defaultPassword) {
            throw new Error('DEFAULT_USER_PASSWORD environment variable is required for seeding');
        }
        const password = await bcrypt.hash(defaultPassword, 12);
        const users = this.userRepo.create([
            { username: 'admin', password, realName: '系统管理员', roleCode: user_entity_1.UserRole.ADMIN, isActive: true },
            { username: 'operator1', password, realName: '张三', roleCode: user_entity_1.UserRole.OPERATOR, isActive: true },
            { username: 'operator2', password, realName: '李四', roleCode: user_entity_1.UserRole.OPERATOR, isActive: true },
            { username: 'quality1', password, realName: '王五', roleCode: user_entity_1.UserRole.QUALITY, isActive: true },
            { username: 'warehouse1', password, realName: '赵六', roleCode: user_entity_1.UserRole.WAREHOUSE, isActive: true },
        ]);
        await this.userRepo.save(users);
        console.log(`Seeded ${users.length} users.`);
    }
    async seedDepartments() {
        const count = await this.departmentRepo.count();
        if (count > 0) {
            console.log('Departments already seeded, skipping.');
            return;
        }
        const departments = this.departmentRepo.create([
            { name: '生产部', code: 'PROD' },
            { name: '品质部', code: 'QA' },
            { name: '仓储部', code: 'WH' },
            { name: '管理部', code: 'ADMIN' },
        ]);
        await this.departmentRepo.save(departments);
        console.log(`Seeded ${departments.length} departments.`);
    }
    async seedEquipment() {
        const count = await this.equipmentRepo.count();
        if (count > 0) {
            console.log('Equipment already seeded, skipping.');
            return;
        }
        const equipment = this.equipmentRepo.create([
            { equipmentCode: 'E001', equipmentName: '配料机-01', departmentCode: 'PROD' },
            { equipmentCode: 'E002', equipmentName: '涂布机-01', departmentCode: 'PROD' },
            { equipmentCode: 'E003', equipmentName: '辊压机-01', departmentCode: 'PROD' },
            { equipmentCode: 'E004', equipmentName: '分切机-01', departmentCode: 'PROD' },
        ]);
        await this.equipmentRepo.save(equipment);
        console.log(`Seeded ${equipment.length} equipment records.`);
    }
    async seedProcessDictionary() {
        const processes = this.processDictRepo.create([
            { processCode: 'batching', processName: '配料', sortOrder: 10, isActive: true },
            { processCode: 'coating', processName: '涂布', sortOrder: 20, isActive: true },
            { processCode: 'roller-pressing', processName: '辊压', sortOrder: 30, isActive: true },
            { processCode: 'slitting', processName: '分切', sortOrder: 40, isActive: true },
            { processCode: 'electrode', processName: '制片', sortOrder: 50, isActive: true },
            { processCode: 'winding', processName: '卷绕', sortOrder: 60, isActive: true },
            { processCode: 'assembly', processName: '装配', sortOrder: 70, isActive: true },
            { processCode: 'baking', processName: '烘烤', sortOrder: 80, isActive: true },
            { processCode: 'injection', processName: '注液', sortOrder: 90, isActive: true },
            { processCode: 'wrapping', processName: '顶封', sortOrder: 100, isActive: true },
            { processCode: 'formation', processName: '化成', sortOrder: 110, isActive: true },
            { processCode: 'grading', processName: '分容', sortOrder: 120, isActive: true },
            { processCode: 'ocv1', processName: 'OCV1测试', sortOrder: 125, isActive: true },
            { processCode: 'ocv2', processName: 'OCV2测试', sortOrder: 128, isActive: true },
            { processCode: 'sorting', processName: '分选', sortOrder: 130, isActive: true },
        ]);
        for (const definition of process_baseline_1.PROCESS_BASELINE) {
            const existing = await this.processDictRepo.findOne({ where: { processCode: definition.processCode } });
            const data = {
                ...definition,
                fieldDefinitions: JSON.stringify((0, process_baseline_1.mergeFieldDefinitionsWithBaseline)(existing?.fieldDefinitions, definition.fieldDefinitions)),
            };
            if (existing)
                await this.processDictRepo.save(Object.assign(existing, data));
            else
                await this.processDictRepo.save(this.processDictRepo.create(data));
        }
        for (const legacyCode of ['formation', 'grading']) {
            const legacy = await this.processDictRepo.findOne({ where: { processCode: legacyCode } });
            if (legacy?.isActive) {
                legacy.isActive = false;
                await this.processDictRepo.save(legacy);
            }
        }
        console.log(`Aligned ${process_baseline_1.PROCESS_BASELINE.length} process dictionary records.`);
    }
};
exports.SeedService = SeedService;
exports.SeedService = SeedService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __param(1, (0, typeorm_1.InjectRepository)(department_entity_1.Department)),
    __param(2, (0, typeorm_1.InjectRepository)(equipment_entity_1.Equipment)),
    __param(3, (0, typeorm_1.InjectRepository)(process_dictionary_entity_1.ProcessDictionary)),
    __param(4, (0, typeorm_1.InjectRepository)(config_entity_1.SystemConfig)),
    __param(5, (0, typeorm_1.InjectRepository)(batch_entity_1.Batch)),
    __param(6, (0, typeorm_1.InjectRepository)(cell_barcode_entity_1.CellBarcode)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        config_1.ConfigService])
], SeedService);
//# sourceMappingURL=seed.service.js.map