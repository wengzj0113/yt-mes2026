import { Repository } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import { User } from '../user/user.entity';
import { Department } from '../department/department.entity';
import { Equipment } from '../equipment/equipment.entity';
import { ProcessDictionary } from '../master-data/process-dictionary/process-dictionary.entity';
import { SystemConfig } from '../system/entities/config.entity';
import { Batch } from '../batch/batch.entity';
import { CellBarcode } from '../cells/cell-barcode.entity';
export declare class SeedService {
    private readonly userRepo;
    private readonly departmentRepo;
    private readonly equipmentRepo;
    private readonly processDictRepo;
    private readonly systemConfigRepo;
    private readonly batchRepo;
    private readonly cellRepo;
    private readonly configService;
    constructor(userRepo: Repository<User>, departmentRepo: Repository<Department>, equipmentRepo: Repository<Equipment>, processDictRepo: Repository<ProcessDictionary>, systemConfigRepo: Repository<SystemConfig>, batchRepo: Repository<Batch>, cellRepo: Repository<CellBarcode>, configService: ConfigService);
    seed(): Promise<void>;
    private seedMockBatches;
    private seedSystemConfig;
    private seedUsers;
    private seedDepartments;
    private seedEquipment;
    private seedProcessDictionary;
}
