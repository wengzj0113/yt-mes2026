"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SystemService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const log_entity_1 = require("./entities/log.entity");
const config_entity_1 = require("./entities/config.entity");
const sorter_api_log_entity_1 = require("./entities/sorter-api-log.entity");
const role_entity_1 = require("./entities/role.entity");
const user_entity_1 = require("../user/user.entity");
const FALLBACK_ROLES = [
    { code: 1, name: '操作员', description: '生产线操作，工序录入', isSystem: true, createdAt: null },
    { code: 2, name: '质检员', description: '质量控制，巡检检验', isSystem: true, createdAt: null },
    { code: 3, name: '仓管员', description: '仓库管理，物料出入库', isSystem: true, createdAt: null },
    { code: 4, name: '系统管理员', description: '系统管理员，拥有全部权限', isSystem: true, createdAt: null },
];
let SystemService = class SystemService {
    constructor(logRepo, configRepo, sorterApiLogRepo, roleRepo, userRepo) {
        this.logRepo = logRepo;
        this.configRepo = configRepo;
        this.sorterApiLogRepo = sorterApiLogRepo;
        this.roleRepo = roleRepo;
        this.userRepo = userRepo;
    }
    onModuleInit() {
        this.cleanOldSorterApiLogs();
        setInterval(() => {
            this.cleanOldSorterApiLogs();
        }, 12 * 60 * 60 * 1000);
    }
    async cleanOldSorterApiLogs() {
        const threeDaysAgo = new Date();
        threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
        try {
            const result = await this.sorterApiLogRepo
                .createQueryBuilder()
                .delete()
                .where('createdAt < :date', { date: threeDaysAgo })
                .execute();
            console.log(`[System] Cleaned up old sorter API logs. Affected rows: ${result.affected}`);
        }
        catch (error) {
            console.error('[System] Failed to clean up old sorter API logs:', error);
        }
    }
    async logSorterApi(data) {
        const log = this.sorterApiLogRepo.create(data);
        return this.sorterApiLogRepo.save(log);
    }
    async getSorterLogs(params) {
        const page = Number(params.page || 1);
        const pageSize = Number(params.pageSize || 20);
        const { isSuccess, apiEndpoint, apiType } = params;
        const query = this.sorterApiLogRepo.createQueryBuilder('log');
        if (isSuccess !== undefined) {
            query.andWhere('log.isSuccess = :isSuccess', { isSuccess });
        }
        if (apiEndpoint) {
            query.andWhere('log.apiEndpoint LIKE :apiEndpoint', { apiEndpoint: `%${apiEndpoint}%` });
        }
        if (apiType) {
            query.andWhere('log.apiType = :apiType', { apiType });
        }
        const [items, total] = await query
            .orderBy('log.createdAt', 'DESC')
            .skip((page - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();
        return {
            data: { items },
            meta: { total, page, pageSize },
        };
    }
    async getLogs(params) {
        const page = Number(params.page || 1);
        const pageSize = Number(params.pageSize || 20);
        const { module } = params;
        const query = this.logRepo.createQueryBuilder('log');
        if (module) {
            query.andWhere('log.module = :module', { module });
        }
        const [items, total] = await query
            .orderBy('log.createdAt', 'DESC')
            .skip((page - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();
        return {
            data: { items },
            meta: { total, page, pageSize },
        };
    }
    async getConfigs() {
        return this.configRepo.find();
    }
    async updateConfig(id, value) {
        const config = await this.configRepo.findOne({ where: { id } });
        if (!config) {
            throw new common_1.NotFoundException(`配置项 ID ${id} 不存在`);
        }
        config.value = value;
        return this.configRepo.save(config);
    }
    async logAction(data) {
        const log = this.logRepo.create(data);
        return this.logRepo.save(log);
    }
    async listRoles() {
        try {
            const items = await this.roleRepo.find({ order: { code: 'ASC' } });
            if (items.length > 0)
                return items;
            return FALLBACK_ROLES;
        }
        catch (err) {
            console.warn('[SystemService.listRoles] fallback to static list:', err.message);
            return FALLBACK_ROLES;
        }
    }
    async createRole(dto) {
        const code = Number(dto.code);
        const name = (dto.name || '').trim();
        const description = dto.description?.trim() || null;
        if (!Number.isInteger(code) || code < 5) {
            throw new common_1.BadRequestException('角色编码必须为不小于5的整数');
        }
        if (!name) {
            throw new common_1.BadRequestException('角色名称不能为空');
        }
        try {
            const exists = await this.roleRepo.findOne({ where: [{ code }, { name }] });
            if (exists) {
                throw new common_1.ConflictException('角色编码或名称已存在');
            }
        }
        catch (err) {
            if (err instanceof common_1.ConflictException)
                throw err;
            throw new common_1.BadRequestException('角色字典表尚未初始化，请联系管理员运行迁移后重试');
        }
        const role = this.roleRepo.create({
            code,
            name,
            description,
            isSystem: false,
        });
        return this.roleRepo.save(role);
    }
    async updateRole(code, dto) {
        const role = await this.roleRepo.findOne({ where: { code } });
        if (!role) {
            throw new common_1.NotFoundException(`角色编码 ${code} 不存在`);
        }
        if (role.isSystem) {
            throw new common_1.BadRequestException('系统内置角色不可编辑');
        }
        if (dto.name !== undefined) {
            const trimmed = (dto.name || '').trim();
            if (!trimmed) {
                throw new common_1.BadRequestException('角色名称不能为空');
            }
            if (trimmed !== role.name) {
                const conflict = await this.roleRepo.findOne({ where: { name: trimmed } });
                if (conflict && conflict.code !== role.code) {
                    throw new common_1.ConflictException('角色名称已存在');
                }
                role.name = trimmed;
            }
        }
        if (dto.description !== undefined) {
            role.description = dto.description ? dto.description.trim() || null : null;
        }
        return this.roleRepo.save(role);
    }
    async deleteRole(code) {
        const role = await this.roleRepo.findOne({ where: { code } });
        if (!role) {
            throw new common_1.NotFoundException(`角色编码 ${code} 不存在`);
        }
        if (role.isSystem) {
            throw new common_1.BadRequestException('系统内置角色不可删除');
        }
        const inUse = await this.userRepo.count({ where: { roleCode: code } });
        if (inUse > 0) {
            throw new common_1.BadRequestException(`该角色已被 ${inUse} 个用户占用，无法删除`);
        }
        await this.roleRepo.delete({ code });
    }
    async rolesInUseCodes(codes) {
        if (!codes.length)
            return new Set();
        const users = await this.userRepo.find({ where: { roleCode: (0, typeorm_2.In)(codes) }, select: ['id', 'roleCode'] });
        return new Set(users.map((u) => u.roleCode));
    }
};
exports.SystemService = SystemService;
exports.SystemService = SystemService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(log_entity_1.SystemLog)),
    __param(1, (0, typeorm_1.InjectRepository)(config_entity_1.SystemConfig)),
    __param(2, (0, typeorm_1.InjectRepository)(sorter_api_log_entity_1.SorterApiLog)),
    __param(3, (0, typeorm_1.InjectRepository)(role_entity_1.SystemRole)),
    __param(4, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], SystemService);
//# sourceMappingURL=system.service.js.map