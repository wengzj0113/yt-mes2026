"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SystemController = void 0;
const common_1 = require("@nestjs/common");
const system_service_1 = require("./system.service");
const roles_decorator_1 = require("../common/decorators/roles.decorator");
const roles_guard_1 = require("../auth/roles.guard");
const user_entity_1 = require("../user/user.entity");
const create_role_dto_1 = require("./dto/create-role.dto");
const update_role_dto_1 = require("./dto/update-role.dto");
let SystemController = class SystemController {
    constructor(systemService) {
        this.systemService = systemService;
    }
    async getLogs(page = 1, pageSize = 20, module) {
        return this.systemService.getLogs({ page, pageSize, module });
    }
    async getSorterLogs(page = 1, pageSize = 20, isSuccess, apiEndpoint, apiType) {
        return this.systemService.getSorterLogs({
            page,
            pageSize,
            isSuccess: isSuccess === 'true' ? true : isSuccess === 'false' ? false : undefined,
            apiEndpoint,
            apiType,
        });
    }
    async getConfigs() {
        const configs = await this.systemService.getConfigs();
        return { data: configs };
    }
    async updateConfig(id, value) {
        const config = await this.systemService.updateConfig(id, value);
        return { data: config, message: '更新成功' };
    }
    async getRoles() {
        const roles = await this.systemService.listRoles();
        return { data: roles };
    }
    async createRole(dto) {
        const role = await this.systemService.createRole(dto);
        return { data: role, message: '角色创建成功' };
    }
    async updateRole(code, dto) {
        const role = await this.systemService.updateRole(Number(code), dto);
        return { data: role, message: '角色更新成功' };
    }
    async deleteRole(code) {
        await this.systemService.deleteRole(Number(code));
        return { message: '角色已删除' };
    }
};
exports.SystemController = SystemController;
__decorate([
    (0, common_1.Get)('logs'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('pageSize')),
    __param(2, (0, common_1.Query)('module')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number, String]),
    __metadata("design:returntype", Promise)
], SystemController.prototype, "getLogs", null);
__decorate([
    (0, common_1.Get)('sorter-logs'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('pageSize')),
    __param(2, (0, common_1.Query)('isSuccess')),
    __param(3, (0, common_1.Query)('apiEndpoint')),
    __param(4, (0, common_1.Query)('apiType')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number, String, String, String]),
    __metadata("design:returntype", Promise)
], SystemController.prototype, "getSorterLogs", null);
__decorate([
    (0, common_1.Get)('configs'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.ADMIN),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SystemController.prototype, "getConfigs", null);
__decorate([
    (0, common_1.Post)('configs/:id'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('value')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, String]),
    __metadata("design:returntype", Promise)
], SystemController.prototype, "updateConfig", null);
__decorate([
    (0, common_1.Get)('roles'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SystemController.prototype, "getRoles", null);
__decorate([
    (0, common_1.Post)('roles'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_role_dto_1.CreateRoleDto]),
    __metadata("design:returntype", Promise)
], SystemController.prototype, "createRole", null);
__decorate([
    (0, common_1.Post)('roles/:code'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('code')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_role_dto_1.UpdateRoleDto]),
    __metadata("design:returntype", Promise)
], SystemController.prototype, "updateRole", null);
__decorate([
    (0, common_1.Post)('roles/:code/delete'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('code')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SystemController.prototype, "deleteRole", null);
exports.SystemController = SystemController = __decorate([
    (0, common_1.UseGuards)(roles_guard_1.RolesGuard),
    (0, common_1.Controller)('system'),
    __metadata("design:paramtypes", [system_service_1.SystemService])
], SystemController);
//# sourceMappingURL=system.controller.js.map