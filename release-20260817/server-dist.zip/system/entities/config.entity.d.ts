export declare class SystemConfig {
    id: number;
    key: string;
    value: string;
    description: string;
    updatedAt: Date;
}
