export declare class SystemLog {
    id: number;
    userId: number;
    username: string;
    action: string;
    module: string;
    detail: string;
    ip: string;
    createdAt: Date;
}
