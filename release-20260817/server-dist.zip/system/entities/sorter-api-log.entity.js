"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SorterApiLog = void 0;
const typeorm_1 = require("typeorm");
let SorterApiLog = class SorterApiLog {
};
exports.SorterApiLog = SorterApiLog;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], SorterApiLog.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'api_endpoint', length: 128 }),
    __metadata("design:type", String)
], SorterApiLog.prototype, "apiEndpoint", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'method', length: 10 }),
    __metadata("design:type", String)
], SorterApiLog.prototype, "method", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'request_body', type: 'nvarchar', length: 'max', nullable: true }),
    __metadata("design:type", String)
], SorterApiLog.prototype, "requestBody", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'response_body', type: 'nvarchar', length: 'max', nullable: true }),
    __metadata("design:type", String)
], SorterApiLog.prototype, "responseBody", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status_code', type: 'int' }),
    __metadata("design:type", Number)
], SorterApiLog.prototype, "statusCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'is_success', type: 'bit' }),
    __metadata("design:type", Boolean)
], SorterApiLog.prototype, "isSuccess", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'error_message', type: 'nvarchar', length: 'max', nullable: true }),
    __metadata("design:type", String)
], SorterApiLog.prototype, "errorMessage", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ip', length: 64, nullable: true }),
    __metadata("design:type", String)
], SorterApiLog.prototype, "ip", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'duration', type: 'int', nullable: true }),
    __metadata("design:type", Number)
], SorterApiLog.prototype, "duration", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], SorterApiLog.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'api_type', type: 'nvarchar', length: 16, nullable: true }),
    __metadata("design:type", Object)
], SorterApiLog.prototype, "apiType", void 0);
exports.SorterApiLog = SorterApiLog = __decorate([
    (0, typeorm_1.Entity)('sorter_api_log')
], SorterApiLog);
//# sourceMappingURL=sorter-api-log.entity.js.map