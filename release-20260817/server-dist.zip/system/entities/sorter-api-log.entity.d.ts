export declare class SorterApiLog {
    id: number;
    apiEndpoint: string;
    method: string;
    requestBody: string;
    responseBody: string;
    statusCode: number;
    isSuccess: boolean;
    errorMessage: string;
    ip: string;
    duration: number;
    createdAt: Date;
    apiType: string | null;
}
