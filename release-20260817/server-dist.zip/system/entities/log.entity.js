"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SystemLog = void 0;
const typeorm_1 = require("typeorm");
let SystemLog = class SystemLog {
};
exports.SystemLog = SystemLog;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], SystemLog.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'user_id' }),
    __metadata("design:type", Number)
], SystemLog.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'username' }),
    __metadata("design:type", String)
], SystemLog.prototype, "username", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'action' }),
    __metadata("design:type", String)
], SystemLog.prototype, "action", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'module' }),
    __metadata("design:type", String)
], SystemLog.prototype, "module", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'detail', type: 'nvarchar', length: 'max', nullable: true }),
    __metadata("design:type", String)
], SystemLog.prototype, "detail", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ip', nullable: true }),
    __metadata("design:type", String)
], SystemLog.prototype, "ip", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], SystemLog.prototype, "createdAt", void 0);
exports.SystemLog = SystemLog = __decorate([
    (0, typeorm_1.Entity)('sys_log')
], SystemLog);
//# sourceMappingURL=log.entity.js.map