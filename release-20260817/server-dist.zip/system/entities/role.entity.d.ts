export declare class SystemRole {
    code: number;
    name: string;
    description: string | null;
    isSystem: boolean;
    createdAt: Date;
}
