import { OnModuleInit } from '@nestjs/common';
import { Repository } from 'typeorm';
import { SystemLog } from './entities/log.entity';
import { SystemConfig } from './entities/config.entity';
import { SorterApiLog } from './entities/sorter-api-log.entity';
import { SystemRole } from './entities/role.entity';
import { CreateRoleDto } from './dto/create-role.dto';
import { UpdateRoleDto } from './dto/update-role.dto';
import { User } from '../user/user.entity';
export declare class SystemService implements OnModuleInit {
    private readonly logRepo;
    private readonly configRepo;
    private readonly sorterApiLogRepo;
    private readonly roleRepo;
    private readonly userRepo;
    constructor(logRepo: Repository<SystemLog>, configRepo: Repository<SystemConfig>, sorterApiLogRepo: Repository<SorterApiLog>, roleRepo: Repository<SystemRole>, userRepo: Repository<User>);
    onModuleInit(): void;
    cleanOldSorterApiLogs(): Promise<void>;
    logSorterApi(data: Partial<SorterApiLog>): Promise<SorterApiLog>;
    getSorterLogs(params: {
        page: number;
        pageSize: number;
        isSuccess?: boolean;
        apiEndpoint?: string;
        apiType?: string;
    }): Promise<{
        data: {
            items: SorterApiLog[];
        };
        meta: {
            total: number;
            page: number;
            pageSize: number;
        };
    }>;
    getLogs(params: {
        page: number;
        pageSize: number;
        module?: string;
    }): Promise<{
        data: {
            items: SystemLog[];
        };
        meta: {
            total: number;
            page: number;
            pageSize: number;
        };
    }>;
    getConfigs(): Promise<SystemConfig[]>;
    updateConfig(id: number, value: string): Promise<SystemConfig>;
    logAction(data: Partial<SystemLog>): Promise<SystemLog>;
    listRoles(): Promise<SystemRole[]>;
    createRole(dto: CreateRoleDto): Promise<SystemRole>;
    updateRole(code: number, dto: UpdateRoleDto): Promise<SystemRole>;
    deleteRole(code: number): Promise<void>;
    rolesInUseCodes(codes: number[]): Promise<Set<number>>;
}
