import { SystemService } from './system.service';
import { CreateRoleDto } from './dto/create-role.dto';
import { UpdateRoleDto } from './dto/update-role.dto';
export declare class SystemController {
    private readonly systemService;
    constructor(systemService: SystemService);
    getLogs(page?: number, pageSize?: number, module?: string): Promise<{
        data: {
            items: import("./entities/log.entity").SystemLog[];
        };
        meta: {
            total: number;
            page: number;
            pageSize: number;
        };
    }>;
    getSorterLogs(page?: number, pageSize?: number, isSuccess?: string, apiEndpoint?: string, apiType?: string): Promise<{
        data: {
            items: import("./entities/sorter-api-log.entity").SorterApiLog[];
        };
        meta: {
            total: number;
            page: number;
            pageSize: number;
        };
    }>;
    getConfigs(): Promise<{
        data: import("./entities/config.entity").SystemConfig[];
    }>;
    updateConfig(id: number, value: string): Promise<{
        data: import("./entities/config.entity").SystemConfig;
        message: string;
    }>;
    getRoles(): Promise<{
        data: import("./entities/role.entity").SystemRole[];
    }>;
    createRole(dto: CreateRoleDto): Promise<{
        data: import("./entities/role.entity").SystemRole;
        message: string;
    }>;
    updateRole(code: string, dto: UpdateRoleDto): Promise<{
        data: import("./entities/role.entity").SystemRole;
        message: string;
    }>;
    deleteRole(code: string): Promise<{
        message: string;
    }>;
}
