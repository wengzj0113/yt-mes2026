export declare class CreateRoleDto {
    code: number;
    name: string;
    description?: string;
}
