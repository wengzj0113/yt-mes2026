import { Repository, DataSource } from 'typeorm';
import { Pack } from './pack.entity';
import { PackCell } from './pack-cell.entity';
import { CreatePackDto } from './dto/create-pack.dto';
export declare class PackService {
    private readonly packRepo;
    private readonly packCellRepo;
    private readonly dataSource;
    constructor(packRepo: Repository<Pack>, packCellRepo: Repository<PackCell>, dataSource: DataSource);
    createOrUpdate(dto: CreatePackDto, operatorName?: string): Promise<Pack>;
    findByBarcode(barcode: string): Promise<Pack>;
    findAll(page?: number, pageSize?: number): Promise<{
        items: Pack[];
        total: number;
    }>;
}
