"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PackService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const pack_entity_1 = require("./pack.entity");
const pack_cell_entity_1 = require("./pack-cell.entity");
let PackService = class PackService {
    constructor(packRepo, packCellRepo, dataSource) {
        this.packRepo = packRepo;
        this.packCellRepo = packCellRepo;
        this.dataSource = dataSource;
    }
    async createOrUpdate(dto, operatorName) {
        const queryRunner = this.dataSource.createQueryRunner();
        await queryRunner.connect();
        await queryRunner.startTransaction();
        try {
            let pack = await this.packRepo.findOne({
                where: { packBarcode: dto.packBarcode },
                relations: ['cells'],
            });
            if (pack) {
                pack.batchNo = dto.batchNo || pack.batchNo;
                pack.protectionBoardBarcode = dto.protectionBoardBarcode || pack.protectionBoardBarcode;
                pack.operatorName = operatorName || pack.operatorName;
                await queryRunner.manager.delete(pack_cell_entity_1.PackCell, { packId: pack.id });
            }
            else {
                pack = this.packRepo.create({
                    packBarcode: dto.packBarcode,
                    batchNo: dto.batchNo ?? null,
                    protectionBoardBarcode: dto.protectionBoardBarcode ?? null,
                    operatorName: operatorName ?? null,
                });
                pack = await queryRunner.manager.save(pack);
            }
            const cells = dto.cellBarcodes.map((barcode) => {
                return this.packCellRepo.create({
                    cellBarcode: barcode,
                    packId: pack.id,
                });
            });
            await queryRunner.manager.save(cells);
            await queryRunner.commitTransaction();
            return this.findByBarcode(dto.packBarcode);
        }
        catch (err) {
            await queryRunner.rollbackTransaction();
            throw err;
        }
        finally {
            await queryRunner.release();
        }
    }
    async findByBarcode(barcode) {
        const pack = await this.packRepo.findOne({
            where: { packBarcode: barcode },
            relations: ['cells'],
        });
        if (!pack) {
            throw new common_1.NotFoundException({
                code: 'PACK_NOT_FOUND',
                message: `Pack 条码 ${barcode} 未找到`,
            });
        }
        return pack;
    }
    async findAll(page = 1, pageSize = 10) {
        const [items, total] = await this.packRepo.findAndCount({
            order: { createdAt: 'DESC' },
            skip: (page - 1) * pageSize,
            take: pageSize,
            relations: ['cells'],
        });
        return { items, total };
    }
};
exports.PackService = PackService;
exports.PackService = PackService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(pack_entity_1.Pack)),
    __param(1, (0, typeorm_1.InjectRepository)(pack_cell_entity_1.PackCell)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.DataSource])
], PackService);
//# sourceMappingURL=pack.service.js.map