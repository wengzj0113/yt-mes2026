export declare class CreatePackDto {
    packBarcode: string;
    batchNo?: string;
    protectionBoardBarcode?: string;
    cellBarcodes: string[];
}
