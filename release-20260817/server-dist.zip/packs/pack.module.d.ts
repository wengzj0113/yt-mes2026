export declare class PackModule {
}
