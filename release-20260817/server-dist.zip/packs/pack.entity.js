"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Pack = void 0;
const typeorm_1 = require("typeorm");
const pack_cell_entity_1 = require("./pack-cell.entity");
let Pack = class Pack {
};
exports.Pack = Pack;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], Pack.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ length: 64, unique: true, name: 'pack_barcode' }),
    __metadata("design:type", String)
], Pack.prototype, "packBarcode", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'nvarchar', length: 64, nullable: true, name: 'batch_no' }),
    __metadata("design:type", Object)
], Pack.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'nvarchar', length: 64, nullable: true, name: 'protection_board_barcode' }),
    __metadata("design:type", Object)
], Pack.prototype, "protectionBoardBarcode", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'nvarchar', length: 64, nullable: true, name: 'operator_name' }),
    __metadata("design:type", Object)
], Pack.prototype, "operatorName", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => pack_cell_entity_1.PackCell, (cell) => cell.pack, { cascade: true }),
    __metadata("design:type", Array)
], Pack.prototype, "cells", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], Pack.prototype, "createdAt", void 0);
exports.Pack = Pack = __decorate([
    (0, typeorm_1.Entity)('pack')
], Pack);
//# sourceMappingURL=pack.entity.js.map