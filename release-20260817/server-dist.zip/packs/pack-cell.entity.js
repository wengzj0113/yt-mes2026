"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PackCell = void 0;
const typeorm_1 = require("typeorm");
const pack_entity_1 = require("./pack.entity");
let PackCell = class PackCell {
};
exports.PackCell = PackCell;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], PackCell.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ length: 64, name: 'cell_barcode' }),
    __metadata("design:type", String)
], PackCell.prototype, "cellBarcode", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => pack_entity_1.Pack, (pack) => pack.cells, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'pack_id' }),
    __metadata("design:type", pack_entity_1.Pack)
], PackCell.prototype, "pack", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pack_id' }),
    __metadata("design:type", Number)
], PackCell.prototype, "packId", void 0);
exports.PackCell = PackCell = __decorate([
    (0, typeorm_1.Entity)('pack_cell')
], PackCell);
//# sourceMappingURL=pack-cell.entity.js.map