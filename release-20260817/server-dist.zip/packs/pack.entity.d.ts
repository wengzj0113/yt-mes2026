import { PackCell } from './pack-cell.entity';
export declare class Pack {
    id: number;
    packBarcode: string;
    batchNo: string | null;
    protectionBoardBarcode: string | null;
    operatorName: string | null;
    cells: PackCell[];
    createdAt: Date;
}
