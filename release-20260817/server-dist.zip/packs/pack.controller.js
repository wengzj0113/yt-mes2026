"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PackController = void 0;
const common_1 = require("@nestjs/common");
const pack_service_1 = require("./pack.service");
const create_pack_dto_1 = require("./dto/create-pack.dto");
const jwt_auth_guard_1 = require("../auth/jwt-auth.guard");
let PackController = class PackController {
    constructor(packService) {
        this.packService = packService;
    }
    async findAll(page = '1', pageSize = '10') {
        return this.packService.findAll(parseInt(page), parseInt(pageSize));
    }
    async createOrUpdate(dto, req) {
        const operatorName = req.user?.username || 'unknown';
        return this.packService.createOrUpdate(dto, operatorName);
    }
    async findByBarcode(barcode) {
        return this.packService.findByBarcode(barcode);
    }
};
exports.PackController = PackController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], PackController.prototype, "findAll", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_pack_dto_1.CreatePackDto, Object]),
    __metadata("design:returntype", Promise)
], PackController.prototype, "createOrUpdate", null);
__decorate([
    (0, common_1.Get)(':barcode'),
    __param(0, (0, common_1.Param)('barcode')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PackController.prototype, "findByBarcode", null);
exports.PackController = PackController = __decorate([
    (0, common_1.Controller)('packs'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [pack_service_1.PackService])
], PackController);
//# sourceMappingURL=pack.controller.js.map