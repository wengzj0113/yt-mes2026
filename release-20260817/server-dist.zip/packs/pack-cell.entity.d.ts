import { Pack } from './pack.entity';
export declare class PackCell {
    id: number;
    cellBarcode: string;
    pack: Pack;
    packId: number;
}
