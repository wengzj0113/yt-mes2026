import { PackService } from './pack.service';
import { CreatePackDto } from './dto/create-pack.dto';
export declare class PackController {
    private readonly packService;
    constructor(packService: PackService);
    findAll(page?: string, pageSize?: string): Promise<{
        items: import("./pack.entity").Pack[];
        total: number;
    }>;
    createOrUpdate(dto: CreatePackDto, req: any): Promise<import("./pack.entity").Pack>;
    findByBarcode(barcode: string): Promise<import("./pack.entity").Pack>;
}
