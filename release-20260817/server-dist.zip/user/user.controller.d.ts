import { Request } from 'express';
import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { RegisterUserDto } from './dto/register-user.dto';
export declare class UserController {
    private readonly userService;
    constructor(userService: UserService);
    findAll(): Promise<{
        data: import("./user.entity").User[];
    }>;
    findOperators(): Promise<{
        data: Pick<import("./user.entity").User, "id" | "realName">[];
    }>;
    findQualityPersonnel(): Promise<{
        data: Pick<import("./user.entity").User, "id" | "realName">[];
    }>;
    register(dto: RegisterUserDto): Promise<{
        data: {
            id: number;
        };
        message: string;
    }>;
    create(dto: CreateUserDto): Promise<{
        data: import("./user.entity").User;
        message: string;
    }>;
    update(id: number, dto: UpdateUserDto): Promise<{
        data: import("./user.entity").User;
        message: string;
    }>;
    remove(id: number, req: Request): Promise<{
        message: string;
    }>;
    resetPassword(id: number, password?: string): Promise<{
        message: string;
    }>;
}
