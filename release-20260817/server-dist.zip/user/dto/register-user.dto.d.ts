export declare class RegisterUserDto {
    username: string;
    realName: string;
    password: string;
    roleCode: number;
    phone?: string;
}
