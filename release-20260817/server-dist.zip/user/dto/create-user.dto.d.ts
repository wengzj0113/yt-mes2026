export declare class CreateUserDto {
    username: string;
    realName: string;
    password: string;
    roleCode: number;
    phone?: string;
}
