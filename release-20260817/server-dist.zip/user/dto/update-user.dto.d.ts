export declare class UpdateUserDto {
    realName?: string;
    roleCode?: number;
    phone?: string;
    isActive?: boolean;
}
