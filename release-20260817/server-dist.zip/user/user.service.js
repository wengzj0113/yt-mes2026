"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const user_entity_1 = require("./user.entity");
const bcrypt = require("bcrypt");
const config_1 = require("@nestjs/config");
let UserService = class UserService {
    constructor(userRepo, configService) {
        this.userRepo = userRepo;
        this.configService = configService;
    }
    async findByUsername(username) {
        return this.userRepo.findOne({ where: { username } });
    }
    async findById(id) {
        return this.userRepo.findOne({ where: { id } });
    }
    async findOperators() {
        return this.findByRole(user_entity_1.UserRole.OPERATOR);
    }
    async findByRole(roleCode) {
        const users = await this.userRepo.find({
            where: { roleCode, isActive: true },
            select: ['id', 'realName'],
        });
        return users;
    }
    async findAll() {
        return this.userRepo.find({
            select: ['id', 'username', 'realName', 'roleCode', 'phone', 'isActive', 'createdAt'],
            order: { createdAt: 'DESC' },
        });
    }
    async create(dto) {
        const existing = await this.userRepo.findOne({ where: { username: dto.username } });
        if (existing) {
            throw new common_1.BadRequestException('用户名已存在');
        }
        const salt = await bcrypt.genSalt(12);
        const hashedPassword = await bcrypt.hash(dto.password, salt);
        const userEntity = this.userRepo.create({
            ...dto,
            password: hashedPassword,
        });
        return this.userRepo.save(userEntity);
    }
    async update(id, dto) {
        const user = await this.userRepo.findOne({ where: { id } });
        if (!user) {
            throw new common_1.NotFoundException('用户不存在');
        }
        if (dto.realName !== undefined)
            user.realName = dto.realName;
        if (dto.phone !== undefined)
            user.phone = dto.phone;
        if (dto.isActive !== undefined)
            user.isActive = dto.isActive;
        if (dto.roleCode !== undefined && dto.roleCode >= 1 && dto.roleCode <= 4) {
            user.roleCode = dto.roleCode;
        }
        if (dto.username !== undefined)
            user.username = dto.username;
        if (dto.password) {
            const salt = await bcrypt.genSalt(12);
            user.password = await bcrypt.hash(dto.password, salt);
        }
        return this.userRepo.save(user);
    }
    async remove(id, currentUserId) {
        const user = await this.userRepo.findOne({ where: { id } });
        if (!user) {
            throw new common_1.NotFoundException('用户不存在');
        }
        if (user.roleCode === 4) {
            throw new common_1.BadRequestException('不能删除超级管理员账号');
        }
        if (currentUserId && user.id === currentUserId) {
            throw new common_1.BadRequestException('不能删除自己');
        }
        await this.userRepo.remove(user);
    }
    async resetPassword(id, password) {
        const user = await this.userRepo.findOne({ where: { id } });
        if (!user) {
            throw new common_1.NotFoundException('用户不存在');
        }
        const newPassword = password || this.configService.get('DEFAULT_USER_PASSWORD', 'admin123');
        const salt = await bcrypt.genSalt(12);
        user.password = await bcrypt.hash(newPassword, salt);
        await this.userRepo.save(user);
    }
    async updatePassword(id, hashedPassword) {
        await this.userRepo.update(id, { password: hashedPassword });
    }
    async register(dto) {
        if (dto.roleCode === user_entity_1.UserRole.ADMIN) {
            throw new common_1.BadRequestException('不允许注册为管理员账号');
        }
        const existing = await this.userRepo.findOne({ where: { username: dto.username } });
        if (existing) {
            throw new common_1.BadRequestException('用户名已存在');
        }
        const salt = await bcrypt.genSalt(12);
        const hashedPassword = await bcrypt.hash(dto.password, salt);
        const user = this.userRepo.create({
            username: dto.username,
            realName: dto.realName,
            password: hashedPassword,
            roleCode: dto.roleCode,
            phone: dto.phone || null,
            isActive: true,
        });
        return this.userRepo.save(user);
    }
};
exports.UserService = UserService;
exports.UserService = UserService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        config_1.ConfigService])
], UserService);
//# sourceMappingURL=user.service.js.map