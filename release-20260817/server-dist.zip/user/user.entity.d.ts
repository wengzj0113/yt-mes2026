export declare enum UserRole {
    OPERATOR = 1,
    QUALITY = 2,
    WAREHOUSE = 3,
    ADMIN = 4
}
export declare class User {
    id: number;
    username: string;
    password: string;
    realName: string;
    roleCode: number;
    phone: string | null;
    isActive: boolean;
    loginAttempts: number;
    lockedUntil: Date | null;
    createdAt: Date;
    updatedAt: Date;
}
