import { Repository } from 'typeorm';
import { User } from './user.entity';
import { ConfigService } from '@nestjs/config';
export declare class UserService {
    private readonly userRepo;
    private readonly configService;
    constructor(userRepo: Repository<User>, configService: ConfigService);
    findByUsername(username: string): Promise<User | null>;
    findById(id: number): Promise<User | null>;
    findOperators(): Promise<Pick<User, 'id' | 'realName'>[]>;
    findByRole(roleCode: number): Promise<Pick<User, 'id' | 'realName'>[]>;
    findAll(): Promise<User[]>;
    create(dto: any): Promise<User>;
    update(id: number, dto: any): Promise<User>;
    remove(id: number, currentUserId?: number): Promise<void>;
    resetPassword(id: number, password?: string): Promise<void>;
    updatePassword(id: number, hashedPassword: string): Promise<void>;
    register(dto: any): Promise<User>;
}
