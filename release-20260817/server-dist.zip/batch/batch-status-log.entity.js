"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatchStatusLog = void 0;
const typeorm_1 = require("typeorm");
let BatchStatusLog = class BatchStatusLog {
};
exports.BatchStatusLog = BatchStatusLog;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], BatchStatusLog.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'batch_no', length: 16 }),
    __metadata("design:type", String)
], BatchStatusLog.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'from_status', type: 'tinyint', nullable: true }),
    __metadata("design:type", Object)
], BatchStatusLog.prototype, "fromStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'to_status', type: 'tinyint' }),
    __metadata("design:type", Number)
], BatchStatusLog.prototype, "toStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'changed_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], BatchStatusLog.prototype, "changedBy", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'change_reason', type: 'nvarchar', length: 200, nullable: true }),
    __metadata("design:type", Object)
], BatchStatusLog.prototype, "changeReason", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], BatchStatusLog.prototype, "createdAt", void 0);
exports.BatchStatusLog = BatchStatusLog = __decorate([
    (0, typeorm_1.Entity)('batch_status_log')
], BatchStatusLog);
//# sourceMappingURL=batch-status-log.entity.js.map