export declare class BatchStatusLog {
    id: number;
    batchNo: string;
    fromStatus: number | null;
    toStatus: number;
    changedBy: number | null;
    changeReason: string | null;
    createdAt: Date;
}
