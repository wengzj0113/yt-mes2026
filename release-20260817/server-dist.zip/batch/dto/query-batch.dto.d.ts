import { BatchStatus } from '../batch.entity';
export declare const BATCH_SORT_BY_FIELDS: readonly ["batchNo", "productModel", "status", "actualStartDate", "createdAt", "updatedAt"];
export declare class BatchQueryDto {
    page?: number;
    pageSize?: number;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
    status?: BatchStatus;
    excludeStatus?: number;
    batchNo?: string;
    workshop?: string;
    shift?: string;
    productModel?: string;
}
