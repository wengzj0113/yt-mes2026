export declare class CreateBatchDto {
    batchNo?: string;
    productModel: string;
    productSpec?: string;
    workshop: string;
    shift: string;
    plannedQty: number;
    actualStartDate: string;
    remarks?: string;
}
