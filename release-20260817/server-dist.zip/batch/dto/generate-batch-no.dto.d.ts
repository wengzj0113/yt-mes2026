export declare class GenerateBatchNoDto {
    mnRatio?: string;
}
