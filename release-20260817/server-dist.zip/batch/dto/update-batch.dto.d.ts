export declare class UpdateBatchDto {
    productModel?: string;
    productSpec?: string;
    workshop?: string;
    shift?: string;
    plannedQty?: number;
    actualStartDate?: string;
    remarks?: string;
    status?: number;
}
