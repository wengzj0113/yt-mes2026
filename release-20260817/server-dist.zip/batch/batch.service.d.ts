import { Repository } from 'typeorm';
import { Batch } from './batch.entity';
import { CreateBatchDto } from './dto/create-batch.dto';
import { UpdateBatchDto } from './dto/update-batch.dto';
import { BatchQueryDto } from './dto/query-batch.dto';
import { BatchStatusLog } from './batch-status-log.entity';
import { CellBarcode } from '../cells/cell-barcode.entity';
export declare class BatchService {
    private readonly batchRepo;
    private readonly batchStatusLogRepo;
    private readonly cellBarcodeRepo;
    constructor(batchRepo: Repository<Batch>, batchStatusLogRepo: Repository<BatchStatusLog>, cellBarcodeRepo: Repository<CellBarcode>);
    generateBatchNo(mnRatio?: string): string;
    create(dto: CreateBatchDto, userId: number): Promise<Batch>;
    findAll(query: BatchQueryDto): Promise<{
        items: Batch[];
        meta: {
            page: number;
            pageSize: number;
            total: number;
            totalPages: number;
        };
    }>;
    findByBatchNo(batchNo: string): Promise<Batch | null>;
    update(batchNo: string, dto: UpdateBatchDto, userId: number): Promise<Batch>;
    findStatusLogs(batchNo: string): Promise<BatchStatusLog[]>;
    remove(batchNo: string): Promise<void>;
    private recordStatusLog;
    getDashboardStats(): Promise<{
        totalBatches: number;
        inProgressBatches: number;
        completedBatches: number;
        totalCells: number;
        integrity: number;
        dailyPassRate: number;
        abnormalCount: number;
    }>;
}
