export declare class BatchModule {
}
