"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatchController = void 0;
const common_1 = require("@nestjs/common");
const batch_service_1 = require("./batch.service");
const create_batch_dto_1 = require("./dto/create-batch.dto");
const update_batch_dto_1 = require("./dto/update-batch.dto");
const query_batch_dto_1 = require("./dto/query-batch.dto");
const generate_batch_no_dto_1 = require("./dto/generate-batch-no.dto");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const roles_decorator_1 = require("../common/decorators/roles.decorator");
const user_entity_1 = require("../user/user.entity");
let BatchController = class BatchController {
    constructor(batchService) {
        this.batchService = batchService;
    }
    generateNo(query) {
        const batchNo = this.batchService.generateBatchNo(query.mnRatio);
        return { data: { batchNo } };
    }
    async getDashboardStats() {
        const stats = await this.batchService.getDashboardStats();
        return { data: stats };
    }
    async create(dto, user) {
        const batch = await this.batchService.create(dto, user.sub);
        return { data: batch, message: '创建成功' };
    }
    async findAll(query) {
        return this.batchService.findAll(query);
    }
    async findByBatchNo(batchNo) {
        const batch = await this.batchService.findByBatchNo(batchNo);
        return { data: batch };
    }
    async findStatusLogs(batchNo) {
        const logs = await this.batchService.findStatusLogs(batchNo);
        return { data: logs };
    }
    async update(batchNo, dto, user) {
        const batch = await this.batchService.update(batchNo, dto, user.sub);
        return { data: batch, message: '更新成功' };
    }
    async remove(batchNo) {
        await this.batchService.remove(batchNo);
        return { message: '删除成功' };
    }
};
exports.BatchController = BatchController;
__decorate([
    (0, common_1.Get)('generate-no'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [generate_batch_no_dto_1.GenerateBatchNoDto]),
    __metadata("design:returntype", void 0)
], BatchController.prototype, "generateNo", null);
__decorate([
    (0, common_1.Get)('stats'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BatchController.prototype, "getDashboardStats", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_batch_dto_1.CreateBatchDto, Object]),
    __metadata("design:returntype", Promise)
], BatchController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_batch_dto_1.BatchQueryDto]),
    __metadata("design:returntype", Promise)
], BatchController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':batchNo'),
    __param(0, (0, common_1.Param)('batchNo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BatchController.prototype, "findByBatchNo", null);
__decorate([
    (0, common_1.Get)(':batchNo/status-logs'),
    __param(0, (0, common_1.Param)('batchNo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BatchController.prototype, "findStatusLogs", null);
__decorate([
    (0, common_1.Patch)(':batchNo'),
    __param(0, (0, common_1.Param)('batchNo')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_batch_dto_1.UpdateBatchDto, Object]),
    __metadata("design:returntype", Promise)
], BatchController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':batchNo'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('batchNo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BatchController.prototype, "remove", null);
exports.BatchController = BatchController = __decorate([
    (0, common_1.Controller)('batches'),
    __metadata("design:paramtypes", [batch_service_1.BatchService])
], BatchController);
//# sourceMappingURL=batch.controller.js.map