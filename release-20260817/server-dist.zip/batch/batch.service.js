"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatchService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const batch_entity_1 = require("./batch.entity");
const query_batch_dto_1 = require("./dto/query-batch.dto");
const batch_status_log_entity_1 = require("./batch-status-log.entity");
const cell_barcode_entity_1 = require("../cells/cell-barcode.entity");
let BatchService = class BatchService {
    constructor(batchRepo, batchStatusLogRepo, cellBarcodeRepo) {
        this.batchRepo = batchRepo;
        this.batchStatusLogRepo = batchStatusLogRepo;
        this.cellBarcodeRepo = cellBarcodeRepo;
    }
    generateBatchNo(mnRatio = '01MA') {
        const factoryCode = process.env.FACTORY_CODE || 'WT';
        const year = new Date().getFullYear().toString().slice(2);
        const month = new Date().getMonth();
        const monthLetter = String.fromCharCode(65 + month);
        return `${factoryCode}${year}${monthLetter}${mnRatio}`;
    }
    async create(dto, userId) {
        const batchNo = dto.batchNo || this.generateBatchNo();
        const existing = await this.batchRepo.findOne({ where: { batchNo } });
        if (existing) {
            throw new common_1.ConflictException({ code: 'CONFLICT', message: `批次号 ${batchNo} 已存在` });
        }
        const batch = this.batchRepo.create({
            batchNo,
            productModel: dto.productModel,
            productSpec: dto.productSpec || null,
            workshop: dto.workshop,
            shift: dto.shift,
            plannedQty: dto.plannedQty,
            actualStartDate: new Date(dto.actualStartDate),
            status: batch_entity_1.BatchStatus.IN_PROGRESS,
            remarks: dto.remarks || null,
            createdBy: userId,
        });
        const savedBatch = await this.batchRepo.save(batch);
        await this.recordStatusLog(savedBatch.batchNo, null, savedBatch.status, userId, '批次创建');
        return savedBatch;
    }
    async findAll(query) {
        const page = Number(query.page || 1);
        const pageSize = Number(query.pageSize || 20);
        const sortBy = query_batch_dto_1.BATCH_SORT_BY_FIELDS.includes(query.sortBy)
            ? query.sortBy
            : 'createdAt';
        const sortOrder = query.sortOrder === 'asc' ? 'ASC' : 'DESC';
        const where = {};
        if (query.status) {
            where.status = query.status;
        }
        else if (query.excludeStatus) {
            where.status = (0, typeorm_2.Not)(query.excludeStatus);
        }
        if (query.batchNo)
            where.batchNo = (0, typeorm_2.Like)(`%${query.batchNo}%`);
        if (query.workshop)
            where.workshop = query.workshop;
        if (query.shift)
            where.shift = query.shift;
        if (query.productModel)
            where.productModel = (0, typeorm_2.Like)(`%${query.productModel}%`);
        const [items, total] = await this.batchRepo.findAndCount({
            where,
            order: { [sortBy]: sortOrder },
            skip: (page - 1) * pageSize,
            take: pageSize,
        });
        return {
            items,
            meta: {
                page,
                pageSize,
                total,
                totalPages: Math.ceil(total / pageSize),
            },
        };
    }
    async findByBatchNo(batchNo) {
        return this.batchRepo.findOne({ where: { batchNo } });
    }
    async update(batchNo, dto, userId) {
        const batch = await this.batchRepo.findOne({ where: { batchNo } });
        if (!batch) {
            throw new common_1.NotFoundException({ code: 'BATCH_NOT_FOUND', message: `批次 ${batchNo} 不存在` });
        }
        const previousStatus = batch.status;
        if (dto.productModel !== undefined)
            batch.productModel = dto.productModel;
        if (dto.productSpec !== undefined)
            batch.productSpec = dto.productSpec;
        if (dto.workshop !== undefined)
            batch.workshop = dto.workshop;
        if (dto.shift !== undefined)
            batch.shift = dto.shift;
        if (dto.plannedQty !== undefined)
            batch.plannedQty = dto.plannedQty;
        if (dto.actualStartDate !== undefined)
            batch.actualStartDate = new Date(dto.actualStartDate);
        if (dto.remarks !== undefined)
            batch.remarks = dto.remarks;
        if (dto.status !== undefined)
            batch.status = dto.status;
        batch.updatedBy = userId;
        const savedBatch = await this.batchRepo.save(batch);
        if (dto.status !== undefined && dto.status !== previousStatus) {
            await this.recordStatusLog(batchNo, previousStatus, dto.status, userId, '批次状态更新');
        }
        return savedBatch;
    }
    async findStatusLogs(batchNo) {
        return this.batchStatusLogRepo.find({
            where: { batchNo },
            order: { createdAt: 'DESC' },
        });
    }
    async remove(batchNo) {
        const batch = await this.batchRepo.findOne({ where: { batchNo } });
        if (!batch) {
            throw new common_1.NotFoundException({ code: 'BATCH_NOT_FOUND', message: `批次 ${batchNo} 不存在` });
        }
        await this.batchRepo.remove(batch);
    }
    async recordStatusLog(batchNo, fromStatus, toStatus, changedBy, changeReason) {
        const log = this.batchStatusLogRepo.create({
            batchNo,
            fromStatus,
            toStatus,
            changedBy,
            changeReason,
        });
        await this.batchStatusLogRepo.save(log);
    }
    async getDashboardStats() {
        const [totalBatches, inProgressBatches, completedBatches, totalCells] = await Promise.all([
            this.batchRepo.count(),
            this.batchRepo.count({ where: { status: batch_entity_1.BatchStatus.IN_PROGRESS } }),
            this.batchRepo.count({ where: { status: batch_entity_1.BatchStatus.COMPLETED } }),
            this.cellBarcodeRepo.count(),
        ]);
        const batchesWithBarcodesCount = await this.batchRepo
            .createQueryBuilder('batch')
            .innerJoin('cell_barcode', 'cb', 'cb.batchNo = batch.batchNo')
            .select('COUNT(DISTINCT batch.batchNo)', 'count')
            .getRawOne();
        const integrity = totalBatches > 0
            ? (Number(batchesWithBarcodesCount.count) / totalBatches) * 100
            : 100;
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const todayCells = await this.cellBarcodeRepo.count({
            where: { createdAt: (0, typeorm_2.MoreThanOrEqual)(today) }
        });
        const todayPassCells = await this.cellBarcodeRepo.count({
            where: { createdAt: (0, typeorm_2.MoreThanOrEqual)(today), grade: 'A' }
        });
        const dailyPassRate = todayCells > 0 ? (todayPassCells / todayCells) * 100 : 98.5;
        return {
            totalBatches,
            inProgressBatches,
            completedBatches,
            totalCells,
            integrity: parseFloat(integrity.toFixed(1)),
            dailyPassRate: parseFloat(dailyPassRate.toFixed(1)),
            abnormalCount: 0,
        };
    }
};
exports.BatchService = BatchService;
exports.BatchService = BatchService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(batch_entity_1.Batch)),
    __param(1, (0, typeorm_1.InjectRepository)(batch_status_log_entity_1.BatchStatusLog)),
    __param(2, (0, typeorm_1.InjectRepository)(cell_barcode_entity_1.CellBarcode)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], BatchService);
//# sourceMappingURL=batch.service.js.map