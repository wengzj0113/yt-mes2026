export declare enum BatchStatus {
    DRAFT = 1,
    IN_PROGRESS = 2,
    COMPLETED = 3,
    CLOSED = 4,
    QUALITY_ISSUE = 5
}
export declare class Batch {
    batchNo: string;
    productModel: string;
    productSpec: string | null;
    workshop: string;
    shift: string;
    plannedQty: number;
    actualStartDate: Date;
    status: number;
    remarks: string | null;
    createdBy: number;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date | null;
}
