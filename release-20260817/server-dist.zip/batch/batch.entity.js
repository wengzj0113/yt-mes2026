"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Batch = exports.BatchStatus = void 0;
const typeorm_1 = require("typeorm");
var BatchStatus;
(function (BatchStatus) {
    BatchStatus[BatchStatus["DRAFT"] = 1] = "DRAFT";
    BatchStatus[BatchStatus["IN_PROGRESS"] = 2] = "IN_PROGRESS";
    BatchStatus[BatchStatus["COMPLETED"] = 3] = "COMPLETED";
    BatchStatus[BatchStatus["CLOSED"] = 4] = "CLOSED";
    BatchStatus[BatchStatus["QUALITY_ISSUE"] = 5] = "QUALITY_ISSUE";
})(BatchStatus || (exports.BatchStatus = BatchStatus = {}));
let Batch = class Batch {
    constructor() {
        this.status = BatchStatus.DRAFT;
    }
};
exports.Batch = Batch;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ name: 'batch_no', length: 16 }),
    __metadata("design:type", String)
], Batch.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'product_model', length: 128 }),
    __metadata("design:type", String)
], Batch.prototype, "productModel", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'product_spec', type: 'nvarchar', length: 128, nullable: true }),
    __metadata("design:type", Object)
], Batch.prototype, "productSpec", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'workshop', length: 64 }),
    __metadata("design:type", String)
], Batch.prototype, "workshop", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'shift', length: 32 }),
    __metadata("design:type", String)
], Batch.prototype, "shift", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'planned_qty', type: 'int' }),
    __metadata("design:type", Number)
], Batch.prototype, "plannedQty", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'actual_start_date', type: 'date' }),
    __metadata("design:type", Date)
], Batch.prototype, "actualStartDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: BatchStatus.DRAFT }),
    __metadata("design:type", Number)
], Batch.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remarks', type: 'nvarchar', length: 500, nullable: true }),
    __metadata("design:type", Object)
], Batch.prototype, "remarks", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'created_by', type: 'int' }),
    __metadata("design:type", Number)
], Batch.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], Batch.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'updated_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], Batch.prototype, "updatedBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Object)
], Batch.prototype, "updatedAt", void 0);
exports.Batch = Batch = __decorate([
    (0, typeorm_1.Entity)('batch')
], Batch);
//# sourceMappingURL=batch.entity.js.map