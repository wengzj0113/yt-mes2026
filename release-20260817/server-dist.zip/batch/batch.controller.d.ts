import { BatchService } from './batch.service';
import { CreateBatchDto } from './dto/create-batch.dto';
import { UpdateBatchDto } from './dto/update-batch.dto';
import { BatchQueryDto } from './dto/query-batch.dto';
import { GenerateBatchNoDto } from './dto/generate-batch-no.dto';
import { JwtPayload } from '../common/decorators/current-user.decorator';
export declare class BatchController {
    private readonly batchService;
    constructor(batchService: BatchService);
    generateNo(query: GenerateBatchNoDto): {
        data: {
            batchNo: string;
        };
    };
    getDashboardStats(): Promise<{
        data: {
            totalBatches: number;
            inProgressBatches: number;
            completedBatches: number;
            totalCells: number;
            integrity: number;
            dailyPassRate: number;
            abnormalCount: number;
        };
    }>;
    create(dto: CreateBatchDto, user: JwtPayload): Promise<{
        data: import("./batch.entity").Batch;
        message: string;
    }>;
    findAll(query: BatchQueryDto): Promise<{
        items: import("./batch.entity").Batch[];
        meta: {
            page: number;
            pageSize: number;
            total: number;
            totalPages: number;
        };
    }>;
    findByBatchNo(batchNo: string): Promise<{
        data: import("./batch.entity").Batch | null;
    }>;
    findStatusLogs(batchNo: string): Promise<{
        data: import("./batch-status-log.entity").BatchStatusLog[];
    }>;
    update(batchNo: string, dto: UpdateBatchDto, user: JwtPayload): Promise<{
        data: import("./batch.entity").Batch;
        message: string;
    }>;
    remove(batchNo: string): Promise<{
        message: string;
    }>;
}
