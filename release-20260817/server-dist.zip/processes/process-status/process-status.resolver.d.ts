export type ResolvedProcessStatus = 'not_entered' | 'saved' | 'pending_quality' | 'quality_passed' | 'quality_failed' | 'voided';
export interface StatusResolution {
    status: ResolvedProcessStatus;
    isDraft: boolean | null;
    recordStatus: number | null;
    updatedAt: string | null;
}
export declare function resolveProcessStatus(record: {
    isDraft?: boolean;
    recordStatus?: number;
    updatedAt?: Date | string | null;
} | null, parameter: {
    updatedAt?: Date | string | null;
} | null, quality: {
    hasFailed: boolean;
} | null): StatusResolution;
