"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessStatusModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const process_status_service_1 = require("./process-status.service");
const process_status_controller_1 = require("./process-status.controller");
const process_record_subscriber_1 = require("./process-record.subscriber");
const quality_check_entity_1 = require("../../quality/quality-check.entity");
const batching_module_1 = require("../batching/batching.module");
const coating_module_1 = require("../coating/coating.module");
const roller_pressing_module_1 = require("../roller-pressing/roller-pressing.module");
const slitting_module_1 = require("../slitting/slitting.module");
const sorting_module_1 = require("../sorting/sorting.module");
const electrode_module_1 = require("../electrode/electrode.module");
const winding_module_1 = require("../winding/winding.module");
const assembly_module_1 = require("../assembly/assembly.module");
const baking_module_1 = require("../baking/baking.module");
const injection_module_1 = require("../injection/injection.module");
const wrapping_module_1 = require("../wrapping/wrapping.module");
const formation_module_1 = require("../formation/formation.module");
const grading_module_1 = require("../grading/grading.module");
const process_parameter_entity_1 = require("../../process-parameters/process-parameter.entity");
let ProcessStatusModule = class ProcessStatusModule {
};
exports.ProcessStatusModule = ProcessStatusModule;
exports.ProcessStatusModule = ProcessStatusModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([quality_check_entity_1.QualityCheck, process_parameter_entity_1.ProcessParameter]),
            batching_module_1.BatchingModule,
            coating_module_1.CoatingModule,
            roller_pressing_module_1.RollerPressingModule,
            slitting_module_1.SlittingModule,
            sorting_module_1.SortingModule,
            electrode_module_1.ElectrodeModule,
            winding_module_1.WindingModule,
            assembly_module_1.AssemblyModule,
            baking_module_1.BakingModule,
            injection_module_1.InjectionModule,
            wrapping_module_1.WrappingModule,
            formation_module_1.FormationModule,
            grading_module_1.GradingModule,
        ],
        providers: [process_status_service_1.ProcessStatusService, process_record_subscriber_1.ProcessRecordSubscriber],
        controllers: [process_status_controller_1.ProcessStatusController],
        exports: [process_status_service_1.ProcessStatusService],
    })
], ProcessStatusModule);
//# sourceMappingURL=process-status.module.js.map