export declare class ProcessStatusModule {
}
