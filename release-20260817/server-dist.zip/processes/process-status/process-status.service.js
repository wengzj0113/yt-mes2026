"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessStatusService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("typeorm");
const typeorm_2 = require("@nestjs/typeorm");
const quality_check_entity_1 = require("../../quality/quality-check.entity");
const process_parameter_entity_1 = require("../../process-parameters/process-parameter.entity");
const process_status_resolver_1 = require("./process-status.resolver");
const batching_service_1 = require("../batching/batching.service");
const coating_service_1 = require("../coating/coating.service");
const roller_pressing_service_1 = require("../roller-pressing/roller-pressing.service");
const slitting_service_1 = require("../slitting/slitting.service");
const sorting_service_1 = require("../sorting/sorting.service");
const electrode_service_1 = require("../electrode/electrode.service");
const winding_service_1 = require("../winding/winding.service");
const assembly_service_1 = require("../assembly/assembly.service");
const baking_service_1 = require("../baking/baking.service");
const injection_service_1 = require("../injection/injection.service");
const wrapping_service_1 = require("../wrapping/wrapping.service");
const formation_service_1 = require("../formation/formation.service");
const grading_service_1 = require("../grading/grading.service");
const process_baseline_1 = require("../../master-data/process-baseline");
let ProcessStatusService = class ProcessStatusService {
    constructor(dataSource, qualityCheckRepo, processParameterRepo, batchingService, coatingService, rollerPressingService, slittingService, sortingService, electrodeService, windingService, assemblyService, bakingService, injectionService, wrappingService, formationService, gradingService) {
        this.dataSource = dataSource;
        this.qualityCheckRepo = qualityCheckRepo;
        this.processParameterRepo = processParameterRepo;
        this.batchingService = batchingService;
        this.coatingService = coatingService;
        this.rollerPressingService = rollerPressingService;
        this.slittingService = slittingService;
        this.sortingService = sortingService;
        this.electrodeService = electrodeService;
        this.windingService = windingService;
        this.assemblyService = assemblyService;
        this.bakingService = bakingService;
        this.injectionService = injectionService;
        this.wrappingService = wrappingService;
        this.formationService = formationService;
        this.gradingService = gradingService;
        this.processes = [
            ['batching', '配料'], ['coating', '涂布'], ['roller-pressing', '辊压'], ['slitting', '分切'], ['electrode', '制片'], ['winding', '卷绕'], ['casing', '入壳'], ['integrated-machine', '一体机'], ['laser-welding', '激光焊接'], ['baking', '烘烤'], ['injection', '注液'], ['wrapping', '封口'], ['formation-grading', '化成分容'], ['ocv1', 'OCV1测试'], ['ocv2', 'OCV2测试'], ['sorting', '分选出货（OCV3）'],
        ].map(([key, name]) => ({ key, name, route: key }));
        const services = new Map([['batching', batchingService], ['coating', coatingService], ['roller-pressing', rollerPressingService], ['slitting', slittingService], ['sorting', sortingService], ['electrode', electrodeService], ['winding', windingService], ['assembly', assemblyService], ['baking', bakingService], ['injection', injectionService], ['wrapping', wrappingService], ['formation', formationService], ['grading', gradingService]]);
        this.processes.forEach((process) => process.service = services.get(process.key));
    }
    async getProcessStatuses(batchNo) {
        const results = [];
        for (const proc of this.processes) {
            const dynamic = process_baseline_1.PROCESS_BASELINE.some((item) => item.processCode === proc.key);
            if (dynamic) {
                const rows = await this.findDynamicRecord(proc.key, batchNo);
                if (rows) {
                    results.push(rows);
                    continue;
                }
                if (!proc.service)
                    continue;
            }
            if (proc.service) {
                const record = await proc.service.findByBatchNo(batchNo).catch(() => null);
                if (record)
                    results.push({ processKey: proc.key, isDraft: record.isDraft, recordStatus: record.recordStatus, updatedAt: record.updatedAt });
                continue;
            }
            const table = dynamic ? 'process_dynamic_record' : `${proc.key.replace(/-/g, '_')}_record`;
            const filter = dynamic ? ` AND process_code = '${proc.key}'` : '';
            try {
                const rows = await this.dataSource.query(`SELECT TOP 1 '${proc.key}' AS processKey, is_draft AS isDraft, record_status AS recordStatus, updated_at AS updatedAt FROM ${table} WITH (NOLOCK) WHERE batch_no = @0${filter} ORDER BY id DESC`, [batchNo]);
                if (rows.length)
                    results.push(rows[0]);
            }
            catch { }
        }
        let parameterMap = new Map();
        try {
            parameterMap = new Map((await this.processParameterRepo.find({ where: { batchNo } })).map((record) => [record.processCode, record]));
        }
        catch { }
        let qualityMap = new Map();
        try {
            const qualityRecords = await this.qualityCheckRepo.find({ where: { batchNo } });
            qualityMap = new Map(qualityRecords.map((record) => [record.processType, { hasAny: true, hasFailed: record.inspectionResult === 2 }]));
            for (const record of qualityRecords)
                if (record.inspectionResult === 2)
                    qualityMap.get(record.processType).hasFailed = true;
        }
        catch { }
        const recordMap = new Map(results.map((record) => [record.processKey, record]));
        return this.processes.map((proc) => ({ processKey: proc.key, processName: proc.name, route: proc.route, ...(0, process_status_resolver_1.resolveProcessStatus)(recordMap.get(proc.key), parameterMap.get(proc.key) ?? null, qualityMap.get(proc.key) ?? null) }));
    }
    async getProcessRecords(batchNo) {
        const records = {};
        for (const proc of this.processes) {
            const dynamic = process_baseline_1.PROCESS_BASELINE.some((item) => item.processCode === proc.key);
            if (dynamic) {
                const dynamicRecord = await this.findDynamicFullRecord(proc.key, batchNo);
                if (dynamicRecord) {
                    records[proc.key] = dynamicRecord;
                    continue;
                }
                if (!proc.service) {
                    records[proc.key] = null;
                    continue;
                }
            }
            if (proc.service) {
                records[proc.key] = await proc.service.findByBatchNo(batchNo).catch(() => null);
                continue;
            }
            const table = dynamic ? 'process_dynamic_record' : `${proc.key.replace(/-/g, '_')}_record`;
            const filter = dynamic ? ` AND process_code = '${proc.key}'` : '';
            try {
                const rows = await this.dataSource.query(`SELECT TOP 1 * FROM ${table} WHERE batch_no = @0${filter} ORDER BY id DESC`, [batchNo]);
                const row = rows[0];
                if (!row) {
                    records[proc.key] = null;
                    continue;
                }
                if (row.extra_data)
                    Object.assign(row, JSON.parse(row.extra_data));
                delete row.extra_data;
                records[proc.key] = this.convertToCamelCase(row);
            }
            catch {
                records[proc.key] = null;
            }
        }
        return records;
    }
    async findDynamicRecord(processCode, batchNo) {
        try {
            const rows = await this.dataSource.query(`SELECT TOP 1 '${processCode}' AS processKey, is_draft AS isDraft, record_status AS recordStatus, updated_at AS updatedAt FROM process_dynamic_record WITH (NOLOCK) WHERE batch_no = @0 AND process_code = @1 ORDER BY id DESC`, [batchNo, processCode]);
            return rows[0] ?? null;
        }
        catch {
            return null;
        }
    }
    async findDynamicFullRecord(processCode, batchNo) {
        try {
            const rows = await this.dataSource.query(`SELECT TOP 1 * FROM process_dynamic_record WITH (NOLOCK) WHERE batch_no = @0 AND process_code = @1 ORDER BY id DESC`, [batchNo, processCode]);
            const row = rows[0];
            if (!row)
                return null;
            if (row.extra_data)
                Object.assign(row, JSON.parse(row.extra_data));
            delete row.extra_data;
            return this.convertToCamelCase(row);
        }
        catch {
            return null;
        }
    }
    convertToCamelCase(obj) { if (Array.isArray(obj))
        return obj.map((value) => this.convertToCamelCase(value)); if (obj && obj.constructor === Object)
        return Object.keys(obj).reduce((result, key) => { result[key.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase())] = this.convertToCamelCase(obj[key]); return result; }, {}); return obj; }
};
exports.ProcessStatusService = ProcessStatusService;
exports.ProcessStatusService = ProcessStatusService = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, typeorm_2.InjectRepository)(quality_check_entity_1.QualityCheck)),
    __param(2, (0, typeorm_2.InjectRepository)(process_parameter_entity_1.ProcessParameter)),
    __metadata("design:paramtypes", [typeorm_1.DataSource, typeorm_1.Repository, typeorm_1.Repository, batching_service_1.BatchingService, coating_service_1.CoatingService, roller_pressing_service_1.RollerPressingService, slitting_service_1.SlittingService, sorting_service_1.SortingService, electrode_service_1.ElectrodeService, winding_service_1.WindingService, assembly_service_1.AssemblyService, baking_service_1.BakingService, injection_service_1.InjectionService, wrapping_service_1.WrappingService, formation_service_1.FormationService, grading_service_1.GradingService])
], ProcessStatusService);
//# sourceMappingURL=process-status.service.js.map