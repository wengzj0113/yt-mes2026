"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveProcessStatus = resolveProcessStatus;
function toIso(value) {
    return value ? new Date(value).toISOString() : null;
}
function resolveProcessStatus(record, parameter, quality) {
    if (parameter) {
        return { status: 'saved', isDraft: false, recordStatus: 1, updatedAt: toIso(parameter.updatedAt) };
    }
    if (!record) {
        return { status: 'not_entered', isDraft: null, recordStatus: null, updatedAt: null };
    }
    if (record.recordStatus === 2) {
        return { status: 'voided', isDraft: record.isDraft ?? null, recordStatus: 2, updatedAt: toIso(record.updatedAt) };
    }
    if (record.isDraft) {
        return { status: 'saved', isDraft: true, recordStatus: record.recordStatus ?? null, updatedAt: toIso(record.updatedAt) };
    }
    return {
        status: quality ? (quality.hasFailed ? 'quality_failed' : 'quality_passed') : 'pending_quality',
        isDraft: false,
        recordStatus: record.recordStatus ?? null,
        updatedAt: toIso(record.updatedAt),
    };
}
//# sourceMappingURL=process-status.resolver.js.map