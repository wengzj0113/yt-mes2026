import { ProcessStatusService } from './process-status.service';
export declare class ProcessStatusController {
    private readonly processStatusService;
    constructor(processStatusService: ProcessStatusService);
    getStatus(batchNo: string): Promise<{
        data: import("./process-status.service").ProcessStatusItem[];
    }>;
    getRecords(batchNo: string): Promise<{
        data: Record<string, any>;
    }>;
}
