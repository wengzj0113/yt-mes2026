"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessStatusController = void 0;
const common_1 = require("@nestjs/common");
const process_status_service_1 = require("./process-status.service");
let ProcessStatusController = class ProcessStatusController {
    constructor(processStatusService) {
        this.processStatusService = processStatusService;
    }
    async getStatus(batchNo) {
        const data = await this.processStatusService.getProcessStatuses(batchNo);
        return { data };
    }
    async getRecords(batchNo) {
        const data = await this.processStatusService.getProcessRecords(batchNo);
        return { data };
    }
};
exports.ProcessStatusController = ProcessStatusController;
__decorate([
    (0, common_1.Get)('status/:batchNo'),
    __param(0, (0, common_1.Param)('batchNo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ProcessStatusController.prototype, "getStatus", null);
__decorate([
    (0, common_1.Get)('records/:batchNo'),
    __param(0, (0, common_1.Param)('batchNo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ProcessStatusController.prototype, "getRecords", null);
exports.ProcessStatusController = ProcessStatusController = __decorate([
    (0, common_1.Controller)('processes'),
    __metadata("design:paramtypes", [process_status_service_1.ProcessStatusService])
], ProcessStatusController);
//# sourceMappingURL=process-status.controller.js.map