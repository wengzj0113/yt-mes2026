import { EntitySubscriberInterface, UpdateEvent, InsertEvent, DataSource } from 'typeorm';
import { EventEmitter2 } from '@nestjs/event-emitter';
export declare class ProcessRecordSubscriber implements EntitySubscriberInterface {
    private readonly dataSource;
    private readonly eventEmitter;
    constructor(dataSource: DataSource, eventEmitter: EventEmitter2);
    afterInsert(event: InsertEvent<any>): void;
    afterUpdate(event: UpdateEvent<any>): void;
    private handleEvent;
}
