import { Repository } from 'typeorm';
import { SlittingRecord } from './slitting-record.entity';
import { Batch } from '../../batch/batch.entity';
import { QualityCheck } from '../../quality/quality-check.entity';
import { CreateSlittingDraftDto } from './dto/create-draft.dto';
export declare class SlittingService {
    private readonly repo;
    private readonly batchRepo;
    private readonly qualityCheckRepo;
    constructor(repo: Repository<SlittingRecord>, batchRepo: Repository<Batch>, qualityCheckRepo: Repository<QualityCheck>);
    private validateBatch;
    createDraft(dto: CreateSlittingDraftDto, userId: number): Promise<SlittingRecord>;
    submitQuality(batchNo: string, userId: number): Promise<SlittingRecord>;
    findByBatchNo(batchNo: string): Promise<SlittingRecord | null>;
    voidRecord(batchNo: string, userId: number): Promise<SlittingRecord>;
}
