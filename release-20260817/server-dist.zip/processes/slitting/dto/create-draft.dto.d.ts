export declare class CreateSlittingDraftDto {
    batchNo: string;
    equipmentCode: string;
    electrodeWidth: number;
    electrodeLength: number;
    slittingSpeed?: number;
    operatorName: string;
}
