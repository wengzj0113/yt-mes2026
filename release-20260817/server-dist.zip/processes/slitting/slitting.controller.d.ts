import { SlittingService } from './slitting.service';
import { CreateSlittingDraftDto } from './dto/create-draft.dto';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
export declare class SlittingController {
    private readonly slittingService;
    constructor(slittingService: SlittingService);
    createDraft(dto: CreateSlittingDraftDto, user: JwtPayload): Promise<{
        data: import("./slitting-record.entity").SlittingRecord;
        message: string;
    }>;
    submitQuality(batchNo: string, user: JwtPayload): Promise<{
        data: import("./slitting-record.entity").SlittingRecord;
        message: string;
    }>;
    findByBatchNo(batchNo: string): Promise<{
        data: import("./slitting-record.entity").SlittingRecord | null;
    }>;
    voidRecord(batchNo: string, user: JwtPayload): Promise<{
        data: import("./slitting-record.entity").SlittingRecord;
        message: string;
    }>;
}
