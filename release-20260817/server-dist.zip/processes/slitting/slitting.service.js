"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SlittingService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const slitting_record_entity_1 = require("./slitting-record.entity");
const batch_entity_1 = require("../../batch/batch.entity");
const quality_check_entity_1 = require("../../quality/quality-check.entity");
const process_record_util_1 = require("../../common/utils/process-record.util");
const SLITTING_ENTITY_FIELDS = [
    'equipmentCode', 'electrodeWidth', 'electrodeLength', 'slittingSpeed', 'operatorName'
];
let SlittingService = class SlittingService {
    constructor(repo, batchRepo, qualityCheckRepo) {
        this.repo = repo;
        this.batchRepo = batchRepo;
        this.qualityCheckRepo = qualityCheckRepo;
    }
    async validateBatch(batchNo) {
        const batch = await this.batchRepo.findOne({ where: { batchNo } });
        if (!batch) {
            throw new common_1.NotFoundException({ code: 'BATCH_NOT_FOUND', message: `批次 ${batchNo} 不存在` });
        }
        return batch;
    }
    async createDraft(dto, userId) {
        await this.validateBatch(dto.batchNo);
        const existing = await this.repo.findOne({ where: { batchNo: dto.batchNo } });
        if (existing) {
            (0, process_record_util_1.mergeExtraData)(existing, dto, SLITTING_ENTITY_FIELDS);
            existing.updatedBy = userId;
            return this.repo.save(existing);
        }
        const record = this.repo.create({
            batchNo: dto.batchNo,
            createdBy: userId,
        });
        (0, process_record_util_1.mergeExtraData)(record, dto, SLITTING_ENTITY_FIELDS);
        return this.repo.save(record);
    }
    async submitQuality(batchNo, userId) {
        await this.validateBatch(batchNo);
        const record = await this.repo.findOne({ where: { batchNo } });
        if (!record) {
            throw new common_1.NotFoundException({ code: 'PROCESS_DRAFT_EXISTS', message: '未找到分切草稿记录' });
        }
        if (!record.equipmentCode || !record.electrodeWidth || !record.electrodeLength || !record.operatorName) {
            throw new common_1.BadRequestException({
                code: 'PROCESS_FIELDS_INCOMPLETE',
                message: '操作员字段未填写完整，请先保存草稿',
            });
        }
        record.isDraft = false;
        record.updatedBy = userId;
        const saved = await this.repo.save(record);
        return saved;
    }
    async findByBatchNo(batchNo) {
        return this.repo.findOne({ where: { batchNo } });
    }
    async voidRecord(batchNo, userId) {
        const record = await this.repo.findOne({ where: { batchNo } });
        if (!record) {
            throw new common_1.NotFoundException({ code: 'PROCESS_DRAFT_EXISTS', message: '未找到分切记录' });
        }
        if (record.recordStatus === 2) {
            throw new common_1.BadRequestException({ code: 'PROCESS_ALREADY_SUBMITTED', message: '记录已被作废' });
        }
        record.recordStatus = 2;
        record.updatedBy = userId;
        return this.repo.save(record);
    }
};
exports.SlittingService = SlittingService;
exports.SlittingService = SlittingService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(slitting_record_entity_1.SlittingRecord)),
    __param(1, (0, typeorm_1.InjectRepository)(batch_entity_1.Batch)),
    __param(2, (0, typeorm_1.InjectRepository)(quality_check_entity_1.QualityCheck)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], SlittingService);
//# sourceMappingURL=slitting.service.js.map