export declare class SlittingModule {
}
