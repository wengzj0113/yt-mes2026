export declare class InjectionRecord {
    id: number;
    batchNo: string;
    recordStatus: number;
    isDraft: boolean;
    equipmentCode: string;
    electrolyteModel: string;
    injectionAmount: number | null;
    injectionHumidity: number | null;
    injectionTemperature: number | null;
    sealingDimension: number | null;
    cleaningRecord: string | null;
    operatorName: string;
    extraData: string;
    createdBy: number;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date | null;
}
