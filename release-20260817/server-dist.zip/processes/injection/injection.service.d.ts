import { Repository } from 'typeorm';
import { InjectionRecord } from './injection-record.entity';
import { Batch } from '../../batch/batch.entity';
import { QualityCheck } from '../../quality/quality-check.entity';
import { CreateInjectionDraftDto } from './dto/create-draft.dto';
import { SubmitInjectionQualityDto } from './dto/submit-quality.dto';
export declare class InjectionService {
    private readonly repo;
    private readonly batchRepo;
    private readonly qualityCheckRepo;
    constructor(repo: Repository<InjectionRecord>, batchRepo: Repository<Batch>, qualityCheckRepo: Repository<QualityCheck>);
    private validateBatch;
    createDraft(dto: CreateInjectionDraftDto, userId: number): Promise<InjectionRecord>;
    submitQuality(dto: SubmitInjectionQualityDto, userId: number): Promise<InjectionRecord>;
    findByBatchNo(batchNo: string): Promise<InjectionRecord | null>;
    voidRecord(batchNo: string, userId: number): Promise<InjectionRecord>;
}
