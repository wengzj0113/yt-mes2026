import { InjectionService } from './injection.service';
import { CreateInjectionDraftDto } from './dto/create-draft.dto';
import { SubmitInjectionQualityDto } from './dto/submit-quality.dto';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
export declare class InjectionController {
    private readonly injectionService;
    constructor(injectionService: InjectionService);
    createDraft(dto: CreateInjectionDraftDto, user: JwtPayload): Promise<{
        data: import("./injection-record.entity").InjectionRecord;
        message: string;
    }>;
    submitQuality(dto: SubmitInjectionQualityDto, user: JwtPayload): Promise<{
        data: import("./injection-record.entity").InjectionRecord;
        message: string;
    }>;
    findByBatchNo(batchNo: string): Promise<{
        data: import("./injection-record.entity").InjectionRecord | null;
    }>;
    voidRecord(batchNo: string, user: JwtPayload): Promise<{
        data: import("./injection-record.entity").InjectionRecord;
        message: string;
    }>;
}
