"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InjectionRecord = void 0;
const typeorm_1 = require("typeorm");
let InjectionRecord = class InjectionRecord {
    constructor() {
        this.recordStatus = 1;
        this.isDraft = true;
    }
};
exports.InjectionRecord = InjectionRecord;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], InjectionRecord.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)({ name: 'batch_no', length: 16 }),
    __metadata("design:type", String)
], InjectionRecord.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'record_status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], InjectionRecord.prototype, "recordStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'is_draft', default: true }),
    __metadata("design:type", Boolean)
], InjectionRecord.prototype, "isDraft", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'equipment_code', length: 16 }),
    __metadata("design:type", String)
], InjectionRecord.prototype, "equipmentCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'electrolyte_model', length: 128 }),
    __metadata("design:type", String)
], InjectionRecord.prototype, "electrolyteModel", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'injection_amount', type: 'decimal', precision: 8, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], InjectionRecord.prototype, "injectionAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'injection_humidity', type: 'decimal', precision: 8, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], InjectionRecord.prototype, "injectionHumidity", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'injection_temperature', type: 'decimal', precision: 8, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], InjectionRecord.prototype, "injectionTemperature", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'sealing_dimension', type: 'decimal', precision: 8, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], InjectionRecord.prototype, "sealingDimension", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'cleaning_record', type: 'nvarchar', length: 256, nullable: true }),
    __metadata("design:type", Object)
], InjectionRecord.prototype, "cleaningRecord", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'operator_name', length: 32 }),
    __metadata("design:type", String)
], InjectionRecord.prototype, "operatorName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'nvarchar', length: 'max', nullable: true, name: 'extra_data' }),
    __metadata("design:type", String)
], InjectionRecord.prototype, "extraData", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'created_by', type: 'int' }),
    __metadata("design:type", Number)
], InjectionRecord.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], InjectionRecord.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'updated_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], InjectionRecord.prototype, "updatedBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Object)
], InjectionRecord.prototype, "updatedAt", void 0);
exports.InjectionRecord = InjectionRecord = __decorate([
    (0, typeorm_1.Entity)('injection_record')
], InjectionRecord);
//# sourceMappingURL=injection-record.entity.js.map