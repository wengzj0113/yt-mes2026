export declare class CreateInjectionDraftDto {
    batchNo: string;
    equipmentCode: string;
    electrolyteModel: string;
    operatorName: string;
}
