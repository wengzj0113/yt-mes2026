export declare class SubmitInjectionQualityDto {
    batchNo: string;
    operatorName?: string;
    injectionAmount: number;
    injectionHumidity: number;
    injectionTemperature: number;
    sealingDimension: number;
    cleaningRecord: string;
}
