"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InjectionModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const injection_record_entity_1 = require("./injection-record.entity");
const injection_service_1 = require("./injection.service");
const injection_controller_1 = require("./injection.controller");
const batch_entity_1 = require("../../batch/batch.entity");
const quality_check_entity_1 = require("../../quality/quality-check.entity");
let InjectionModule = class InjectionModule {
};
exports.InjectionModule = InjectionModule;
exports.InjectionModule = InjectionModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([injection_record_entity_1.InjectionRecord, batch_entity_1.Batch, quality_check_entity_1.QualityCheck])],
        providers: [injection_service_1.InjectionService],
        controllers: [injection_controller_1.InjectionController],
        exports: [injection_service_1.InjectionService],
    })
], InjectionModule);
//# sourceMappingURL=injection.module.js.map