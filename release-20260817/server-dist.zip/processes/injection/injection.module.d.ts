export declare class InjectionModule {
}
