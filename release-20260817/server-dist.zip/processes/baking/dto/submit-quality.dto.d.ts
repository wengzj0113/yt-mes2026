export declare class SubmitBakingQualityDto {
    batchNo: string;
    operatorName?: string;
    vacuumLevel: number;
    moistureAfterBaking: number;
}
