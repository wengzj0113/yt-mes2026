export declare class CreateBakingDraftDto {
    batchNo: string;
    equipmentCode: string;
    bakingTemperature: number;
    bakingDuration: number;
    operatorName: string;
}
