import { BakingService } from './baking.service';
import { CreateBakingDraftDto } from './dto/create-draft.dto';
import { SubmitBakingQualityDto } from './dto/submit-quality.dto';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
export declare class BakingController {
    private readonly bakingService;
    constructor(bakingService: BakingService);
    createDraft(dto: CreateBakingDraftDto, user: JwtPayload): Promise<{
        data: import("./baking-record.entity").BakingRecord;
        message: string;
    }>;
    submitQuality(dto: SubmitBakingQualityDto, user: JwtPayload): Promise<{
        data: import("./baking-record.entity").BakingRecord;
        message: string;
    }>;
    findByBatchNo(batchNo: string): Promise<{
        data: import("./baking-record.entity").BakingRecord | null;
    }>;
    voidRecord(batchNo: string, user: JwtPayload): Promise<{
        data: import("./baking-record.entity").BakingRecord;
        message: string;
    }>;
}
