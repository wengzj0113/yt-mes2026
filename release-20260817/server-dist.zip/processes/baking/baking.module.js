"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BakingModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const baking_record_entity_1 = require("./baking-record.entity");
const baking_service_1 = require("./baking.service");
const baking_controller_1 = require("./baking.controller");
const batch_entity_1 = require("../../batch/batch.entity");
const quality_check_entity_1 = require("../../quality/quality-check.entity");
let BakingModule = class BakingModule {
};
exports.BakingModule = BakingModule;
exports.BakingModule = BakingModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([baking_record_entity_1.BakingRecord, batch_entity_1.Batch, quality_check_entity_1.QualityCheck])],
        providers: [baking_service_1.BakingService],
        controllers: [baking_controller_1.BakingController],
        exports: [baking_service_1.BakingService],
    })
], BakingModule);
//# sourceMappingURL=baking.module.js.map