export declare class BakingRecord {
    id: number;
    batchNo: string;
    recordStatus: number;
    isDraft: boolean;
    equipmentCode: string;
    bakingTemperature: number;
    bakingDuration: number;
    vacuumLevel: number | null;
    moistureAfterBaking: number | null;
    operatorName: string;
    extraData: string;
    createdBy: number;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date | null;
}
