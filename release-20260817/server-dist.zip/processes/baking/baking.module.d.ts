export declare class BakingModule {
}
