import { Repository } from 'typeorm';
import { BakingRecord } from './baking-record.entity';
import { Batch } from '../../batch/batch.entity';
import { QualityCheck } from '../../quality/quality-check.entity';
import { CreateBakingDraftDto } from './dto/create-draft.dto';
import { SubmitBakingQualityDto } from './dto/submit-quality.dto';
export declare class BakingService {
    private readonly repo;
    private readonly batchRepo;
    private readonly qualityCheckRepo;
    constructor(repo: Repository<BakingRecord>, batchRepo: Repository<Batch>, qualityCheckRepo: Repository<QualityCheck>);
    private validateBatch;
    createDraft(dto: CreateBakingDraftDto, userId: number): Promise<BakingRecord>;
    submitQuality(dto: SubmitBakingQualityDto, userId: number): Promise<BakingRecord>;
    findByBatchNo(batchNo: string): Promise<BakingRecord | null>;
    voidRecord(batchNo: string, userId: number): Promise<BakingRecord>;
}
