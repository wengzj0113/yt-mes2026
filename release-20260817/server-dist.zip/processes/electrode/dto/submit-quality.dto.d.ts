export declare class SubmitElectrodeQualityDto {
    batchNo: string;
    operatorName?: string;
    tabWeldingPull: number;
}
