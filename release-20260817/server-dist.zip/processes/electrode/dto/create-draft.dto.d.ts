export declare class CreateElectrodeDraftDto {
    batchNo: string;
    tabMaterialSpec: string;
    electrodeLength: string;
    operatorName: string;
}
