import { Repository, DataSource } from 'typeorm';
import { ElectrodeRecord } from './electrode-record.entity';
import { Batch } from '../../batch/batch.entity';
import { QualityCheck } from '../../quality/quality-check.entity';
import { CreateElectrodeDraftDto } from './dto/create-draft.dto';
import { SubmitElectrodeQualityDto } from './dto/submit-quality.dto';
export declare class ElectrodeService {
    private readonly repo;
    private readonly batchRepo;
    private readonly qualityCheckRepo;
    private readonly dataSource;
    constructor(repo: Repository<ElectrodeRecord>, batchRepo: Repository<Batch>, qualityCheckRepo: Repository<QualityCheck>, dataSource: DataSource);
    private validateBatch;
    createDraft(dto: CreateElectrodeDraftDto, userId: number): Promise<ElectrodeRecord>;
    submitQuality(dto: SubmitElectrodeQualityDto, userId: number): Promise<ElectrodeRecord>;
    findByBatchNo(batchNo: string): Promise<ElectrodeRecord | null>;
    voidRecord(batchNo: string, userId: number): Promise<ElectrodeRecord>;
}
