import { ElectrodeService } from './electrode.service';
import { CreateElectrodeDraftDto } from './dto/create-draft.dto';
import { SubmitElectrodeQualityDto } from './dto/submit-quality.dto';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
export declare class ElectrodeController {
    private readonly electrodeService;
    constructor(electrodeService: ElectrodeService);
    createDraft(dto: CreateElectrodeDraftDto, user: JwtPayload): Promise<{
        data: import("./electrode-record.entity").ElectrodeRecord;
        message: string;
    }>;
    submitQuality(dto: SubmitElectrodeQualityDto, user: JwtPayload): Promise<{
        data: import("./electrode-record.entity").ElectrodeRecord;
        message: string;
    }>;
    findByBatchNo(batchNo: string): Promise<{
        data: import("./electrode-record.entity").ElectrodeRecord | null;
    }>;
    voidRecord(batchNo: string, user: JwtPayload): Promise<{
        data: import("./electrode-record.entity").ElectrodeRecord;
        message: string;
    }>;
}
