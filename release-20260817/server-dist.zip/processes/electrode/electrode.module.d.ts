export declare class ElectrodeModule {
}
