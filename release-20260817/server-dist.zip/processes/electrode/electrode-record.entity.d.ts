export declare class ElectrodeRecord {
    id: number;
    batchNo: string;
    recordStatus: number;
    isDraft: boolean;
    tabMaterialSpec: string;
    electrodeLength: string;
    tabWeldingPull: string | null;
    operatorName: string;
    extraData: string;
    createdBy: number;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date | null;
}
