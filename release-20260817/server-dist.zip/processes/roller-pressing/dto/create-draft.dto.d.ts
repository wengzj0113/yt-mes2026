export declare class CreateRollerPressingDraftDto {
    batchNo: string;
    equipmentCode: string;
    rollerPressure: number;
    rollerThickness: number;
    rollerSpeed?: number;
    operatorName: string;
}
