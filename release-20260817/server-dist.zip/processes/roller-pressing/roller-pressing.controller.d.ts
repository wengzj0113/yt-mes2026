import { RollerPressingService } from './roller-pressing.service';
import { CreateRollerPressingDraftDto } from './dto/create-draft.dto';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
export declare class RollerPressingController {
    private readonly rollerPressingService;
    constructor(rollerPressingService: RollerPressingService);
    createDraft(dto: CreateRollerPressingDraftDto, user: JwtPayload): Promise<{
        data: import("./roller-pressing-record.entity").RollerPressingRecord;
        message: string;
    }>;
    submitQuality(batchNo: string, user: JwtPayload): Promise<{
        data: import("./roller-pressing-record.entity").RollerPressingRecord;
        message: string;
    }>;
    findByBatchNo(batchNo: string): Promise<{
        data: import("./roller-pressing-record.entity").RollerPressingRecord | null;
    }>;
    voidRecord(batchNo: string, user: JwtPayload): Promise<{
        data: import("./roller-pressing-record.entity").RollerPressingRecord;
        message: string;
    }>;
}
