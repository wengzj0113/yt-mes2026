import { Repository } from 'typeorm';
import { RollerPressingRecord } from './roller-pressing-record.entity';
import { Batch } from '../../batch/batch.entity';
import { QualityCheck } from '../../quality/quality-check.entity';
import { CreateRollerPressingDraftDto } from './dto/create-draft.dto';
export declare class RollerPressingService {
    private readonly repo;
    private readonly batchRepo;
    private readonly qualityCheckRepo;
    constructor(repo: Repository<RollerPressingRecord>, batchRepo: Repository<Batch>, qualityCheckRepo: Repository<QualityCheck>);
    private validateBatch;
    createDraft(dto: CreateRollerPressingDraftDto, userId: number): Promise<RollerPressingRecord>;
    submitQuality(batchNo: string, userId: number): Promise<RollerPressingRecord>;
    findByBatchNo(batchNo: string): Promise<RollerPressingRecord | null>;
    voidRecord(batchNo: string, userId: number): Promise<RollerPressingRecord>;
}
