export declare class RollerPressingModule {
}
