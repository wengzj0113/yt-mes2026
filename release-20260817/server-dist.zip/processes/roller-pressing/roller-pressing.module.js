"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RollerPressingModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const roller_pressing_record_entity_1 = require("./roller-pressing-record.entity");
const roller_pressing_service_1 = require("./roller-pressing.service");
const roller_pressing_controller_1 = require("./roller-pressing.controller");
const batch_entity_1 = require("../../batch/batch.entity");
const quality_check_entity_1 = require("../../quality/quality-check.entity");
let RollerPressingModule = class RollerPressingModule {
};
exports.RollerPressingModule = RollerPressingModule;
exports.RollerPressingModule = RollerPressingModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([roller_pressing_record_entity_1.RollerPressingRecord, batch_entity_1.Batch, quality_check_entity_1.QualityCheck])],
        providers: [roller_pressing_service_1.RollerPressingService],
        controllers: [roller_pressing_controller_1.RollerPressingController],
        exports: [roller_pressing_service_1.RollerPressingService],
    })
], RollerPressingModule);
//# sourceMappingURL=roller-pressing.module.js.map