import { Repository } from 'typeorm';
import { SortingRecord } from './sorting-record.entity';
import { Batch } from '../../batch/batch.entity';
import { QualityCheck } from '../../quality/quality-check.entity';
import { CreateSortingDraftDto } from './dto/create-draft.dto';
export declare class SortingService {
    private readonly repo;
    private readonly batchRepo;
    private readonly qualityCheckRepo;
    constructor(repo: Repository<SortingRecord>, batchRepo: Repository<Batch>, qualityCheckRepo: Repository<QualityCheck>);
    private validateBatch;
    createDraft(dto: CreateSortingDraftDto, userId: number): Promise<SortingRecord>;
    submitQuality(batchNo: string, userId: number): Promise<SortingRecord>;
    findByBatchNo(batchNo: string): Promise<SortingRecord | null>;
    voidRecord(batchNo: string, userId: number): Promise<SortingRecord>;
}
