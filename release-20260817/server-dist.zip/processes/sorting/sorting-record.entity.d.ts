export declare class SortingRecord {
    id: number;
    batchNo: string;
    recordStatus: number;
    isDraft: boolean;
    equipmentCode: string;
    ocvVoltageRange: string;
    ocvVoltageMin: number | null;
    ocvVoltageMax: number | null;
    irRange: string;
    irMin: number | null;
    irMax: number | null;
    capacityRange: string;
    capacityMin: number | null;
    capacityMax: number | null;
    operatorName: string;
    extraData: string;
    createdBy: number;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date | null;
}
