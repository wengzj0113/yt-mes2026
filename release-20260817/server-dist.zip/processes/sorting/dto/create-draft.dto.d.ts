export declare class CreateSortingDraftDto {
    batchNo: string;
    equipmentCode: string;
    ocvVoltageMin?: number | null;
    ocvVoltageMax?: number | null;
    irMin?: number | null;
    irMax?: number | null;
    capacityMin?: number | null;
    capacityMax?: number | null;
    operatorName: string;
}
