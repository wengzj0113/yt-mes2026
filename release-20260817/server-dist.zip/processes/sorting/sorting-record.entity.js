"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SortingRecord = void 0;
const typeorm_1 = require("typeorm");
let SortingRecord = class SortingRecord {
    constructor() {
        this.recordStatus = 1;
        this.isDraft = true;
    }
};
exports.SortingRecord = SortingRecord;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], SortingRecord.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)({ name: 'batch_no', length: 16 }),
    __metadata("design:type", String)
], SortingRecord.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'record_status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], SortingRecord.prototype, "recordStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'is_draft', default: true }),
    __metadata("design:type", Boolean)
], SortingRecord.prototype, "isDraft", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'equipment_code', length: 16 }),
    __metadata("design:type", String)
], SortingRecord.prototype, "equipmentCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ocv_voltage_range', length: 500, nullable: true }),
    __metadata("design:type", String)
], SortingRecord.prototype, "ocvVoltageRange", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ocv_voltage_min', type: 'decimal', precision: 10, scale: 4, nullable: true }),
    __metadata("design:type", Object)
], SortingRecord.prototype, "ocvVoltageMin", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ocv_voltage_max', type: 'decimal', precision: 10, scale: 4, nullable: true }),
    __metadata("design:type", Object)
], SortingRecord.prototype, "ocvVoltageMax", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ir_range', length: 500, nullable: true }),
    __metadata("design:type", String)
], SortingRecord.prototype, "irRange", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ir_min', type: 'decimal', precision: 10, scale: 4, nullable: true }),
    __metadata("design:type", Object)
], SortingRecord.prototype, "irMin", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ir_max', type: 'decimal', precision: 10, scale: 4, nullable: true }),
    __metadata("design:type", Object)
], SortingRecord.prototype, "irMax", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'capacity_range', length: 500, nullable: true }),
    __metadata("design:type", String)
], SortingRecord.prototype, "capacityRange", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'capacity_min', type: 'decimal', precision: 10, scale: 4, nullable: true }),
    __metadata("design:type", Object)
], SortingRecord.prototype, "capacityMin", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'capacity_max', type: 'decimal', precision: 10, scale: 4, nullable: true }),
    __metadata("design:type", Object)
], SortingRecord.prototype, "capacityMax", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'operator_name', length: 32 }),
    __metadata("design:type", String)
], SortingRecord.prototype, "operatorName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'nvarchar', length: 'max', nullable: true, name: 'extra_data' }),
    __metadata("design:type", String)
], SortingRecord.prototype, "extraData", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'created_by', type: 'int' }),
    __metadata("design:type", Number)
], SortingRecord.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], SortingRecord.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'updated_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], SortingRecord.prototype, "updatedBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Object)
], SortingRecord.prototype, "updatedAt", void 0);
exports.SortingRecord = SortingRecord = __decorate([
    (0, typeorm_1.Entity)('sorting_record')
], SortingRecord);
//# sourceMappingURL=sorting-record.entity.js.map