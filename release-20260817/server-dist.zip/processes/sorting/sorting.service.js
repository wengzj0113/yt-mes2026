"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SortingService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const sorting_record_entity_1 = require("./sorting-record.entity");
const batch_entity_1 = require("../../batch/batch.entity");
const quality_check_entity_1 = require("../../quality/quality-check.entity");
const process_record_util_1 = require("../../common/utils/process-record.util");
const SORTING_ENTITY_FIELDS = [
    'equipmentCode',
    'ocvVoltageMin', 'ocvVoltageMax',
    'irMin', 'irMax',
    'capacityMin', 'capacityMax',
    'operatorName',
];
function assertRange(fieldLabel, min, max) {
    if (min == null || max == null)
        return;
    if (Number(min) > Number(max)) {
        throw new common_1.BadRequestException({
            code: 'PROCESS_RANGE_INVALID',
            message: `${fieldLabel} 范围的最小值不能大于最大值`,
        });
    }
}
let SortingService = class SortingService {
    constructor(repo, batchRepo, qualityCheckRepo) {
        this.repo = repo;
        this.batchRepo = batchRepo;
        this.qualityCheckRepo = qualityCheckRepo;
    }
    async validateBatch(batchNo) {
        const batch = await this.batchRepo.findOne({ where: { batchNo } });
        if (!batch) {
            throw new common_1.NotFoundException({ code: 'BATCH_NOT_FOUND', message: `批次 ${batchNo} 不存在` });
        }
        return batch;
    }
    async createDraft(dto, userId) {
        await this.validateBatch(dto.batchNo);
        const existing = await this.repo.findOne({ where: { batchNo: dto.batchNo } });
        if (existing) {
            (0, process_record_util_1.mergeExtraData)(existing, dto, SORTING_ENTITY_FIELDS);
            existing.updatedBy = userId;
            return this.repo.save(existing);
        }
        const record = this.repo.create({
            batchNo: dto.batchNo,
            createdBy: userId,
        });
        (0, process_record_util_1.mergeExtraData)(record, dto, SORTING_ENTITY_FIELDS);
        return this.repo.save(record);
    }
    async submitQuality(batchNo, userId) {
        await this.validateBatch(batchNo);
        const record = await this.repo.findOne({ where: { batchNo } });
        if (!record) {
            throw new common_1.NotFoundException({ code: 'PROCESS_DRAFT_EXISTS', message: '未找到分选草稿记录' });
        }
        if (!record.equipmentCode ||
            record.ocvVoltageMin == null || record.ocvVoltageMax == null ||
            record.irMin == null || record.irMax == null ||
            record.capacityMin == null || record.capacityMax == null ||
            !record.operatorName) {
            throw new common_1.BadRequestException({
                code: 'PROCESS_FIELDS_INCOMPLETE',
                message: '操作员字段未填写完整，请先保存草稿',
            });
        }
        assertRange('OCV电压', record.ocvVoltageMin, record.ocvVoltageMax);
        assertRange('内阻', record.irMin, record.irMax);
        assertRange('容量', record.capacityMin, record.capacityMax);
        record.isDraft = false;
        record.updatedBy = userId;
        const saved = await this.repo.save(record);
        return saved;
    }
    async findByBatchNo(batchNo) {
        return this.repo.findOne({ where: { batchNo } });
    }
    async voidRecord(batchNo, userId) {
        const record = await this.repo.findOne({ where: { batchNo } });
        if (!record) {
            throw new common_1.NotFoundException({ code: 'PROCESS_DRAFT_EXISTS', message: '未找到分选记录' });
        }
        if (record.recordStatus === 2) {
            throw new common_1.BadRequestException({ code: 'PROCESS_ALREADY_SUBMITTED', message: '记录已被作废' });
        }
        record.recordStatus = 2;
        record.updatedBy = userId;
        return this.repo.save(record);
    }
};
exports.SortingService = SortingService;
exports.SortingService = SortingService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(sorting_record_entity_1.SortingRecord)),
    __param(1, (0, typeorm_1.InjectRepository)(batch_entity_1.Batch)),
    __param(2, (0, typeorm_1.InjectRepository)(quality_check_entity_1.QualityCheck)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], SortingService);
//# sourceMappingURL=sorting.service.js.map