import { SortingService } from './sorting.service';
import { CreateSortingDraftDto } from './dto/create-draft.dto';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
export declare class SortingController {
    private readonly sortingService;
    constructor(sortingService: SortingService);
    createDraft(dto: CreateSortingDraftDto, user: JwtPayload): Promise<{
        data: import("./sorting-record.entity").SortingRecord;
        message: string;
    }>;
    submitQuality(batchNo: string, user: JwtPayload): Promise<{
        data: import("./sorting-record.entity").SortingRecord;
        message: string;
    }>;
    findByBatchNo(batchNo: string): Promise<{
        data: import("./sorting-record.entity").SortingRecord | null;
    }>;
    voidRecord(batchNo: string, user: JwtPayload): Promise<{
        data: import("./sorting-record.entity").SortingRecord;
        message: string;
    }>;
}
