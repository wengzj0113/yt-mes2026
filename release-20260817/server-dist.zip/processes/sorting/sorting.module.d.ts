export declare class SortingModule {
}
