"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SortingModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const sorting_record_entity_1 = require("./sorting-record.entity");
const sorting_service_1 = require("./sorting.service");
const sorting_controller_1 = require("./sorting.controller");
const batch_entity_1 = require("../../batch/batch.entity");
const quality_check_entity_1 = require("../../quality/quality-check.entity");
let SortingModule = class SortingModule {
};
exports.SortingModule = SortingModule;
exports.SortingModule = SortingModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([sorting_record_entity_1.SortingRecord, batch_entity_1.Batch, quality_check_entity_1.QualityCheck])],
        providers: [sorting_service_1.SortingService],
        controllers: [sorting_controller_1.SortingController],
        exports: [sorting_service_1.SortingService],
    })
], SortingModule);
//# sourceMappingURL=sorting.module.js.map