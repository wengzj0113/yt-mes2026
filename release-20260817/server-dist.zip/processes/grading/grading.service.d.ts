import { Repository } from 'typeorm';
import { GradingRecord } from './grading-record.entity';
import { Batch } from '../../batch/batch.entity';
import { QualityCheck } from '../../quality/quality-check.entity';
import { CreateGradingDraftDto } from './dto/create-draft.dto';
import { SubmitGradingQualityDto } from './dto/submit-quality.dto';
export declare class GradingService {
    private readonly repo;
    private readonly batchRepo;
    private readonly qualityCheckRepo;
    constructor(repo: Repository<GradingRecord>, batchRepo: Repository<Batch>, qualityCheckRepo: Repository<QualityCheck>);
    private validateBatch;
    createDraft(dto: CreateGradingDraftDto, userId: number): Promise<GradingRecord>;
    submitQuality(dto: SubmitGradingQualityDto, userId: number): Promise<GradingRecord>;
    findByBatchNo(batchNo: string): Promise<GradingRecord | null>;
    voidRecord(batchNo: string, userId: number): Promise<GradingRecord>;
}
