export declare class GradingModule {
}
