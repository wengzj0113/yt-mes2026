import { GradingService } from './grading.service';
import { CreateGradingDraftDto } from './dto/create-draft.dto';
import { SubmitGradingQualityDto } from './dto/submit-quality.dto';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
export declare class GradingController {
    private readonly gradingService;
    constructor(gradingService: GradingService);
    createDraft(dto: CreateGradingDraftDto, user: JwtPayload): Promise<{
        data: import("./grading-record.entity").GradingRecord;
        message: string;
    }>;
    submitQuality(dto: SubmitGradingQualityDto, user: JwtPayload): Promise<{
        data: import("./grading-record.entity").GradingRecord;
        message: string;
    }>;
    findByBatchNo(batchNo: string): Promise<{
        data: import("./grading-record.entity").GradingRecord | null;
    }>;
    voidRecord(batchNo: string, user: JwtPayload): Promise<{
        data: import("./grading-record.entity").GradingRecord;
        message: string;
    }>;
}
