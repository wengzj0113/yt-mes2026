export declare class CreateGradingDraftDto {
    batchNo: string;
    equipmentCode: string;
    operatorName: string;
}
