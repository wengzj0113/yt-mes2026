export declare class SubmitGradingQualityDto {
    batchNo: string;
    operatorName?: string;
    chargeDischargeTemplate: string;
    gradingTemperature: number;
    capacityGradeStandard: string;
}
