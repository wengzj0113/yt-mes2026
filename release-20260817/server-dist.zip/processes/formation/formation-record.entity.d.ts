export declare class FormationRecord {
    id: number;
    batchNo: string;
    recordStatus: number;
    isDraft: boolean;
    equipmentCode: string;
    chargeDischargeTemplate: string | null;
    formationTemperature: number | null;
    operatorName: string;
    extraData: string;
    createdBy: number;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date | null;
}
