export declare class FormationModule {
}
