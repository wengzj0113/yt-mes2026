export declare class SubmitFormationQualityDto {
    batchNo: string;
    operatorName?: string;
    chargeDischargeTemplate: string;
    formationTemperature: number;
}
