export declare class CreateFormationDraftDto {
    batchNo: string;
    equipmentCode: string;
    operatorName: string;
}
