import { FormationService } from './formation.service';
import { CreateFormationDraftDto } from './dto/create-draft.dto';
import { SubmitFormationQualityDto } from './dto/submit-quality.dto';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
export declare class FormationController {
    private readonly formationService;
    constructor(formationService: FormationService);
    createDraft(dto: CreateFormationDraftDto, user: JwtPayload): Promise<{
        data: import("./formation-record.entity").FormationRecord;
        message: string;
    }>;
    submitQuality(dto: SubmitFormationQualityDto, user: JwtPayload): Promise<{
        data: import("./formation-record.entity").FormationRecord;
        message: string;
    }>;
    findByBatchNo(batchNo: string): Promise<{
        data: import("./formation-record.entity").FormationRecord | null;
    }>;
    voidRecord(batchNo: string, user: JwtPayload): Promise<{
        data: import("./formation-record.entity").FormationRecord;
        message: string;
    }>;
}
