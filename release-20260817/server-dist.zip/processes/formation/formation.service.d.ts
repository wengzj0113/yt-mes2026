import { Repository } from 'typeorm';
import { FormationRecord } from './formation-record.entity';
import { Batch } from '../../batch/batch.entity';
import { QualityCheck } from '../../quality/quality-check.entity';
import { CreateFormationDraftDto } from './dto/create-draft.dto';
import { SubmitFormationQualityDto } from './dto/submit-quality.dto';
export declare class FormationService {
    private readonly repo;
    private readonly batchRepo;
    private readonly qualityCheckRepo;
    constructor(repo: Repository<FormationRecord>, batchRepo: Repository<Batch>, qualityCheckRepo: Repository<QualityCheck>);
    private validateBatch;
    createDraft(dto: CreateFormationDraftDto, userId: number): Promise<FormationRecord>;
    submitQuality(dto: SubmitFormationQualityDto, userId: number): Promise<FormationRecord>;
    findByBatchNo(batchNo: string): Promise<FormationRecord | null>;
    voidRecord(batchNo: string, userId: number): Promise<FormationRecord>;
}
