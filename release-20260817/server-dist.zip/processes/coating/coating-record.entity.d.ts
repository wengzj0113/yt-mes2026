export declare class CoatingRecord {
    id: number;
    batchNo: string;
    recordStatus: number;
    isDraft: boolean;
    equipmentCode: string;
    coatingSpeed: number;
    coatingThicknessPos: number;
    coatingThicknessNeg: number;
    arealDensityPos: number;
    arealDensityNeg: number;
    coatingTemperature: number;
    operatorName: string;
    extraData: string;
    createdBy: number;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date | null;
}
