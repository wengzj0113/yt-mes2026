import { Repository } from 'typeorm';
import { CoatingRecord } from './coating-record.entity';
import { Batch } from '../../batch/batch.entity';
import { QualityCheck } from '../../quality/quality-check.entity';
import { CreateCoatingDraftDto } from './dto/create-draft.dto';
export declare class CoatingService {
    private readonly repo;
    private readonly batchRepo;
    private readonly qualityCheckRepo;
    constructor(repo: Repository<CoatingRecord>, batchRepo: Repository<Batch>, qualityCheckRepo: Repository<QualityCheck>);
    private validateBatch;
    createDraft(dto: CreateCoatingDraftDto, userId: number): Promise<CoatingRecord>;
    submitQuality(batchNo: string, userId: number): Promise<CoatingRecord>;
    findByBatchNo(batchNo: string): Promise<CoatingRecord | null>;
    voidRecord(batchNo: string, userId: number): Promise<CoatingRecord>;
}
