"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoatingRecord = void 0;
const typeorm_1 = require("typeorm");
let CoatingRecord = class CoatingRecord {
    constructor() {
        this.recordStatus = 1;
        this.isDraft = true;
    }
};
exports.CoatingRecord = CoatingRecord;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], CoatingRecord.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)({ name: 'batch_no', length: 16 }),
    __metadata("design:type", String)
], CoatingRecord.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'record_status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], CoatingRecord.prototype, "recordStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'is_draft', default: true }),
    __metadata("design:type", Boolean)
], CoatingRecord.prototype, "isDraft", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'equipment_code', length: 16 }),
    __metadata("design:type", String)
], CoatingRecord.prototype, "equipmentCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'coating_speed', type: 'decimal', precision: 8, scale: 2 }),
    __metadata("design:type", Number)
], CoatingRecord.prototype, "coatingSpeed", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'coating_thickness_pos', type: 'decimal', precision: 8, scale: 2 }),
    __metadata("design:type", Number)
], CoatingRecord.prototype, "coatingThicknessPos", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'coating_thickness_neg', type: 'decimal', precision: 8, scale: 2 }),
    __metadata("design:type", Number)
], CoatingRecord.prototype, "coatingThicknessNeg", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'areal_density_pos', type: 'decimal', precision: 8, scale: 2 }),
    __metadata("design:type", Number)
], CoatingRecord.prototype, "arealDensityPos", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'areal_density_neg', type: 'decimal', precision: 8, scale: 2 }),
    __metadata("design:type", Number)
], CoatingRecord.prototype, "arealDensityNeg", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'coating_temperature', type: 'decimal', precision: 8, scale: 2 }),
    __metadata("design:type", Number)
], CoatingRecord.prototype, "coatingTemperature", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'operator_name', length: 32 }),
    __metadata("design:type", String)
], CoatingRecord.prototype, "operatorName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'nvarchar', length: 'max', nullable: true, name: 'extra_data' }),
    __metadata("design:type", String)
], CoatingRecord.prototype, "extraData", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'created_by', type: 'int' }),
    __metadata("design:type", Number)
], CoatingRecord.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], CoatingRecord.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'updated_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], CoatingRecord.prototype, "updatedBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Object)
], CoatingRecord.prototype, "updatedAt", void 0);
exports.CoatingRecord = CoatingRecord = __decorate([
    (0, typeorm_1.Entity)('coating_record')
], CoatingRecord);
//# sourceMappingURL=coating-record.entity.js.map