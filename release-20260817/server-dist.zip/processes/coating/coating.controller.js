"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoatingController = void 0;
const common_1 = require("@nestjs/common");
const coating_service_1 = require("./coating.service");
const create_draft_dto_1 = require("./dto/create-draft.dto");
const current_user_decorator_1 = require("../../common/decorators/current-user.decorator");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const user_entity_1 = require("../../user/user.entity");
let CoatingController = class CoatingController {
    constructor(coatingService) {
        this.coatingService = coatingService;
    }
    async createDraft(dto, user) {
        const record = await this.coatingService.createDraft(dto, user.sub);
        return { data: record, message: '草稿保存成功' };
    }
    async submitQuality(batchNo, user) {
        const record = await this.coatingService.submitQuality(batchNo, user.sub);
        return { data: record, message: '提交成功' };
    }
    async findByBatchNo(batchNo) {
        const record = await this.coatingService.findByBatchNo(batchNo);
        return { data: record };
    }
    async voidRecord(batchNo, user) {
        const record = await this.coatingService.voidRecord(batchNo, user.sub);
        return { data: record, message: '已作废' };
    }
};
exports.CoatingController = CoatingController;
__decorate([
    (0, common_1.Post)('draft'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.OPERATOR, user_entity_1.UserRole.QUALITY, user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_draft_dto_1.CreateCoatingDraftDto, Object]),
    __metadata("design:returntype", Promise)
], CoatingController.prototype, "createDraft", null);
__decorate([
    (0, common_1.Post)('submit'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.OPERATOR, user_entity_1.UserRole.QUALITY, user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Body)('batchNo')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], CoatingController.prototype, "submitQuality", null);
__decorate([
    (0, common_1.Get)(':batchNo'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.OPERATOR, user_entity_1.UserRole.QUALITY, user_entity_1.UserRole.WAREHOUSE, user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('batchNo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], CoatingController.prototype, "findByBatchNo", null);
__decorate([
    (0, common_1.Patch)(':batchNo/void'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.QUALITY, user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('batchNo')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], CoatingController.prototype, "voidRecord", null);
exports.CoatingController = CoatingController = __decorate([
    (0, common_1.Controller)('processes/coating'),
    __metadata("design:paramtypes", [coating_service_1.CoatingService])
], CoatingController);
//# sourceMappingURL=coating.controller.js.map