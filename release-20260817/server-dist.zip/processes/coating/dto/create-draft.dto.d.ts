export declare class CreateCoatingDraftDto {
    batchNo: string;
    equipmentCode: string;
    coatingSpeed: number;
    coatingThicknessPos: number;
    coatingThicknessNeg: number;
    arealDensityPos: number;
    arealDensityNeg: number;
    coatingTemperature: number;
    operatorName: string;
}
