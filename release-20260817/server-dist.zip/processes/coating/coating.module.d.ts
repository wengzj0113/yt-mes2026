export declare class CoatingModule {
}
