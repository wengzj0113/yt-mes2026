import { CoatingService } from './coating.service';
import { CreateCoatingDraftDto } from './dto/create-draft.dto';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
export declare class CoatingController {
    private readonly coatingService;
    constructor(coatingService: CoatingService);
    createDraft(dto: CreateCoatingDraftDto, user: JwtPayload): Promise<{
        data: import("./coating-record.entity").CoatingRecord;
        message: string;
    }>;
    submitQuality(batchNo: string, user: JwtPayload): Promise<{
        data: import("./coating-record.entity").CoatingRecord;
        message: string;
    }>;
    findByBatchNo(batchNo: string): Promise<{
        data: import("./coating-record.entity").CoatingRecord | null;
    }>;
    voidRecord(batchNo: string, user: JwtPayload): Promise<{
        data: import("./coating-record.entity").CoatingRecord;
        message: string;
    }>;
}
