"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Ocv1Record = void 0;
const typeorm_1 = require("typeorm");
let Ocv1Record = class Ocv1Record {
    constructor() {
        this.recordStatus = 1;
        this.isDraft = false;
    }
};
exports.Ocv1Record = Ocv1Record;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], Ocv1Record.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)({ name: 'batch_no', length: 16 }),
    __metadata("design:type", String)
], Ocv1Record.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'record_status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], Ocv1Record.prototype, "recordStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'is_draft', default: false }),
    __metadata("design:type", Boolean)
], Ocv1Record.prototype, "isDraft", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ocv_voltage_min', type: 'decimal', precision: 12, scale: 4, nullable: true }),
    __metadata("design:type", Object)
], Ocv1Record.prototype, "ocvVoltageMin", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ocv_voltage_max', type: 'decimal', precision: 12, scale: 4, nullable: true }),
    __metadata("design:type", Object)
], Ocv1Record.prototype, "ocvVoltageMax", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'equipment_code', type: 'nvarchar', length: 64, nullable: true }),
    __metadata("design:type", Object)
], Ocv1Record.prototype, "equipmentCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'operator_name', type: 'nvarchar', length: 64, nullable: true }),
    __metadata("design:type", Object)
], Ocv1Record.prototype, "operatorName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'created_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], Ocv1Record.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], Ocv1Record.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'updated_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], Ocv1Record.prototype, "updatedBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Object)
], Ocv1Record.prototype, "updatedAt", void 0);
exports.Ocv1Record = Ocv1Record = __decorate([
    (0, typeorm_1.Entity)('ocv1_record')
], Ocv1Record);
//# sourceMappingURL=ocv1-record.entity.js.map