export declare class Ocv2Record {
    id: number;
    batchNo: string;
    recordStatus: number;
    isDraft: boolean;
    ocvVoltageMin: number | null;
    ocvVoltageMax: number | null;
    equipmentCode: string | null;
    operatorName: string | null;
    createdBy: number | null;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date | null;
}
