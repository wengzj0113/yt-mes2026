export declare class WrappingRecord {
    id: number;
    batchNo: string;
    recordStatus: number;
    isDraft: boolean;
    equipmentCode: string;
    filmModel: string;
    shrinkTemperature: number;
    appearanceCheck: number | null;
    operatorName: string;
    extraData: string;
    createdBy: number;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date | null;
}
