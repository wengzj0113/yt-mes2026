import { WrappingService } from './wrapping.service';
import { CreateWrappingDraftDto } from './dto/create-draft.dto';
import { SubmitWrappingQualityDto } from './dto/submit-quality.dto';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
export declare class WrappingController {
    private readonly wrappingService;
    constructor(wrappingService: WrappingService);
    createDraft(dto: CreateWrappingDraftDto, user: JwtPayload): Promise<{
        data: import("./wrapping-record.entity").WrappingRecord;
        message: string;
    }>;
    submitQuality(dto: SubmitWrappingQualityDto, user: JwtPayload): Promise<{
        data: import("./wrapping-record.entity").WrappingRecord;
        message: string;
    }>;
    findByBatchNo(batchNo: string): Promise<{
        data: import("./wrapping-record.entity").WrappingRecord | null;
    }>;
    voidRecord(batchNo: string, user: JwtPayload): Promise<{
        data: import("./wrapping-record.entity").WrappingRecord;
        message: string;
    }>;
}
