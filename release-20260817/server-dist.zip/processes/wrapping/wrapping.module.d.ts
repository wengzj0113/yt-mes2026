export declare class WrappingModule {
}
