"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WrappingRecord = void 0;
const typeorm_1 = require("typeorm");
let WrappingRecord = class WrappingRecord {
    constructor() {
        this.recordStatus = 1;
        this.isDraft = true;
    }
};
exports.WrappingRecord = WrappingRecord;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], WrappingRecord.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)({ name: 'batch_no', length: 16 }),
    __metadata("design:type", String)
], WrappingRecord.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'record_status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], WrappingRecord.prototype, "recordStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'is_draft', default: true }),
    __metadata("design:type", Boolean)
], WrappingRecord.prototype, "isDraft", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'equipment_code', length: 16 }),
    __metadata("design:type", String)
], WrappingRecord.prototype, "equipmentCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'film_model', length: 128 }),
    __metadata("design:type", String)
], WrappingRecord.prototype, "filmModel", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'shrink_temperature', type: 'decimal', precision: 8, scale: 2 }),
    __metadata("design:type", Number)
], WrappingRecord.prototype, "shrinkTemperature", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'appearance_check', type: 'tinyint', nullable: true }),
    __metadata("design:type", Object)
], WrappingRecord.prototype, "appearanceCheck", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'operator_name', length: 32 }),
    __metadata("design:type", String)
], WrappingRecord.prototype, "operatorName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'nvarchar', length: 'max', nullable: true, name: 'extra_data' }),
    __metadata("design:type", String)
], WrappingRecord.prototype, "extraData", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'created_by', type: 'int' }),
    __metadata("design:type", Number)
], WrappingRecord.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], WrappingRecord.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'updated_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], WrappingRecord.prototype, "updatedBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Object)
], WrappingRecord.prototype, "updatedAt", void 0);
exports.WrappingRecord = WrappingRecord = __decorate([
    (0, typeorm_1.Entity)('wrapping_record')
], WrappingRecord);
//# sourceMappingURL=wrapping-record.entity.js.map