import { Repository } from 'typeorm';
import { WrappingRecord } from './wrapping-record.entity';
import { Batch } from '../../batch/batch.entity';
import { QualityCheck } from '../../quality/quality-check.entity';
import { CreateWrappingDraftDto } from './dto/create-draft.dto';
import { SubmitWrappingQualityDto } from './dto/submit-quality.dto';
export declare class WrappingService {
    private readonly repo;
    private readonly batchRepo;
    private readonly qualityCheckRepo;
    constructor(repo: Repository<WrappingRecord>, batchRepo: Repository<Batch>, qualityCheckRepo: Repository<QualityCheck>);
    private validateBatch;
    createDraft(dto: CreateWrappingDraftDto, userId: number): Promise<WrappingRecord>;
    submitQuality(dto: SubmitWrappingQualityDto, userId: number): Promise<WrappingRecord>;
    findByBatchNo(batchNo: string): Promise<WrappingRecord | null>;
    voidRecord(batchNo: string, userId: number): Promise<WrappingRecord>;
}
