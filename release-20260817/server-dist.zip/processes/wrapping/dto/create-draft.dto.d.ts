export declare class CreateWrappingDraftDto {
    batchNo: string;
    equipmentCode: string;
    filmModel: string;
    shrinkTemperature: number;
    operatorName: string;
}
