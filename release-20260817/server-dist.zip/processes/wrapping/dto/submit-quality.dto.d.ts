export declare class SubmitWrappingQualityDto {
    batchNo: string;
    operatorName?: string;
    appearanceCheck: number;
}
