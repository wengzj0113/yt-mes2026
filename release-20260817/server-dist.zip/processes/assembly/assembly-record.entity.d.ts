export declare class AssemblyRecord {
    id: number;
    batchNo: string;
    recordStatus: number;
    isDraft: boolean;
    casingEquipmentCode: string;
    shellModel: string;
    bottomWeldEquipment: string;
    bottomWeldParams: string;
    bottomWeldPull: number | null;
    grooveRecord: string | null;
    capModel: string;
    capWeldingPull: number | null;
    tabWeldingPull: number | null;
    operatorName: string;
    extraData: string;
    createdBy: number;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date | null;
}
