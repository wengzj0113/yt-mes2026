export declare class AssemblyModule {
}
