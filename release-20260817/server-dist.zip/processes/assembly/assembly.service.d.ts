import { Repository } from 'typeorm';
import { AssemblyRecord } from './assembly-record.entity';
import { Batch } from '../../batch/batch.entity';
import { QualityCheck } from '../../quality/quality-check.entity';
import { CreateAssemblyDraftDto } from './dto/create-draft.dto';
import { SubmitAssemblyQualityDto } from './dto/submit-quality.dto';
export declare class AssemblyService {
    private readonly repo;
    private readonly batchRepo;
    private readonly qualityCheckRepo;
    constructor(repo: Repository<AssemblyRecord>, batchRepo: Repository<Batch>, qualityCheckRepo: Repository<QualityCheck>);
    private validateBatch;
    createDraft(dto: CreateAssemblyDraftDto, userId: number): Promise<AssemblyRecord>;
    submitQuality(dto: SubmitAssemblyQualityDto, userId: number): Promise<AssemblyRecord>;
    findByBatchNo(batchNo: string): Promise<AssemblyRecord | null>;
    voidRecord(batchNo: string, userId: number): Promise<AssemblyRecord>;
}
