export declare class SubmitAssemblyQualityDto {
    batchNo: string;
    casingEquipmentCode?: string;
    shellModel?: string;
    bottomWeldEquipment?: string;
    bottomWeldParams?: string;
    capModel?: string;
    operatorName?: string;
    bottomWeldPull: number;
    grooveRecord: string;
    capWeldingPull: number;
    tabWeldingPull: number;
}
