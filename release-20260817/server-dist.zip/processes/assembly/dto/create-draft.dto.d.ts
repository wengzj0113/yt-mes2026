export declare class CreateAssemblyDraftDto {
    batchNo: string;
    casingEquipmentCode: string;
    shellModel: string;
    bottomWeldEquipment: string;
    bottomWeldParams: string;
    capModel: string;
    operatorName: string;
}
