"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AssemblyRecord = void 0;
const typeorm_1 = require("typeorm");
let AssemblyRecord = class AssemblyRecord {
    constructor() {
        this.recordStatus = 1;
        this.isDraft = true;
    }
};
exports.AssemblyRecord = AssemblyRecord;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], AssemblyRecord.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)({ name: 'batch_no', length: 16 }),
    __metadata("design:type", String)
], AssemblyRecord.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'record_status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], AssemblyRecord.prototype, "recordStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'is_draft', default: true }),
    __metadata("design:type", Boolean)
], AssemblyRecord.prototype, "isDraft", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'casing_equipment_code', length: 16 }),
    __metadata("design:type", String)
], AssemblyRecord.prototype, "casingEquipmentCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'shell_model', length: 128 }),
    __metadata("design:type", String)
], AssemblyRecord.prototype, "shellModel", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bottom_weld_equipment', length: 16 }),
    __metadata("design:type", String)
], AssemblyRecord.prototype, "bottomWeldEquipment", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bottom_weld_params', length: 256 }),
    __metadata("design:type", String)
], AssemblyRecord.prototype, "bottomWeldParams", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bottom_weld_pull', type: 'decimal', precision: 8, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], AssemblyRecord.prototype, "bottomWeldPull", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'groove_record', type: 'nvarchar', length: 256, nullable: true }),
    __metadata("design:type", Object)
], AssemblyRecord.prototype, "grooveRecord", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'cap_model', length: 128 }),
    __metadata("design:type", String)
], AssemblyRecord.prototype, "capModel", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'cap_welding_pull', type: 'decimal', precision: 8, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], AssemblyRecord.prototype, "capWeldingPull", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'tab_welding_pull', type: 'decimal', precision: 8, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], AssemblyRecord.prototype, "tabWeldingPull", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'operator_name', length: 32 }),
    __metadata("design:type", String)
], AssemblyRecord.prototype, "operatorName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'nvarchar', length: 'max', nullable: true, name: 'extra_data' }),
    __metadata("design:type", String)
], AssemblyRecord.prototype, "extraData", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'created_by', type: 'int' }),
    __metadata("design:type", Number)
], AssemblyRecord.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], AssemblyRecord.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'updated_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], AssemblyRecord.prototype, "updatedBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Object)
], AssemblyRecord.prototype, "updatedAt", void 0);
exports.AssemblyRecord = AssemblyRecord = __decorate([
    (0, typeorm_1.Entity)('assembly_record')
], AssemblyRecord);
//# sourceMappingURL=assembly-record.entity.js.map