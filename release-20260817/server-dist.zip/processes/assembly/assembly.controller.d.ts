import { AssemblyService } from './assembly.service';
import { CreateAssemblyDraftDto } from './dto/create-draft.dto';
import { SubmitAssemblyQualityDto } from './dto/submit-quality.dto';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
export declare class AssemblyController {
    private readonly assemblyService;
    constructor(assemblyService: AssemblyService);
    createDraft(dto: CreateAssemblyDraftDto, user: JwtPayload): Promise<{
        data: import("./assembly-record.entity").AssemblyRecord;
        message: string;
    }>;
    submitQuality(dto: SubmitAssemblyQualityDto, user: JwtPayload): Promise<{
        data: import("./assembly-record.entity").AssemblyRecord;
        message: string;
    }>;
    findByBatchNo(batchNo: string): Promise<{
        data: import("./assembly-record.entity").AssemblyRecord | null;
    }>;
    voidRecord(batchNo: string, user: JwtPayload): Promise<{
        data: import("./assembly-record.entity").AssemblyRecord;
        message: string;
    }>;
}
