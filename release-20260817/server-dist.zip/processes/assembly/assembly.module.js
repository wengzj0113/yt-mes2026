"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AssemblyModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const assembly_record_entity_1 = require("./assembly-record.entity");
const assembly_service_1 = require("./assembly.service");
const assembly_controller_1 = require("./assembly.controller");
const batch_entity_1 = require("../../batch/batch.entity");
const quality_check_entity_1 = require("../../quality/quality-check.entity");
let AssemblyModule = class AssemblyModule {
};
exports.AssemblyModule = AssemblyModule;
exports.AssemblyModule = AssemblyModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([assembly_record_entity_1.AssemblyRecord, batch_entity_1.Batch, quality_check_entity_1.QualityCheck])],
        providers: [assembly_service_1.AssemblyService],
        controllers: [assembly_controller_1.AssemblyController],
        exports: [assembly_service_1.AssemblyService],
    })
], AssemblyModule);
//# sourceMappingURL=assembly.module.js.map