export declare class BatchingModule {
}
