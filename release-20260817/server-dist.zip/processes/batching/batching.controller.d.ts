import { BatchingService } from './batching.service';
import { CreateBatchingDraftDto } from './dto/create-draft.dto';
import { SubmitBatchingQualityDto } from './dto/submit-quality.dto';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
export declare class BatchingController {
    private readonly batchingService;
    constructor(batchingService: BatchingService);
    createDraft(dto: CreateBatchingDraftDto, user: JwtPayload): Promise<{
        data: import("./batching-record.entity").BatchingRecord;
        message: string;
    }>;
    submitQuality(dto: SubmitBatchingQualityDto, user: JwtPayload): Promise<{
        data: import("./batching-record.entity").BatchingRecord;
        message: string;
    }>;
    findByBatchNo(batchNo: string): Promise<{
        data: import("./batching-record.entity").BatchingRecord | null;
    }>;
    voidRecord(batchNo: string, user: JwtPayload): Promise<{
        data: import("./batching-record.entity").BatchingRecord;
        message: string;
    }>;
}
