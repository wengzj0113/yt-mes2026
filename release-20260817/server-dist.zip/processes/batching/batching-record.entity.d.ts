export declare class BatchingRecord {
    id: number;
    batchNo: string;
    recordStatus: number;
    isDraft: boolean;
    positiveMaterial: string;
    negativeMaterial: string;
    viscosityRecord: string | null;
    operatorName: string;
    extraData: string;
    createdBy: number;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date | null;
}
