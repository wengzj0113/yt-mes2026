export declare class SubmitBatchingQualityDto {
    batchNo: string;
    operatorName?: string;
    viscosityRecord: string;
}
