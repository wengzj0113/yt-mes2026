export declare class CreateBatchingDraftDto {
    batchNo: string;
    positiveMaterial: string;
    negativeMaterial: string;
    operatorName: string;
}
