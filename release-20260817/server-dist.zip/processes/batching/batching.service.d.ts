import { Repository, DataSource } from 'typeorm';
import { BatchingRecord } from './batching-record.entity';
import { Batch } from '../../batch/batch.entity';
import { QualityCheck } from '../../quality/quality-check.entity';
import { CreateBatchingDraftDto } from './dto/create-draft.dto';
import { SubmitBatchingQualityDto } from './dto/submit-quality.dto';
export declare class BatchingService {
    private readonly repo;
    private readonly batchRepo;
    private readonly qualityCheckRepo;
    private readonly dataSource;
    constructor(repo: Repository<BatchingRecord>, batchRepo: Repository<Batch>, qualityCheckRepo: Repository<QualityCheck>, dataSource: DataSource);
    private validateBatch;
    createDraft(dto: CreateBatchingDraftDto, userId: number): Promise<BatchingRecord>;
    submitQuality(dto: SubmitBatchingQualityDto, userId: number): Promise<BatchingRecord>;
    findByBatchNo(batchNo: string): Promise<BatchingRecord | null>;
    voidRecord(batchNo: string, userId: number): Promise<BatchingRecord>;
}
