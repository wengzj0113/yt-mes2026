"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WindingModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const winding_record_entity_1 = require("./winding-record.entity");
const winding_service_1 = require("./winding.service");
const winding_controller_1 = require("./winding.controller");
const batch_entity_1 = require("../../batch/batch.entity");
const quality_check_entity_1 = require("../../quality/quality-check.entity");
let WindingModule = class WindingModule {
};
exports.WindingModule = WindingModule;
exports.WindingModule = WindingModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([winding_record_entity_1.WindingRecord, batch_entity_1.Batch, quality_check_entity_1.QualityCheck])],
        providers: [winding_service_1.WindingService],
        controllers: [winding_controller_1.WindingController],
        exports: [winding_service_1.WindingService],
    })
], WindingModule);
//# sourceMappingURL=winding.module.js.map