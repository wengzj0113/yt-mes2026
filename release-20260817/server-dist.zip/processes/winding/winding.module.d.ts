export declare class WindingModule {
}
