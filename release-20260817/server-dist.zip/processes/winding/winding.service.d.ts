import { Repository } from 'typeorm';
import { WindingRecord } from './winding-record.entity';
import { Batch } from '../../batch/batch.entity';
import { QualityCheck } from '../../quality/quality-check.entity';
import { CreateWindingDraftDto } from './dto/create-draft.dto';
import { SubmitWindingQualityDto } from './dto/submit-quality.dto';
export declare class WindingService {
    private readonly repo;
    private readonly batchRepo;
    private readonly qualityCheckRepo;
    constructor(repo: Repository<WindingRecord>, batchRepo: Repository<Batch>, qualityCheckRepo: Repository<QualityCheck>);
    private validateBatch;
    createDraft(dto: CreateWindingDraftDto, userId: number): Promise<WindingRecord>;
    submitQuality(dto: SubmitWindingQualityDto, userId: number): Promise<WindingRecord>;
    findByBatchNo(batchNo: string): Promise<WindingRecord | null>;
    voidRecord(batchNo: string, userId: number): Promise<WindingRecord>;
}
