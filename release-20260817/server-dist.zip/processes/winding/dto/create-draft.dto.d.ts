export declare class CreateWindingDraftDto {
    batchNo: string;
    equipmentCode: string;
    separatorModel: string;
    windingSpeed: number;
    windingTension: number;
    operatorName: string;
}
