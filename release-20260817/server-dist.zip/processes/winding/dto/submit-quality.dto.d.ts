export declare class SubmitWindingQualityDto {
    batchNo: string;
    operatorName?: string;
    coreThickness: number;
    coreDiameter: number;
}
