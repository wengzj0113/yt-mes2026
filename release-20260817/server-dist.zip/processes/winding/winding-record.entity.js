"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WindingRecord = void 0;
const typeorm_1 = require("typeorm");
let WindingRecord = class WindingRecord {
    constructor() {
        this.recordStatus = 1;
        this.isDraft = true;
    }
};
exports.WindingRecord = WindingRecord;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], WindingRecord.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Index)(),
    (0, typeorm_1.Column)({ name: 'batch_no', length: 16 }),
    __metadata("design:type", String)
], WindingRecord.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'record_status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], WindingRecord.prototype, "recordStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'is_draft', default: true }),
    __metadata("design:type", Boolean)
], WindingRecord.prototype, "isDraft", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'equipment_code', length: 16 }),
    __metadata("design:type", String)
], WindingRecord.prototype, "equipmentCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'separator_model', length: 128 }),
    __metadata("design:type", String)
], WindingRecord.prototype, "separatorModel", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'winding_speed', type: 'decimal', precision: 8, scale: 2 }),
    __metadata("design:type", Number)
], WindingRecord.prototype, "windingSpeed", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'winding_tension', type: 'decimal', precision: 8, scale: 2 }),
    __metadata("design:type", Number)
], WindingRecord.prototype, "windingTension", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'core_thickness', type: 'decimal', precision: 8, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], WindingRecord.prototype, "coreThickness", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'core_diameter', type: 'decimal', precision: 8, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], WindingRecord.prototype, "coreDiameter", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'operator_name', length: 32 }),
    __metadata("design:type", String)
], WindingRecord.prototype, "operatorName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'nvarchar', length: 'max', nullable: true, name: 'extra_data' }),
    __metadata("design:type", String)
], WindingRecord.prototype, "extraData", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'created_by', type: 'int' }),
    __metadata("design:type", Number)
], WindingRecord.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], WindingRecord.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'updated_by', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], WindingRecord.prototype, "updatedBy", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Object)
], WindingRecord.prototype, "updatedAt", void 0);
exports.WindingRecord = WindingRecord = __decorate([
    (0, typeorm_1.Entity)('winding_record')
], WindingRecord);
//# sourceMappingURL=winding-record.entity.js.map