import { WindingService } from './winding.service';
import { CreateWindingDraftDto } from './dto/create-draft.dto';
import { SubmitWindingQualityDto } from './dto/submit-quality.dto';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
export declare class WindingController {
    private readonly windingService;
    constructor(windingService: WindingService);
    createDraft(dto: CreateWindingDraftDto, user: JwtPayload): Promise<{
        data: import("./winding-record.entity").WindingRecord;
        message: string;
    }>;
    submitQuality(dto: SubmitWindingQualityDto, user: JwtPayload): Promise<{
        data: import("./winding-record.entity").WindingRecord;
        message: string;
    }>;
    findByBatchNo(batchNo: string): Promise<{
        data: import("./winding-record.entity").WindingRecord | null;
    }>;
    voidRecord(batchNo: string, user: JwtPayload): Promise<{
        data: import("./winding-record.entity").WindingRecord;
        message: string;
    }>;
}
