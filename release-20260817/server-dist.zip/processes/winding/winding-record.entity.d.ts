export declare class WindingRecord {
    id: number;
    batchNo: string;
    recordStatus: number;
    isDraft: boolean;
    equipmentCode: string;
    separatorModel: string;
    windingSpeed: number;
    windingTension: number;
    coreThickness: number | null;
    coreDiameter: number | null;
    operatorName: string;
    extraData: string;
    createdBy: number;
    createdAt: Date;
    updatedBy: number | null;
    updatedAt: Date | null;
}
