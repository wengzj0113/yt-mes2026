"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CellBarcodeService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const cache_manager_1 = require("@nestjs/cache-manager");
const event_emitter_1 = require("@nestjs/event-emitter");
const cell_barcode_entity_1 = require("./cell-barcode.entity");
const batch_entity_1 = require("../batch/batch.entity");
const process_status_service_1 = require("../processes/process-status/process-status.service");
const ocv1_record_entity_1 = require("../processes/ocv/ocv1-record.entity");
const ocv2_record_entity_1 = require("../processes/ocv/ocv2-record.entity");
function cleanDecimal(value, max = 10001, min = 0) {
    if (value === undefined || value === null)
        return null;
    const num = Number(value);
    if (isNaN(num))
        return null;
    if (num < min)
        return min;
    if (num > max)
        return max;
    return num;
}
let CellBarcodeService = class CellBarcodeService {
    constructor(repo, batchRepo, ocv1RecordRepo, ocv2RecordRepo, processStatusService, cacheManager) {
        this.repo = repo;
        this.batchRepo = batchRepo;
        this.ocv1RecordRepo = ocv1RecordRepo;
        this.ocv2RecordRepo = ocv2RecordRepo;
        this.processStatusService = processStatusService;
        this.cacheManager = cacheManager;
    }
    async sorterUpload(dto) {
        const batch = await this.batchRepo.findOne({ where: { batchNo: dto.batchNo } });
        if (!batch) {
            throw new common_1.NotFoundException({ code: 'BATCH_NOT_FOUND', message: `批次 ${dto.batchNo} 不存在` });
        }
        const voltage = cleanDecimal(dto.voltage, 10001, 0);
        const internalResistance = cleanDecimal(dto.internalResistance ?? dto.resistance, 10001, 0);
        const kValue = cleanDecimal(dto.kValue, 10001, 0);
        let record = await this.repo.findOne({ where: { barcode: dto.barcode } });
        if (record) {
            record.batchNo = dto.batchNo;
            record.capacity = dto.capacity ?? null;
            record.voltage = voltage;
            record.internalResistance = internalResistance;
            record.kValue = kValue;
            record.grade = dto.grade ?? null;
            record.sortingTime = dto.sortingTime ? new Date(dto.sortingTime) : null;
            record.importSource = 'sorter';
        }
        else {
            record = this.repo.create({
                barcode: dto.barcode,
                batchNo: dto.batchNo,
                capacity: dto.capacity ?? null,
                voltage: voltage,
                internalResistance: internalResistance,
                kValue: kValue,
                grade: dto.grade ?? null,
                sortingTime: dto.sortingTime ? new Date(dto.sortingTime) : null,
                importSource: 'sorter',
            });
        }
        return await this.repo.save(record);
    }
    async bulkSorterUpload(dto) {
        const batchNos = [...new Set(dto.cells.map(c => c.batchNo))];
        const existingBatches = await this.batchRepo.find({
            where: { batchNo: (0, typeorm_2.In)(batchNos) },
            select: ['batchNo'],
        });
        if (existingBatches.length !== batchNos.length) {
            const foundBatchNos = existingBatches.map(b => b.batchNo);
            const missingBatchNos = batchNos.filter(bn => !foundBatchNos.includes(bn));
            throw new common_1.NotFoundException({
                code: 'BATCH_NOT_FOUND',
                message: `批次 ${missingBatchNos.join(', ')} 不存在`
            });
        }
        const barcodes = dto.cells.map(c => c.barcode);
        const uniqueCellsMap = new Map();
        dto.cells.forEach(cell => {
            uniqueCellsMap.set(cell.barcode, cell);
        });
        const uniqueCells = Array.from(uniqueCellsMap.values());
        const uniqueBarcodes = uniqueCells.map(c => c.barcode);
        const existingCells = await this.repo.find({
            where: { barcode: (0, typeorm_2.In)(uniqueBarcodes) },
        });
        const existingCellsMap = new Map();
        existingCells.forEach(cell => {
            existingCellsMap.set(cell.barcode, cell);
        });
        const recordsToSave = [];
        uniqueCells.forEach(cell => {
            const voltage = cleanDecimal(cell.voltage, 10001, 0);
            const internalResistance = cleanDecimal(cell.internalResistance ?? cell.resistance, 10001, 0);
            const kValue = cleanDecimal(cell.kValue, 10001, 0);
            let record = existingCellsMap.get(cell.barcode);
            if (record) {
                record.batchNo = cell.batchNo;
                record.capacity = cell.capacity ?? null;
                record.voltage = voltage;
                record.internalResistance = internalResistance;
                record.kValue = kValue;
                record.grade = cell.grade ?? null;
                record.sortingTime = cell.sortingTime ? new Date(cell.sortingTime) : null;
                record.importSource = 'sorter';
            }
            else {
                record = this.repo.create({
                    barcode: cell.barcode,
                    batchNo: cell.batchNo,
                    capacity: cell.capacity ?? null,
                    voltage: voltage,
                    internalResistance: internalResistance,
                    kValue: kValue,
                    grade: cell.grade ?? null,
                    sortingTime: cell.sortingTime ? new Date(cell.sortingTime) : null,
                    importSource: 'sorter',
                });
            }
            recordsToSave.push(record);
        });
        return await this.repo.save(recordsToSave);
    }
    async trace(barcode) {
        const cacheKey = `trace:barcode:${barcode}`;
        const cached = await this.cacheManager.get(cacheKey);
        if (cached) {
            return cached;
        }
        const cell = await this.repo.findOne({ where: { barcode } });
        if (!cell) {
            throw new common_1.NotFoundException({ code: 'CELL_BARCODE_NOT_FOUND', message: `电芯码 ${barcode} 不存在` });
        }
        const [batch, processes] = await Promise.all([
            this.batchRepo.findOne({ where: { batchNo: cell.batchNo } }),
            this.processStatusService.getProcessRecords(cell.batchNo),
        ]);
        const result = { cell, batch, processes };
        await this.cacheManager.set(cacheKey, result, 3600000);
        return result;
    }
    async findByBatch(batchNo, pageNum = 1, pageSizeNum = 20) {
        const page = Number(pageNum || 1);
        const pageSize = Number(pageSizeNum || 20);
        const [data, total] = await Promise.all([
            this.repo.find({
                where: { batchNo },
                skip: (page - 1) * pageSize,
                take: pageSize,
                order: { createdAt: 'DESC' },
            }),
            this.repo.count({ where: { batchNo } }),
        ]);
        return { data, total, page, pageSize };
    }
    async handleProcessRecordUpdated(payload) {
        const cells = await this.repo.find({
            where: { batchNo: payload.batchNo },
            select: ['barcode'],
        });
        if (cells.length > 0) {
            const keys = cells.map(c => `trace:barcode:${c.barcode}`);
            await Promise.all(keys.map(key => this.cacheManager.del(key)));
        }
    }
    async ocv1Upload(dto) {
        return this.processOcv1Batch([dto]);
    }
    async bulkOcv1Upload(dto) {
        return this.processOcv1Batch(dto.ocv1Records);
    }
    async processOcv1Batch(records) {
        return this.repo.manager.transaction(async (manager) => {
            const batchNos = [...new Set(records.map(r => r.batchNo))];
            const existingBatches = await manager.find(batch_entity_1.Batch, {
                where: { batchNo: (0, typeorm_2.In)(batchNos) },
                select: ['batchNo'],
            });
            if (existingBatches.length !== batchNos.length) {
                const found = existingBatches.map(b => b.batchNo);
                const missing = batchNos.filter(b => !found.includes(b));
                throw new common_1.NotFoundException({
                    code: 'BATCH_NOT_FOUND',
                    message: `批次 ${missing.join(', ')} 不存在`,
                });
            }
            const uniqueMap = new Map();
            records.forEach(r => uniqueMap.set(r.barcode, r));
            const unique = Array.from(uniqueMap.values());
            const barcodes = unique.map(r => r.barcode);
            const existingCells = await manager.find(cell_barcode_entity_1.CellBarcode, {
                where: { barcode: (0, typeorm_2.In)(barcodes) },
            });
            const cellMap = new Map();
            existingCells.forEach(c => cellMap.set(c.barcode, c));
            const cellsToSave = [];
            const recordsToInsert = [];
            unique.forEach(r => {
                let cell = cellMap.get(r.barcode);
                if (!cell) {
                    cell = manager.create(cell_barcode_entity_1.CellBarcode, {
                        barcode: r.barcode,
                        batchNo: r.batchNo,
                        ocv1Voltage: r.voltage ?? null,
                        ocv1Resistance: r.internalResistance ?? r.resistance ?? null,
                        ocv1Time: r.testTime ? new Date(r.testTime) : null,
                        ocv1EquipmentCode: r.equipmentCode ?? null,
                        importSource: 'ocv1',
                    });
                }
                else {
                    cell.batchNo = r.batchNo;
                    cell.ocv1Voltage = r.voltage ?? cell.ocv1Voltage;
                    cell.ocv1Resistance = r.internalResistance ?? r.resistance ?? cell.ocv1Resistance;
                    cell.ocv1Time = r.testTime ? new Date(r.testTime) : cell.ocv1Time;
                    cell.ocv1EquipmentCode = r.equipmentCode ?? cell.ocv1EquipmentCode;
                }
                cellsToSave.push(cell);
                recordsToInsert.push(manager.create(ocv1_record_entity_1.Ocv1Record, {
                    batchNo: r.batchNo,
                    ocvVoltageMin: r.voltage ?? null,
                    ocvVoltageMax: r.voltage ?? null,
                    equipmentCode: r.equipmentCode ?? null,
                    operatorName: 'OCV设备',
                    isDraft: false,
                    recordStatus: 1,
                }));
            });
            const savedCells = await manager.save(cell_barcode_entity_1.CellBarcode, cellsToSave);
            await manager.save(ocv1_record_entity_1.Ocv1Record, recordsToInsert);
            return savedCells;
        });
    }
    async ocv2Upload(dto) {
        return this.processOcv2Batch([dto]);
    }
    async bulkOcv2Upload(dto) {
        return this.processOcv2Batch(dto.ocv2Records);
    }
    async processOcv2Batch(records) {
        return this.repo.manager.transaction(async (manager) => {
            const batchNos = [...new Set(records.map(r => r.batchNo))];
            const existingBatches = await manager.find(batch_entity_1.Batch, {
                where: { batchNo: (0, typeorm_2.In)(batchNos) },
                select: ['batchNo'],
            });
            if (existingBatches.length !== batchNos.length) {
                const found = existingBatches.map(b => b.batchNo);
                const missing = batchNos.filter(b => !found.includes(b));
                throw new common_1.NotFoundException({
                    code: 'BATCH_NOT_FOUND',
                    message: `批次 ${missing.join(', ')} 不存在`,
                });
            }
            const uniqueMap = new Map();
            records.forEach(r => uniqueMap.set(r.barcode, r));
            const unique = Array.from(uniqueMap.values());
            const barcodes = unique.map(r => r.barcode);
            const existingCells = await manager.find(cell_barcode_entity_1.CellBarcode, {
                where: { barcode: (0, typeorm_2.In)(barcodes) },
            });
            const cellMap = new Map();
            existingCells.forEach(c => cellMap.set(c.barcode, c));
            const cellsToSave = [];
            const recordsToInsert = [];
            unique.forEach(r => {
                let cell = cellMap.get(r.barcode);
                if (!cell) {
                    cell = manager.create(cell_barcode_entity_1.CellBarcode, {
                        barcode: r.barcode,
                        batchNo: r.batchNo,
                        ocv2Voltage: r.voltage ?? null,
                        ocv2Resistance: r.internalResistance ?? r.resistance ?? null,
                        ocv2Time: r.testTime ? new Date(r.testTime) : null,
                        ocv2EquipmentCode: r.equipmentCode ?? null,
                        kValue: null,
                        importSource: 'ocv2',
                    });
                }
                else {
                    cell.batchNo = r.batchNo;
                    cell.ocv2Voltage = r.voltage ?? cell.ocv2Voltage;
                    cell.ocv2Resistance = r.internalResistance ?? r.resistance ?? cell.ocv2Resistance;
                    cell.ocv2Time = r.testTime ? new Date(r.testTime) : cell.ocv2Time;
                    cell.ocv2EquipmentCode = r.equipmentCode ?? cell.ocv2EquipmentCode;
                }
                cellsToSave.push(cell);
                cellsToSave.push(cell);
                recordsToInsert.push(manager.create(ocv2_record_entity_1.Ocv2Record, {
                    batchNo: r.batchNo,
                    ocvVoltageMin: r.voltage ?? null,
                    ocvVoltageMax: r.voltage ?? null,
                    equipmentCode: r.equipmentCode ?? null,
                    operatorName: 'OCV设备',
                    isDraft: false,
                    recordStatus: 1,
                }));
            });
            const savedCells = await manager.save(cell_barcode_entity_1.CellBarcode, cellsToSave);
            await manager.save(ocv2_record_entity_1.Ocv2Record, recordsToInsert);
            return savedCells;
        });
    }
};
exports.CellBarcodeService = CellBarcodeService;
__decorate([
    (0, event_emitter_1.OnEvent)('process.record.updated'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], CellBarcodeService.prototype, "handleProcessRecordUpdated", null);
exports.CellBarcodeService = CellBarcodeService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(cell_barcode_entity_1.CellBarcode)),
    __param(1, (0, typeorm_1.InjectRepository)(batch_entity_1.Batch)),
    __param(2, (0, typeorm_1.InjectRepository)(ocv1_record_entity_1.Ocv1Record)),
    __param(3, (0, typeorm_1.InjectRepository)(ocv2_record_entity_1.Ocv2Record)),
    __param(5, (0, common_1.Inject)(cache_manager_1.CACHE_MANAGER)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        process_status_service_1.ProcessStatusService,
        cache_manager_1.Cache])
], CellBarcodeService);
//# sourceMappingURL=cell-barcode.service.js.map