export declare class CellBarcodeModule {
}
