export declare class Ocv2UploadDto {
    batchNo: string;
    barcode: string;
    voltage?: number;
    internalResistance?: number;
    resistance?: number;
    kValue?: number;
    testTime?: string;
    equipmentCode?: string;
}
