export declare class SorterUploadDto {
    batchNo: string;
    barcode: string;
    capacity?: string;
    voltage?: number;
    internalResistance?: number;
    resistance?: number;
    kValue?: number;
    grade?: string;
    sortingTime?: string;
}
