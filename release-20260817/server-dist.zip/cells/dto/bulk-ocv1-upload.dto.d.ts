import { Ocv1UploadDto } from './ocv1-upload.dto';
export declare class BulkOcv1UploadDto {
    ocv1Records: Ocv1UploadDto[];
}
