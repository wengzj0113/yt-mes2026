export declare function normalizeDeviceDateTime(value: unknown): unknown;
