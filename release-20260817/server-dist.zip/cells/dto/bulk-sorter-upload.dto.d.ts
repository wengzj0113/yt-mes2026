import { SorterUploadDto } from './sorter-upload.dto';
export declare class BulkSorterUploadDto {
    cells: SorterUploadDto[];
}
