"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeDeviceDateTime = normalizeDeviceDateTime;
const LOCAL_DEVICE_DATE_TIME = /^(\d{4}-\d{2}-\d{2})[ ](\d{2}:\d{2}:\d{2})(?:\.(\d{1,3}))?$/;
function normalizeDeviceDateTime(value) {
    if (typeof value !== 'string')
        return value;
    const match = value.match(LOCAL_DEVICE_DATE_TIME);
    if (!match)
        return value;
    const fraction = match[3] ? `.${match[3].padEnd(3, '0')}` : '';
    return `${match[1]}T${match[2]}${fraction}+08:00`;
}
//# sourceMappingURL=normalize-device-date-time.js.map