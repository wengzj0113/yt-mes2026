import { Ocv2UploadDto } from './ocv2-upload.dto';
export declare class BulkOcv2UploadDto {
    ocv2Records: Ocv2UploadDto[];
}
