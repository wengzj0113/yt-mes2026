export declare class Ocv1UploadDto {
    batchNo: string;
    barcode: string;
    voltage?: number;
    internalResistance?: number;
    resistance?: number;
    testTime?: string;
    equipmentCode?: string;
}
