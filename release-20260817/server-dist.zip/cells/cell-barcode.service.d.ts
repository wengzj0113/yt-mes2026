import { Repository } from 'typeorm';
import { Cache } from '@nestjs/cache-manager';
import { CellBarcode } from './cell-barcode.entity';
import { Batch } from '../batch/batch.entity';
import { ProcessStatusService } from '../processes/process-status/process-status.service';
import { SorterUploadDto } from './dto/sorter-upload.dto';
import { BulkSorterUploadDto } from './dto/bulk-sorter-upload.dto';
import { Ocv1UploadDto } from './dto/ocv1-upload.dto';
import { BulkOcv1UploadDto } from './dto/bulk-ocv1-upload.dto';
import { Ocv2UploadDto } from './dto/ocv2-upload.dto';
import { BulkOcv2UploadDto } from './dto/bulk-ocv2-upload.dto';
import { Ocv1Record } from '../processes/ocv/ocv1-record.entity';
import { Ocv2Record } from '../processes/ocv/ocv2-record.entity';
export declare class CellBarcodeService {
    private readonly repo;
    private readonly batchRepo;
    private readonly ocv1RecordRepo;
    private readonly ocv2RecordRepo;
    private readonly processStatusService;
    private readonly cacheManager;
    constructor(repo: Repository<CellBarcode>, batchRepo: Repository<Batch>, ocv1RecordRepo: Repository<Ocv1Record>, ocv2RecordRepo: Repository<Ocv2Record>, processStatusService: ProcessStatusService, cacheManager: Cache);
    sorterUpload(dto: SorterUploadDto): Promise<CellBarcode>;
    bulkSorterUpload(dto: BulkSorterUploadDto): Promise<CellBarcode[]>;
    trace(barcode: string): Promise<{
        cell: CellBarcode;
        batch: Batch | null;
        processes: Record<string, any>;
    }>;
    findByBatch(batchNo: string, pageNum?: number, pageSizeNum?: number): Promise<{
        data: CellBarcode[];
        total: number;
        page: number;
        pageSize: number;
    }>;
    handleProcessRecordUpdated(payload: {
        batchNo: string;
    }): Promise<void>;
    ocv1Upload(dto: Ocv1UploadDto): Promise<CellBarcode[]>;
    bulkOcv1Upload(dto: BulkOcv1UploadDto): Promise<CellBarcode[]>;
    private processOcv1Batch;
    ocv2Upload(dto: Ocv2UploadDto): Promise<CellBarcode[]>;
    bulkOcv2Upload(dto: BulkOcv2UploadDto): Promise<CellBarcode[]>;
    private processOcv2Batch;
}
