export declare class CellBarcode {
    id: number;
    barcode: string;
    batchNo: string;
    sortingRecordId: number | null;
    voltage: number | null;
    internalResistance: number | null;
    capacity: string | null;
    kValue: number | null;
    sortingTime: Date | null;
    grade: string | null;
    importSource: string | null;
    ocv1Voltage: number | null;
    ocv1Resistance: number | null;
    ocv1Time: Date | null;
    ocv1EquipmentCode: string | null;
    ocv2Voltage: number | null;
    ocv2Resistance: number | null;
    ocv2Time: Date | null;
    ocv2EquipmentCode: string | null;
    importedAt: Date;
    createdAt: Date;
}
