"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CellBarcodeModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const cell_barcode_entity_1 = require("./cell-barcode.entity");
const cell_barcode_service_1 = require("./cell-barcode.service");
const cell_barcode_controller_1 = require("./cell-barcode.controller");
const batch_entity_1 = require("../batch/batch.entity");
const process_status_module_1 = require("../processes/process-status/process-status.module");
const system_module_1 = require("../system/system.module");
const ocv1_record_entity_1 = require("../processes/ocv/ocv1-record.entity");
const ocv2_record_entity_1 = require("../processes/ocv/ocv2-record.entity");
let CellBarcodeModule = class CellBarcodeModule {
};
exports.CellBarcodeModule = CellBarcodeModule;
exports.CellBarcodeModule = CellBarcodeModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([cell_barcode_entity_1.CellBarcode, batch_entity_1.Batch, ocv1_record_entity_1.Ocv1Record, ocv2_record_entity_1.Ocv2Record]),
            process_status_module_1.ProcessStatusModule,
            system_module_1.SystemModule,
        ],
        providers: [cell_barcode_service_1.CellBarcodeService],
        controllers: [cell_barcode_controller_1.CellBarcodeController],
    })
], CellBarcodeModule);
//# sourceMappingURL=cell-barcode.module.js.map