"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CellBarcode = void 0;
const typeorm_1 = require("typeorm");
let CellBarcode = class CellBarcode {
};
exports.CellBarcode = CellBarcode;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id' }),
    __metadata("design:type", Number)
], CellBarcode.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'barcode', length: 32, unique: true }),
    __metadata("design:type", String)
], CellBarcode.prototype, "barcode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'batch_no', length: 16 }),
    __metadata("design:type", String)
], CellBarcode.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'sorting_record_id', type: 'int', nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "sortingRecordId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'voltage', type: 'decimal', precision: 12, scale: 4, nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "voltage", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'internal_resistance', type: 'decimal', precision: 12, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "internalResistance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'capacity', type: 'nvarchar', length: 32, nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "capacity", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'k_value', type: 'decimal', precision: 12, scale: 4, nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "kValue", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'sorting_time', type: 'datetime2', nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "sortingTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'grade', type: 'nvarchar', length: 16, nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "grade", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'import_source', type: 'nvarchar', length: 32, nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "importSource", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ocv1_voltage', type: 'decimal', precision: 12, scale: 4, nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "ocv1Voltage", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ocv1_resistance', type: 'decimal', precision: 12, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "ocv1Resistance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ocv1_time', type: 'datetime2', nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "ocv1Time", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ocv1_equipment_code', type: 'nvarchar', length: 64, nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "ocv1EquipmentCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ocv2_voltage', type: 'decimal', precision: 12, scale: 4, nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "ocv2Voltage", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ocv2_resistance', type: 'decimal', precision: 12, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "ocv2Resistance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ocv2_time', type: 'datetime2', nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "ocv2Time", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ocv2_equipment_code', type: 'nvarchar', length: 64, nullable: true }),
    __metadata("design:type", Object)
], CellBarcode.prototype, "ocv2EquipmentCode", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'imported_at' }),
    __metadata("design:type", Date)
], CellBarcode.prototype, "importedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], CellBarcode.prototype, "createdAt", void 0);
exports.CellBarcode = CellBarcode = __decorate([
    (0, typeorm_1.Entity)('cell_barcode')
], CellBarcode);
//# sourceMappingURL=cell-barcode.entity.js.map