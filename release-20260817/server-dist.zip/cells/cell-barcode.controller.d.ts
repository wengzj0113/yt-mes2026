import { CellBarcodeService } from './cell-barcode.service';
import { SorterUploadDto } from './dto/sorter-upload.dto';
import { BulkSorterUploadDto } from './dto/bulk-sorter-upload.dto';
import { Ocv1UploadDto } from './dto/ocv1-upload.dto';
import { BulkOcv1UploadDto } from './dto/bulk-ocv1-upload.dto';
import { Ocv2UploadDto } from './dto/ocv2-upload.dto';
import { BulkOcv2UploadDto } from './dto/bulk-ocv2-upload.dto';
export declare class CellBarcodeController {
    private readonly cellBarcodeService;
    constructor(cellBarcodeService: CellBarcodeService);
    sorterUpload(dto: SorterUploadDto): Promise<{
        data: import("./cell-barcode.entity").CellBarcode;
        message: string;
    }>;
    bulkSorterUpload(dto: BulkSorterUploadDto): Promise<{
        data: import("./cell-barcode.entity").CellBarcode[];
        message: string;
    }>;
    ocv1Upload(dto: Ocv1UploadDto): Promise<{
        data: import("./cell-barcode.entity").CellBarcode;
        message: string;
    }>;
    bulkOcv1Upload(dto: BulkOcv1UploadDto): Promise<{
        data: import("./cell-barcode.entity").CellBarcode[];
        message: string;
    }>;
    ocv2Upload(dto: Ocv2UploadDto): Promise<{
        data: import("./cell-barcode.entity").CellBarcode;
        message: string;
    }>;
    bulkOcv2Upload(dto: BulkOcv2UploadDto): Promise<{
        data: import("./cell-barcode.entity").CellBarcode[];
        message: string;
    }>;
    trace(barcode: string): Promise<{
        data: {
            cell: import("./cell-barcode.entity").CellBarcode;
            batch: import("../batch/batch.entity").Batch | null;
            processes: Record<string, any>;
        };
    }>;
    findByBatch(batchNo: string, page: number, pageSize: number): Promise<{
        data: import("./cell-barcode.entity").CellBarcode[];
        meta: {
            page: number;
            pageSize: number;
            total: number;
            totalPages: number;
        };
    }>;
}
