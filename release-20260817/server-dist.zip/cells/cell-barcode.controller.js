"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CellBarcodeController = void 0;
const common_1 = require("@nestjs/common");
const cell_barcode_service_1 = require("./cell-barcode.service");
const sorter_upload_dto_1 = require("./dto/sorter-upload.dto");
const bulk_sorter_upload_dto_1 = require("./dto/bulk-sorter-upload.dto");
const ocv1_upload_dto_1 = require("./dto/ocv1-upload.dto");
const bulk_ocv1_upload_dto_1 = require("./dto/bulk-ocv1-upload.dto");
const ocv2_upload_dto_1 = require("./dto/ocv2-upload.dto");
const bulk_ocv2_upload_dto_1 = require("./dto/bulk-ocv2-upload.dto");
const public_decorator_1 = require("../common/decorators/public.decorator");
const roles_decorator_1 = require("../common/decorators/roles.decorator");
const user_entity_1 = require("../user/user.entity");
const sorter_api_log_interceptor_1 = require("../common/interceptors/sorter-api-log.interceptor");
const api_type_decorator_1 = require("../common/decorators/api-type.decorator");
let CellBarcodeController = class CellBarcodeController {
    constructor(cellBarcodeService) {
        this.cellBarcodeService = cellBarcodeService;
    }
    async sorterUpload(dto) {
        const record = await this.cellBarcodeService.sorterUpload(dto);
        return { data: record, message: '分选数据接收成功' };
    }
    async bulkSorterUpload(dto) {
        const records = await this.cellBarcodeService.bulkSorterUpload(dto);
        return { data: records, message: '批量分选数据接收成功' };
    }
    async ocv1Upload(dto) {
        const records = await this.cellBarcodeService.ocv1Upload(dto);
        return { data: records[0], message: 'OCV1测试数据接收成功' };
    }
    async bulkOcv1Upload(dto) {
        const records = await this.cellBarcodeService.bulkOcv1Upload(dto);
        return { data: records, message: '批量OCV1测试数据接收成功' };
    }
    async ocv2Upload(dto) {
        const records = await this.cellBarcodeService.ocv2Upload(dto);
        return { data: records[0], message: 'OCV2测试数据接收成功' };
    }
    async bulkOcv2Upload(dto) {
        const records = await this.cellBarcodeService.bulkOcv2Upload(dto);
        return { data: records, message: '批量OCV2测试数据接收成功' };
    }
    async trace(barcode) {
        const cell = await this.cellBarcodeService.trace(barcode);
        return { data: cell };
    }
    async findByBatch(batchNo, page, pageSize) {
        const result = await this.cellBarcodeService.findByBatch(batchNo, page, pageSize);
        return {
            data: result.data,
            meta: {
                page: result.page,
                pageSize: result.pageSize,
                total: result.total,
                totalPages: Math.ceil(result.total / result.pageSize),
            },
        };
    }
};
exports.CellBarcodeController = CellBarcodeController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, api_type_decorator_1.ApiTypeDecorator)('sorter'),
    (0, common_1.UseInterceptors)(sorter_api_log_interceptor_1.SorterApiLogInterceptor),
    (0, common_1.Post)('sorter-upload'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [sorter_upload_dto_1.SorterUploadDto]),
    __metadata("design:returntype", Promise)
], CellBarcodeController.prototype, "sorterUpload", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, api_type_decorator_1.ApiTypeDecorator)('sorter'),
    (0, common_1.UseInterceptors)(sorter_api_log_interceptor_1.SorterApiLogInterceptor),
    (0, common_1.Post)('sorter-upload/bulk'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [bulk_sorter_upload_dto_1.BulkSorterUploadDto]),
    __metadata("design:returntype", Promise)
], CellBarcodeController.prototype, "bulkSorterUpload", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, api_type_decorator_1.ApiTypeDecorator)('ocv1'),
    (0, common_1.UseInterceptors)(sorter_api_log_interceptor_1.SorterApiLogInterceptor),
    (0, common_1.Post)('ocv1-upload'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [ocv1_upload_dto_1.Ocv1UploadDto]),
    __metadata("design:returntype", Promise)
], CellBarcodeController.prototype, "ocv1Upload", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, api_type_decorator_1.ApiTypeDecorator)('ocv1'),
    (0, common_1.UseInterceptors)(sorter_api_log_interceptor_1.SorterApiLogInterceptor),
    (0, common_1.Post)('ocv1-upload/bulk'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [bulk_ocv1_upload_dto_1.BulkOcv1UploadDto]),
    __metadata("design:returntype", Promise)
], CellBarcodeController.prototype, "bulkOcv1Upload", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, api_type_decorator_1.ApiTypeDecorator)('ocv2'),
    (0, common_1.UseInterceptors)(sorter_api_log_interceptor_1.SorterApiLogInterceptor),
    (0, common_1.Post)('ocv2-upload'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [ocv2_upload_dto_1.Ocv2UploadDto]),
    __metadata("design:returntype", Promise)
], CellBarcodeController.prototype, "ocv2Upload", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, api_type_decorator_1.ApiTypeDecorator)('ocv2'),
    (0, common_1.UseInterceptors)(sorter_api_log_interceptor_1.SorterApiLogInterceptor),
    (0, common_1.Post)('ocv2-upload/bulk'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [bulk_ocv2_upload_dto_1.BulkOcv2UploadDto]),
    __metadata("design:returntype", Promise)
], CellBarcodeController.prototype, "bulkOcv2Upload", null);
__decorate([
    (0, common_1.Get)(':barcode/trace'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.OPERATOR, user_entity_1.UserRole.QUALITY, user_entity_1.UserRole.WAREHOUSE, user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('barcode')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], CellBarcodeController.prototype, "trace", null);
__decorate([
    (0, common_1.Get)('batch/:batchNo/barcodes'),
    (0, roles_decorator_1.Roles)(user_entity_1.UserRole.OPERATOR, user_entity_1.UserRole.QUALITY, user_entity_1.UserRole.WAREHOUSE, user_entity_1.UserRole.ADMIN),
    __param(0, (0, common_1.Param)('batchNo')),
    __param(1, (0, common_1.Query)('page', new common_1.DefaultValuePipe(1), common_1.ParseIntPipe)),
    __param(2, (0, common_1.Query)('pageSize', new common_1.DefaultValuePipe(20), common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number, Number]),
    __metadata("design:returntype", Promise)
], CellBarcodeController.prototype, "findByBatch", null);
exports.CellBarcodeController = CellBarcodeController = __decorate([
    (0, common_1.Controller)('cells'),
    __metadata("design:paramtypes", [cell_barcode_service_1.CellBarcodeService])
], CellBarcodeController);
//# sourceMappingURL=cell-barcode.controller.js.map