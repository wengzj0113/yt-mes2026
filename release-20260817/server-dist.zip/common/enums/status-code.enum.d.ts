export declare const BusinessStatusCode: {
    readonly SUCCESS: {
        readonly code: "SUCCESS";
        readonly message: "操作成功";
        readonly httpStatus: 200;
    };
    readonly BAD_REQUEST: {
        readonly code: "BAD_REQUEST";
        readonly message: "请求参数错误";
        readonly httpStatus: 400;
    };
    readonly UNAUTHORIZED: {
        readonly code: "UNAUTHORIZED";
        readonly message: "未登录或 Token 已过期";
        readonly httpStatus: 401;
    };
    readonly FORBIDDEN: {
        readonly code: "FORBIDDEN";
        readonly message: "权限不足";
        readonly httpStatus: 403;
    };
    readonly NOT_FOUND: {
        readonly code: "NOT_FOUND";
        readonly message: "资源不存在";
        readonly httpStatus: 404;
    };
    readonly CONFLICT: {
        readonly code: "CONFLICT";
        readonly message: "资源冲突";
        readonly httpStatus: 409;
    };
    readonly VALIDATION_ERROR: {
        readonly code: "VALIDATION_ERROR";
        readonly message: "请求参数校验失败";
        readonly httpStatus: 422;
    };
    readonly USER_NOT_FOUND: {
        readonly code: "USER_NOT_FOUND";
        readonly message: "用户不存在";
        readonly httpStatus: 404;
    };
    readonly USER_PASSWORD_ERROR: {
        readonly code: "USER_PASSWORD_ERROR";
        readonly message: "密码错误";
        readonly httpStatus: 401;
    };
    readonly USER_DISABLED: {
        readonly code: "USER_DISABLED";
        readonly message: "账号已被禁用";
        readonly httpStatus: 403;
    };
    readonly USER_LOCKED: {
        readonly code: "USER_LOCKED";
        readonly message: "账号已被锁定，请稍后再试";
        readonly httpStatus: 423;
    };
    readonly BATCH_NOT_FOUND: {
        readonly code: "BATCH_NOT_FOUND";
        readonly message: "批次不存在";
        readonly httpStatus: 404;
    };
    readonly BATCH_STATUS_CONFLICT: {
        readonly code: "BATCH_STATUS_CONFLICT";
        readonly message: "批次状态不匹配";
        readonly httpStatus: 409;
    };
    readonly PROCESS_DRAFT_EXISTS: {
        readonly code: "PROCESS_DRAFT_EXISTS";
        readonly message: "草稿已存在";
        readonly httpStatus: 409;
    };
    readonly PROCESS_ALREADY_SUBMITTED: {
        readonly code: "PROCESS_ALREADY_SUBMITTED";
        readonly message: "记录已提交";
        readonly httpStatus: 409;
    };
    readonly PROCESS_FIELDS_INCOMPLETE: {
        readonly code: "PROCESS_FIELDS_INCOMPLETE";
        readonly message: "字段未填写完整";
        readonly httpStatus: 422;
    };
    readonly BATCH_STATUS_TRANSITION_INVALID: {
        readonly code: "BATCH_STATUS_TRANSITION_INVALID";
        readonly message: "状态转换不合法";
        readonly httpStatus: 422;
    };
    readonly CELL_BARCODE_DUPLICATE: {
        readonly code: "CELL_BARCODE_DUPLICATE";
        readonly message: "电芯码重复导入";
        readonly httpStatus: 409;
    };
    readonly INTERNAL_ERROR: {
        readonly code: "SYSTEM_INTERNAL_ERROR";
        readonly message: "服务器内部错误";
        readonly httpStatus: 500;
    };
};
export type BusinessCode = keyof typeof BusinessStatusCode;
