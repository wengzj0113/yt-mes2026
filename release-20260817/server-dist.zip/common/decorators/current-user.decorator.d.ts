export interface JwtPayload {
    sub: number;
    username: string;
    roleCode: number;
    iat?: number;
    exp?: number;
}
export declare const CurrentUser: (...dataOrPipes: (import("@nestjs/common").PipeTransform<any, any> | import("@nestjs/common").Type<import("@nestjs/common").PipeTransform<any, any>> | keyof JwtPayload | undefined)[]) => ParameterDecorator;
