import { ApiType } from '../interceptors/sorter-api-log.interceptor';
export declare const API_TYPE_KEY = "api_type";
export declare const ApiTypeDecorator: (apiType: ApiType) => import("@nestjs/common").CustomDecorator<string>;
