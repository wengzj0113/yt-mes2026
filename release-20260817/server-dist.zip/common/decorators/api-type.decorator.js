"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiTypeDecorator = exports.API_TYPE_KEY = void 0;
const common_1 = require("@nestjs/common");
exports.API_TYPE_KEY = 'api_type';
const ApiTypeDecorator = (apiType) => (0, common_1.SetMetadata)(exports.API_TYPE_KEY, apiType);
exports.ApiTypeDecorator = ApiTypeDecorator;
//# sourceMappingURL=api-type.decorator.js.map