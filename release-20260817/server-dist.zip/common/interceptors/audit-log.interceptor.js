"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditLogInterceptor = void 0;
const common_1 = require("@nestjs/common");
const operators_1 = require("rxjs/operators");
const system_service_1 = require("../../system/system.service");
let AuditLogInterceptor = class AuditLogInterceptor {
    constructor(systemService) {
        this.systemService = systemService;
        this.moduleMap = {
            '/api/users': '用户管理',
            '/api/roles': '角色管理',
            '/api/departments': '部门管理',
            '/api/equipment': '设备管理',
            '/api/batches': '批次管理',
            '/api/processes': '工序管理',
            '/api/system': '系统配置',
            '/api/master-data': '工序主数据',
            '/api/process-dictionary': '工序主数据',
            '/api/packs': 'Pack管理',
        };
        this.actionMap = {
            POST: '新增',
            PUT: '修改',
            PATCH: '修改',
            DELETE: '删除',
        };
    }
    intercept(context, next) {
        const request = context.switchToHttp().getRequest();
        const { method, url, ip } = request;
        if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) {
            return next.handle();
        }
        if (url.includes('/api/auth') || url.includes('/api/system/logs')) {
            return next.handle();
        }
        return next.handle().pipe((0, operators_1.tap)(async () => {
            const user = request.user;
            if (!user)
                return;
            const module = this.getModule(url);
            const action = this.actionMap[method] || method;
            let detail = `${action}了资源: ${url}`;
            if (request.body && Object.keys(request.body).length > 0) {
                const body = { ...request.body };
                delete body.password;
                detail += `，参数: ${JSON.stringify(body).substring(0, 500)}`;
            }
            try {
                await this.systemService.logAction({
                    userId: user.sub || user.id,
                    username: user.username,
                    module,
                    action,
                    detail,
                    ip,
                });
            }
            catch (error) {
                console.error('Failed to record audit log:', error);
            }
        }));
    }
    getModule(url) {
        for (const prefix in this.moduleMap) {
            if (url.startsWith(prefix)) {
                return this.moduleMap[prefix];
            }
        }
        return '其他模块';
    }
};
exports.AuditLogInterceptor = AuditLogInterceptor;
exports.AuditLogInterceptor = AuditLogInterceptor = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [system_service_1.SystemService])
], AuditLogInterceptor);
//# sourceMappingURL=audit-log.interceptor.js.map