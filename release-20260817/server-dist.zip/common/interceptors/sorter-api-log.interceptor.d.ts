import { NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { Observable } from 'rxjs';
import { SystemService } from '../../system/system.service';
import { Reflector } from '@nestjs/core';
export type ApiType = 'sorter' | 'ocv1' | 'ocv2';
export declare class SorterApiLogInterceptor implements NestInterceptor {
    private readonly systemService;
    private readonly reflector;
    constructor(systemService: SystemService, reflector: Reflector);
    intercept(context: ExecutionContext, next: CallHandler): Observable<any>;
}
