"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SorterApiLogInterceptor = void 0;
const common_1 = require("@nestjs/common");
const rxjs_1 = require("rxjs");
const operators_1 = require("rxjs/operators");
const system_service_1 = require("../../system/system.service");
const core_1 = require("@nestjs/core");
const api_type_decorator_1 = require("../decorators/api-type.decorator");
let SorterApiLogInterceptor = class SorterApiLogInterceptor {
    constructor(systemService, reflector) {
        this.systemService = systemService;
        this.reflector = reflector;
    }
    intercept(context, next) {
        const request = context.switchToHttp().getRequest();
        const response = context.switchToHttp().getResponse();
        const { method, url, ip, body } = request;
        const startTime = Date.now();
        const apiType = this.reflector.get(api_type_decorator_1.API_TYPE_KEY, context.getHandler()) || 'sorter';
        return next.handle().pipe((0, operators_1.tap)(async (resBody) => {
            const duration = Date.now() - startTime;
            try {
                await this.systemService.logSorterApi({
                    apiEndpoint: url,
                    method,
                    requestBody: JSON.stringify(body),
                    responseBody: JSON.stringify(resBody),
                    statusCode: response.statusCode || 201,
                    isSuccess: true,
                    ip,
                    duration,
                    apiType,
                });
            }
            catch (error) {
                console.error('Failed to save sorter API success log:', error);
            }
        }), (0, operators_1.catchError)((err) => {
            const duration = Date.now() - startTime;
            const statusCode = err.status || err.statusCode || 500;
            const errorMessage = err.message || JSON.stringify(err);
            const errorResponse = err.response || { message: err.message };
            this.systemService.logSorterApi({
                apiEndpoint: url,
                method,
                requestBody: JSON.stringify(body),
                responseBody: JSON.stringify(errorResponse),
                statusCode,
                isSuccess: false,
                errorMessage,
                ip,
                duration,
                apiType,
            }).catch((error) => {
                console.error('Failed to save sorter API error log:', error);
            });
            return (0, rxjs_1.throwError)(() => err);
        }));
    }
};
exports.SorterApiLogInterceptor = SorterApiLogInterceptor;
exports.SorterApiLogInterceptor = SorterApiLogInterceptor = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [system_service_1.SystemService,
        core_1.Reflector])
], SorterApiLogInterceptor);
//# sourceMappingURL=sorter-api-log.interceptor.js.map