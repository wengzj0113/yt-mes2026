import { NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { Observable } from 'rxjs';
import { SystemService } from '../../system/system.service';
export declare class AuditLogInterceptor implements NestInterceptor {
    private readonly systemService;
    constructor(systemService: SystemService);
    private moduleMap;
    private actionMap;
    intercept(context: ExecutionContext, next: CallHandler): Observable<any>;
    private getModule;
}
