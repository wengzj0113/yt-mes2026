export declare function mergeExtraData(record: any, dto: any, entityFields: string[]): void;
