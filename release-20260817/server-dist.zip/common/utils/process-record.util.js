"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mergeExtraData = mergeExtraData;
function mergeExtraData(record, dto, entityFields) {
    const extraData = record.extraData ? JSON.parse(record.extraData) : {};
    const entityFieldSet = new Set(entityFields);
    Object.entries(dto).forEach(([key, value]) => {
        if (entityFieldSet.has(key)) {
            record[key] = value;
        }
        else if (key !== 'batchNo') {
            extraData[key] = value;
        }
    });
    if (Object.keys(extraData).length > 0) {
        record.extraData = JSON.stringify(extraData);
    }
}
//# sourceMappingURL=process-record.util.js.map