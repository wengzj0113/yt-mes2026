"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpExceptionFilter = void 0;
const common_1 = require("@nestjs/common");
let HttpExceptionFilter = class HttpExceptionFilter {
    catch(exception, host) {
        const ctx = host.switchToHttp();
        const response = ctx.getResponse();
        let status = common_1.HttpStatus.INTERNAL_SERVER_ERROR;
        let message = '服务器内部错误';
        let code;
        let fields;
        if (exception instanceof common_1.HttpException) {
            status = exception.getStatus();
            const res = exception.getResponse();
            if (typeof res === 'string') {
                message = res;
            }
            else if (typeof res === 'object') {
                const body = res;
                message = body.message || exception.message;
                if (Array.isArray(body.message)) {
                    fields = body.message.map((err) => {
                        const field = err.property || 'unknown';
                        const errMessages = err.constraints
                            ? Object.values(err.constraints)
                            : ['invalid value'];
                        return {
                            field,
                            message: errMessages[0],
                            value: err.value,
                        };
                    });
                    message = '请求参数校验失败';
                    code = 'VALIDATION_ERROR';
                }
                if (body.code)
                    code = body.code;
            }
        }
        else if (exception instanceof Error) {
            console.error('Unhandled error:', exception);
            message =
                process.env.NODE_ENV === 'development'
                    ? exception.message
                    : '服务器内部错误';
        }
        const errorBody = (() => {
            if (code && fields)
                return { error: { code, fields } };
            if (code)
                return { error: { code } };
            if (fields)
                return { error: { code: 'VALIDATION_ERROR', fields } };
            return {};
        })();
        response.status(status).json({
            success: false,
            data: null,
            message,
            ...errorBody,
        });
    }
};
exports.HttpExceptionFilter = HttpExceptionFilter;
exports.HttpExceptionFilter = HttpExceptionFilter = __decorate([
    (0, common_1.Catch)()
], HttpExceptionFilter);
//# sourceMappingURL=http-exception.filter.js.map