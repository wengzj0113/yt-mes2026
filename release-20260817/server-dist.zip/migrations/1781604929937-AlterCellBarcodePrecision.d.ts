import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AlterCellBarcodePrecision1781604929937 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
