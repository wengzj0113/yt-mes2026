import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AlignProcessDictionaryWithExcel1781860000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(): Promise<void>;
}
