"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IncreaseCellBarcodeDecimalPrecision1781700000000 = void 0;
class IncreaseCellBarcodeDecimalPrecision1781700000000 {
    async up(queryRunner) {
        await queryRunner.query(`
            IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('cell_barcode') AND name = 'voltage')
            BEGIN
                ALTER TABLE cell_barcode ALTER COLUMN voltage DECIMAL(12,4) NULL;
            END
        `);
        await queryRunner.query(`
            IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('cell_barcode') AND name = 'internal_resistance')
            BEGIN
                ALTER TABLE cell_barcode ALTER COLUMN internal_resistance DECIMAL(12,2) NULL;
            END
        `);
        await queryRunner.query(`
            IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('cell_barcode') AND name = 'k_value')
            BEGIN
                ALTER TABLE cell_barcode ALTER COLUMN k_value DECIMAL(12,4) NULL;
            END
        `);
    }
    async down(queryRunner) {
        await queryRunner.query(`
            IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('cell_barcode') AND name = 'voltage')
            BEGIN
                ALTER TABLE cell_barcode ALTER COLUMN voltage DECIMAL(6,4) NULL;
            END
        `);
        await queryRunner.query(`
            IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('cell_barcode') AND name = 'internal_resistance')
            BEGIN
                ALTER TABLE cell_barcode ALTER COLUMN internal_resistance DECIMAL(6,2) NULL;
            END
        `);
        await queryRunner.query(`
            IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('cell_barcode') AND name = 'k_value')
            BEGIN
                ALTER TABLE cell_barcode ALTER COLUMN k_value DECIMAL(6,4) NULL;
            END
        `);
    }
}
exports.IncreaseCellBarcodeDecimalPrecision1781700000000 = IncreaseCellBarcodeDecimalPrecision1781700000000;
//# sourceMappingURL=1781700000000-IncreaseCellBarcodeDecimalPrecision.js.map