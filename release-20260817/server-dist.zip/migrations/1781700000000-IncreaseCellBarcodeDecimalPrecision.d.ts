import { MigrationInterface, QueryRunner } from "typeorm";
export declare class IncreaseCellBarcodeDecimalPrecision1781700000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
