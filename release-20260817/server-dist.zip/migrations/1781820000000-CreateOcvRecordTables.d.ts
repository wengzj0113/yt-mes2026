import { MigrationInterface, QueryRunner } from "typeorm";
export declare class CreateOcvRecordTables1781820000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
