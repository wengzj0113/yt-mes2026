import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class CreateOcvKValueCalculation1781840000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
