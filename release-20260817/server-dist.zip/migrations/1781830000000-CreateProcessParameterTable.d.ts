import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class CreateProcessParameterTable1781830000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
