import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddApiTypeToSorterApiLog1781800000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
