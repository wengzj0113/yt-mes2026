import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class UpdateOcvKValueCalculationToDays1781850000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
