import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class CreateSysRole1781900000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
