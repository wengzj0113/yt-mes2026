import { MigrationInterface, QueryRunner } from "typeorm";
export declare class ChangeCellBarcodeCapacityToNvarchar1781600000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
