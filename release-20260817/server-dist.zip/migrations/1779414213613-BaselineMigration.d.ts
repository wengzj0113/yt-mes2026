import { MigrationInterface, QueryRunner } from "typeorm";
export declare class BaselineMigration1779414213613 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
