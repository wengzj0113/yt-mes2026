"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddSortingRangeMinMax1779500000000 = void 0;
class AddSortingRangeMinMax1779500000000 {
    async up(queryRunner) {
        await queryRunner.query(`
            IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('sorting_record') AND name = 'ocv_voltage_min')
                ALTER TABLE sorting_record ADD ocv_voltage_min DECIMAL(10,4) NULL;
        `);
        await queryRunner.query(`
            IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('sorting_record') AND name = 'ocv_voltage_max')
                ALTER TABLE sorting_record ADD ocv_voltage_max DECIMAL(10,4) NULL;
        `);
        await queryRunner.query(`
            IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('sorting_record') AND name = 'ir_min')
                ALTER TABLE sorting_record ADD ir_min DECIMAL(10,4) NULL;
        `);
        await queryRunner.query(`
            IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('sorting_record') AND name = 'ir_max')
                ALTER TABLE sorting_record ADD ir_max DECIMAL(10,4) NULL;
        `);
        await queryRunner.query(`
            IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('sorting_record') AND name = 'capacity_min')
                ALTER TABLE sorting_record ADD capacity_min DECIMAL(10,4) NULL;
        `);
        await queryRunner.query(`
            IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('sorting_record') AND name = 'capacity_max')
                ALTER TABLE sorting_record ADD capacity_max DECIMAL(10,4) NULL;
        `);
    }
    async down(queryRunner) {
        await queryRunner.query(`
            IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('sorting_record') AND name = 'ocv_voltage_max')
                ALTER TABLE sorting_record DROP COLUMN ocv_voltage_max;
        `);
        await queryRunner.query(`
            IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('sorting_record') AND name = 'ocv_voltage_min')
                ALTER TABLE sorting_record DROP COLUMN ocv_voltage_min;
        `);
        await queryRunner.query(`
            IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('sorting_record') AND name = 'ir_max')
                ALTER TABLE sorting_record DROP COLUMN ir_max;
        `);
        await queryRunner.query(`
            IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('sorting_record') AND name = 'ir_min')
                ALTER TABLE sorting_record DROP COLUMN ir_min;
        `);
        await queryRunner.query(`
            IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('sorting_record') AND name = 'capacity_max')
                ALTER TABLE sorting_record DROP COLUMN capacity_max;
        `);
        await queryRunner.query(`
            IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('sorting_record') AND name = 'capacity_min')
                ALTER TABLE sorting_record DROP COLUMN capacity_min;
        `);
    }
}
exports.AddSortingRangeMinMax1779500000000 = AddSortingRangeMinMax1779500000000;
//# sourceMappingURL=1779500000000-AddSortingRangeMinMax.js.map