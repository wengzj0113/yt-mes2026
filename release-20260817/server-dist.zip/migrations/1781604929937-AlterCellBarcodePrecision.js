"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlterCellBarcodePrecision1781604929937 = void 0;
class AlterCellBarcodePrecision1781604929937 {
    constructor() {
        this.name = 'AlterCellBarcodePrecision1781604929937';
    }
    async up(queryRunner) {
        await queryRunner.query(`ALTER TABLE "cell_barcode" ALTER COLUMN "voltage" decimal(10,4)`);
        await queryRunner.query(`ALTER TABLE "cell_barcode" ALTER COLUMN "internal_resistance" decimal(10,2)`);
        await queryRunner.query(`ALTER TABLE "cell_barcode" ALTER COLUMN "k_value" decimal(10,4)`);
    }
    async down(queryRunner) {
        await queryRunner.query(`ALTER TABLE "cell_barcode" ALTER COLUMN "k_value" decimal(6,4)`);
        await queryRunner.query(`ALTER TABLE "cell_barcode" ALTER COLUMN "internal_resistance" decimal(6,2)`);
        await queryRunner.query(`ALTER TABLE "cell_barcode" ALTER COLUMN "voltage" decimal(6,4)`);
    }
}
exports.AlterCellBarcodePrecision1781604929937 = AlterCellBarcodePrecision1781604929937;
//# sourceMappingURL=1781604929937-AlterCellBarcodePrecision.js.map