"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChangeCellBarcodeCapacityToNvarchar1781600000000 = void 0;
class ChangeCellBarcodeCapacityToNvarchar1781600000000 {
    async up(queryRunner) {
        await queryRunner.query(`
            IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('cell_barcode') AND name = 'capacity')
            BEGIN
                -- 先修改列类型
                ALTER TABLE cell_barcode ALTER COLUMN capacity NVARCHAR(32) NULL;
            END
        `);
    }
    async down(queryRunner) {
        await queryRunner.query(`
            IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('cell_barcode') AND name = 'capacity')
            BEGIN
                ALTER TABLE cell_barcode ALTER COLUMN capacity DECIMAL(8,2) NULL;
            END
        `);
    }
}
exports.ChangeCellBarcodeCapacityToNvarchar1781600000000 = ChangeCellBarcodeCapacityToNvarchar1781600000000;
//# sourceMappingURL=1781600000000-ChangeCellBarcodeCapacityToNvarchar.js.map