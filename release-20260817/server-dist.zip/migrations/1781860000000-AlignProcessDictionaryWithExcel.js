"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlignProcessDictionaryWithExcel1781860000000 = void 0;
const process_baseline_1 = require("../master-data/process-baseline");
class AlignProcessDictionaryWithExcel1781860000000 {
    async up(queryRunner) {
        const existingRows = await queryRunner.query('SELECT process_code, field_definitions FROM process_dictionary');
        const existingByCode = new Map(existingRows.map((row) => [row.process_code, row.field_definitions]));
        for (const definition of process_baseline_1.PROCESS_BASELINE) {
            const fieldDefinitions = JSON.stringify((0, process_baseline_1.mergeFieldDefinitionsWithBaseline)(existingByCode.get(definition.processCode), definition.fieldDefinitions)).replace(/'/g, "''");
            const processName = definition.processName.replace(/'/g, "''");
            await queryRunner.query(`
        IF EXISTS (SELECT 1 FROM process_dictionary WHERE process_code = '${definition.processCode}')
          UPDATE process_dictionary
          SET process_name = N'${processName}', sort_order = ${definition.sortOrder}, is_active = 1,
              field_definitions = N'${fieldDefinitions}', updated_at = SYSUTCDATETIME()
          WHERE process_code = '${definition.processCode}'
        ELSE
          INSERT INTO process_dictionary (process_code, process_name, sort_order, is_active, field_definitions, created_at, updated_at)
          VALUES ('${definition.processCode}', N'${processName}', ${definition.sortOrder}, 1, N'${fieldDefinitions}', SYSUTCDATETIME(), SYSUTCDATETIME())
      `);
        }
        await queryRunner.query(`UPDATE process_dictionary SET is_active = 0, updated_at = SYSUTCDATETIME() WHERE process_code IN ('formation', 'grading')`);
    }
    async down() {
    }
}
exports.AlignProcessDictionaryWithExcel1781860000000 = AlignProcessDictionaryWithExcel1781860000000;
//# sourceMappingURL=1781860000000-AlignProcessDictionaryWithExcel.js.map