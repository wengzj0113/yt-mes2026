"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddApiTypeToSorterApiLog1781800000000 = void 0;
class AddApiTypeToSorterApiLog1781800000000 {
    async up(queryRunner) {
        await queryRunner.query(`
            IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('sorter_api_log') AND name = 'api_type')
            BEGIN
                ALTER TABLE sorter_api_log ADD api_type NVARCHAR(16) NULL;
            END
        `);
    }
    async down(queryRunner) {
        await queryRunner.query(`
            IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('sorter_api_log') AND name = 'api_type')
            BEGIN
                ALTER TABLE sorter_api_log DROP COLUMN api_type;
            END
        `);
    }
}
exports.AddApiTypeToSorterApiLog1781800000000 = AddApiTypeToSorterApiLog1781800000000;
//# sourceMappingURL=1781800000000-AddApiTypeToSorterApiLog.js.map