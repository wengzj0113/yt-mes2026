import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class CreateProcessDynamicRecord1781870000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(_queryRunner: QueryRunner): Promise<void>;
}
