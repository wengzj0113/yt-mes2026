export declare class HealthController {
    check(): {
        data: {
            status: string;
            timestamp: string;
            uptime: number;
        };
    };
}
